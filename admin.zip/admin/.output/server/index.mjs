globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"112f7-wG8LFLSFmp1X/NssVHEvb4qXUOk\"",
		"mtime": "2026-09-28T12:15:28.012Z",
		"size": 70391,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon-16x16.png": {
		"type": "image/png",
		"etag": "\"3d6-Vu8qiYHfsh1t3ej9y7uOzjE9juU\"",
		"mtime": "2026-09-28T12:15:27.898Z",
		"size": 982,
		"path": "../public/favicon-16x16.png"
	},
	"/favicon-32x32.png": {
		"type": "image/png",
		"etag": "\"c6e-aLzzcJF33jkg34wnOIQIknyRl2o\"",
		"mtime": "2026-09-28T12:15:27.936Z",
		"size": 3182,
		"path": "../public/favicon-32x32.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"2a6e-5IbgoEYVvd2g5b2XkktEjDQWpv8\"",
		"mtime": "2026-09-28T12:15:28.218Z",
		"size": 10862,
		"path": "../public/favicon.ico"
	},
	"/icon-192.png": {
		"type": "image/png",
		"etag": "\"13664-JBrudkEVcQY6PFx1IPqfT+JSlwE\"",
		"mtime": "2026-09-28T12:15:28.056Z",
		"size": 79460,
		"path": "../public/icon-192.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-11T11:39:00.208Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/icon-512.png": {
		"type": "image/png",
		"etag": "\"774f7-muwnpMwsqOMFsINY6QagXS7mGNU\"",
		"mtime": "2026-09-28T12:15:28.148Z",
		"size": 488695,
		"path": "../public/icon-512.png"
	},
	"/site.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"155-QDwvkqCrh3kNyejy7rWTIu4XXBI\"",
		"mtime": "2026-09-28T12:16:01.940Z",
		"size": 341,
		"path": "../public/site.webmanifest"
	},
	"/brand/nelma-icon.png": {
		"type": "image/png",
		"etag": "\"13664-JBrudkEVcQY6PFx1IPqfT+JSlwE\"",
		"mtime": "2026-09-28T12:15:28.056Z",
		"size": 79460,
		"path": "../public/brand/nelma-icon.png"
	},
	"/products/first_purchase.jpg": {
		"type": "image/jpeg",
		"etag": "\"1b437-GeKD9r7nkMK4AX4wjxplWzG+h0o\"",
		"mtime": "2026-09-28T09:17:38.819Z",
		"size": 111671,
		"path": "../public/products/first_purchase.jpg"
	},
	"/brand/nelma-logo.png": {
		"type": "image/png",
		"etag": "\"377b1-F59jS7dCq90PS3V3ZqiZw1FZ5S8\"",
		"mtime": "2026-09-28T16:26:59.949Z",
		"size": 227249,
		"path": "../public/brand/nelma-logo.png"
	},
	"/products/refill.jpg": {
		"type": "image/jpeg",
		"etag": "\"1bf07-GYtpfaRIWRn18hjQn6XORtLv7rE\"",
		"mtime": "2026-09-28T09:17:38.979Z",
		"size": 114439,
		"path": "../public/products/refill.jpg"
	},
	"/assets/admin-accounts-BuJmpqDb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"186d-a5LWonqbUrstRkIJBQ5tP9f5Y0U\"",
		"mtime": "2026-10-01T15:37:47.729Z",
		"size": 6253,
		"path": "../public/assets/admin-accounts-BuJmpqDb.js"
	},
	"/assets/arrow-left-C8CyOHN4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-UuGeGzCwxejG4xvPfZzDqeaxLcY\"",
		"mtime": "2026-10-01T15:37:47.729Z",
		"size": 165,
		"path": "../public/assets/arrow-left-C8CyOHN4.js"
	},
	"/assets/AssignmentModal-DxQg3l22.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9cd-bqjmWd7e3gMCuLovFQxD4yscoZA\"",
		"mtime": "2026-10-01T15:37:47.714Z",
		"size": 2509,
		"path": "../public/assets/AssignmentModal-DxQg3l22.js"
	},
	"/assets/check-Ci8GA_FX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-Dgm7sFZMm29Op2pmpqmaX2avdm4\"",
		"mtime": "2026-10-01T15:37:47.734Z",
		"size": 124,
		"path": "../public/assets/check-Ci8GA_FX.js"
	},
	"/assets/button-CbHDWFrM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e58-WJ8iO4AUWd/5lnvTuZPPTQmo628\"",
		"mtime": "2026-10-01T15:37:47.733Z",
		"size": 32344,
		"path": "../public/assets/button-CbHDWFrM.js"
	},
	"/assets/chevron-down-DvzM3DiY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-SiUFwCGu/RBzqum/KT0LB9GtHH0\"",
		"mtime": "2026-10-01T15:37:47.734Z",
		"size": 128,
		"path": "../public/assets/chevron-down-DvzM3DiY.js"
	},
	"/assets/circle-Cdnh72AK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82-N6VEKimWijfBKEDJQbkIkKoiLbM\"",
		"mtime": "2026-10-01T15:37:47.735Z",
		"size": 130,
		"path": "../public/assets/circle-Cdnh72AK.js"
	},
	"/assets/circle-plus-HL2_siJD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-xnUaOjkWNALujEoesUJ2fdtmbqk\"",
		"mtime": "2026-10-01T15:37:47.735Z",
		"size": 207,
		"path": "../public/assets/circle-plus-HL2_siJD.js"
	},
	"/assets/audit-logs-CJzpcHhL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bda-5oxzeHRWzUpsWpt8tVndhdvXrSY\"",
		"mtime": "2026-10-01T15:37:47.729Z",
		"size": 3034,
		"path": "../public/assets/audit-logs-CJzpcHhL.js"
	},
	"/assets/create-order-C78VsTHG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ee6-3felAZAcW9Pv3MS7ClbRlRnl50U\"",
		"mtime": "2026-10-01T15:37:47.737Z",
		"size": 16102,
		"path": "../public/assets/create-order-C78VsTHG.js"
	},
	"/assets/createLucideIcon-CoTZf2oV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-912eekqBZpj/U32QYMEY2v7pbtE\"",
		"mtime": "2026-10-01T15:37:47.738Z",
		"size": 1192,
		"path": "../public/assets/createLucideIcon-CoTZf2oV.js"
	},
	"/assets/ConfirmDialog-DDlf9q2c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1018-bRVW10nvG/+ngnCNpyLUF89qqwI\"",
		"mtime": "2026-10-01T15:37:47.716Z",
		"size": 4120,
		"path": "../public/assets/ConfirmDialog-DDlf9q2c.js"
	},
	"/assets/ContactFields-CGH4mMvE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29e-TESA020NsCtbb0+ENiexXhgK8us\"",
		"mtime": "2026-10-01T15:37:47.717Z",
		"size": 670,
		"path": "../public/assets/ContactFields-CGH4mMvE.js"
	},
	"/assets/dashboard-CaIT85VC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2254-kSsDLPFbeGIDnUtlVYmcrmlsc6o\"",
		"mtime": "2026-10-01T15:37:47.740Z",
		"size": 8788,
		"path": "../public/assets/dashboard-CaIT85VC.js"
	},
	"/assets/DataPagination-B9Ss_vOO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fa-axbbAKkxytnClP0NUH1/IrLbquk\"",
		"mtime": "2026-10-01T15:37:47.718Z",
		"size": 762,
		"path": "../public/assets/DataPagination-B9Ss_vOO.js"
	},
	"/assets/dialog-DtqQ49Wt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"83e-C5QoOUOBJrnzyERvH/GoXif0Hmk\"",
		"mtime": "2026-10-01T15:37:47.742Z",
		"size": 2110,
		"path": "../public/assets/dialog-DtqQ49Wt.js"
	},
	"/assets/deliveries-Ca8aUVDB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12cd-wHezKbtkVlBbsPWohPpI62vIk9w\"",
		"mtime": "2026-10-01T15:37:47.741Z",
		"size": 4813,
		"path": "../public/assets/deliveries-Ca8aUVDB.js"
	},
	"/assets/dist-BnCP_94i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1306-7JOFqMUtKULDh9B/aT3CXgzOZ0s\"",
		"mtime": "2026-10-01T15:37:47.742Z",
		"size": 4870,
		"path": "../public/assets/dist-BnCP_94i.js"
	},
	"/assets/dist-BpS8h7FN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6a-lQGbyFQUqG81b2gCsew4yXU7A/c\"",
		"mtime": "2026-10-01T15:37:47.743Z",
		"size": 3178,
		"path": "../public/assets/dist-BpS8h7FN.js"
	},
	"/assets/dist-CjqWO2QC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"277-s3SYATHfGmK6ClOSsCye/YZsbR4\"",
		"mtime": "2026-10-01T15:37:47.745Z",
		"size": 631,
		"path": "../public/assets/dist-CjqWO2QC.js"
	},
	"/assets/dist-CLQAGs60.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29d-zjSE5IoX2TjZ6qP/3nBYQR6A1cQ\"",
		"mtime": "2026-10-01T15:37:47.743Z",
		"size": 669,
		"path": "../public/assets/dist-CLQAGs60.js"
	},
	"/assets/dist-CoyOp6El.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6416-1LgvEEMSI5CXDS0AEcvqYQZxqzo\"",
		"mtime": "2026-10-01T15:37:47.746Z",
		"size": 25622,
		"path": "../public/assets/dist-CoyOp6El.js"
	},
	"/assets/dist-DlTlzDqh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10fe-+t17vO+AkXplgj0BKKDQo0yQb4I\"",
		"mtime": "2026-10-01T15:37:47.746Z",
		"size": 4350,
		"path": "../public/assets/dist-DlTlzDqh.js"
	},
	"/assets/dist-GfiyVQyI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1098-lXC9INQJPNhEhijWMv4PXd+z0PI\"",
		"mtime": "2026-10-01T15:37:47.749Z",
		"size": 4248,
		"path": "../public/assets/dist-GfiyVQyI.js"
	},
	"/assets/dist-ws-WhAEq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c97-93TilVbKo8zu+K1Txv8VCe+9XP8\"",
		"mtime": "2026-10-01T15:37:47.749Z",
		"size": 7319,
		"path": "../public/assets/dist-ws-WhAEq.js"
	},
	"/assets/DriverCard-pSjTQsru.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7bd-R3SZHEcW2MndDDeqAi7BKPQPqOM\"",
		"mtime": "2026-10-01T15:37:47.718Z",
		"size": 1981,
		"path": "../public/assets/DriverCard-pSjTQsru.js"
	},
	"/assets/drivers.index-cTrY4-7y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1093-LUgpC3hAMfbpvNu364hvr0M3eFg\"",
		"mtime": "2026-10-01T15:37:47.751Z",
		"size": 4243,
		"path": "../public/assets/drivers.index-cTrY4-7y.js"
	},
	"/assets/drivers._id-mx2wf5hT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a99-qnSgCZwcMGgM+CnLTOx8b4lP9HE\"",
		"mtime": "2026-10-01T15:37:47.750Z",
		"size": 6809,
		"path": "../public/assets/drivers._id-mx2wf5hT.js"
	},
	"/assets/es2015-Gk2xCMJo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5811-ufYUefOVcnDV84bLibnYEwhqH/A\"",
		"mtime": "2026-10-01T15:37:47.751Z",
		"size": 22545,
		"path": "../public/assets/es2015-Gk2xCMJo.js"
	},
	"/assets/input-B1mdbGkY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"266-oRc+zqbNSgqqFJhcUEW2LIL6eyA\"",
		"mtime": "2026-10-01T15:37:47.751Z",
		"size": 614,
		"path": "../public/assets/input-B1mdbGkY.js"
	},
	"/assets/FilterBar-Bm6nO-lE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c46-YCa7dwWCOGxlHYiG5IBZ7daeTec\"",
		"mtime": "2026-10-01T15:37:47.719Z",
		"size": 23622,
		"path": "../public/assets/FilterBar-Bm6nO-lE.js"
	},
	"/assets/label-kyqZC24D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ab-fUrAEJ4UryStVclp8FUFBvyxB7s\"",
		"mtime": "2026-10-01T15:37:47.754Z",
		"size": 683,
		"path": "../public/assets/label-kyqZC24D.js"
	},
	"/assets/link-zvcgpv5H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b21-od7xXEw+cIKOa8QC/BgeZhd4dCA\"",
		"mtime": "2026-10-01T15:37:47.754Z",
		"size": 23329,
		"path": "../public/assets/link-zvcgpv5H.js"
	},
	"/assets/index-rqflDa6O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"53961-0Se+Bq7oIDtcq9U9LfII0kmsacU\"",
		"mtime": "2026-10-01T15:37:47.713Z",
		"size": 342369,
		"path": "../public/assets/index-rqflDa6O.js"
	},
	"/assets/loader-circle-DxSy_2GF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-upYA/C1P2yJr4JJFqdunevCzM1k\"",
		"mtime": "2026-10-01T15:37:47.756Z",
		"size": 144,
		"path": "../public/assets/loader-circle-DxSy_2GF.js"
	},
	"/assets/map-pin-BjW5w3Ur.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-uDkihqSrMFOVyGgiv9BpxzrxTeM\"",
		"mtime": "2026-10-01T15:37:47.757Z",
		"size": 259,
		"path": "../public/assets/map-pin-BjW5w3Ur.js"
	},
	"/assets/Match-Cb0Aj3Gr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bdd2-KTBIqVrjIKiTckU6VTzVri523ss\"",
		"mtime": "2026-10-01T15:37:47.720Z",
		"size": 48594,
		"path": "../public/assets/Match-Cb0Aj3Gr.js"
	},
	"/assets/notifications-DjO42KNL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7d-SjMF0OLyMdn8Ax1bQ5iS0hMsHCg\"",
		"mtime": "2026-10-01T15:37:47.757Z",
		"size": 3197,
		"path": "../public/assets/notifications-DjO42KNL.js"
	},
	"/assets/operations-C0-ZYD40.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"372a-Fo3qJ4NW7mYrJhVHW2nrK8PYoG4\"",
		"mtime": "2026-10-01T15:37:47.759Z",
		"size": 14122,
		"path": "../public/assets/operations-C0-ZYD40.js"
	},
	"/assets/OrderCard-BEgDxJIC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"883-NafvipNSqMNks8eTjtJpJAHENXM\"",
		"mtime": "2026-10-01T15:37:47.721Z",
		"size": 2179,
		"path": "../public/assets/OrderCard-BEgDxJIC.js"
	},
	"/assets/orders.index-CKQU70Tc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1766-cGkhd4pUD5jy3EDBkKfFf0WwRrw\"",
		"mtime": "2026-10-01T15:37:47.761Z",
		"size": 5990,
		"path": "../public/assets/orders.index-CKQU70Tc.js"
	},
	"/assets/orders._id-qxGQ6pdx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c69-Dt/fWUw8g5fJTPILzBB/VYvnaHQ\"",
		"mtime": "2026-10-01T15:37:47.759Z",
		"size": 11369,
		"path": "../public/assets/orders._id-qxGQ6pdx.js"
	},
	"/assets/package-check-Cpqljsth.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"244-cErnuWQbq703fjsD6WjzTBEQ8vs\"",
		"mtime": "2026-10-01T15:37:47.763Z",
		"size": 580,
		"path": "../public/assets/package-check-Cpqljsth.js"
	},
	"/assets/package-CI3qzO0j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"174-92uzpczNcafZvao0QKAxOTGDVV0\"",
		"mtime": "2026-10-01T15:37:47.761Z",
		"size": 372,
		"path": "../public/assets/package-CI3qzO0j.js"
	},
	"/assets/PageHeader-BHzfyVCZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f5-n8ENiVZs/fRNpqfXfKNplWWvPo8\"",
		"mtime": "2026-10-01T15:37:47.721Z",
		"size": 501,
		"path": "../public/assets/PageHeader-BHzfyVCZ.js"
	},
	"/assets/PermissionGate-CcD7cpDc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"552-tpcRNGOcGQHdVS+MIK4fObiKnYk\"",
		"mtime": "2026-10-01T15:37:47.723Z",
		"size": 1362,
		"path": "../public/assets/PermissionGate-CcD7cpDc.js"
	},
	"/assets/phone-C4IsOFMb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-mhCTP1iptllNWeiV/PAylmEk+zk\"",
		"mtime": "2026-10-01T15:37:47.763Z",
		"size": 322,
		"path": "../public/assets/phone-C4IsOFMb.js"
	},
	"/assets/products-DEUO-4b8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38fa-i8QDWXDZ2TjwQLbm0ryAfqAt81E\"",
		"mtime": "2026-10-01T15:37:47.765Z",
		"size": 14586,
		"path": "../public/assets/products-DEUO-4b8.js"
	},
	"/assets/profile-DD5OOyPj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eb8-RZwrhN7qhrjyCpmDgpsLi+lDAA4\"",
		"mtime": "2026-10-01T15:37:47.765Z",
		"size": 3768,
		"path": "../public/assets/profile-DD5OOyPj.js"
	},
	"/assets/reset-password-Ddj4swZi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d90-xAzdxWybYins4SH81/PnJSwTGbQ\"",
		"mtime": "2026-10-01T15:37:47.766Z",
		"size": 3472,
		"path": "../public/assets/reset-password-Ddj4swZi.js"
	},
	"/assets/RoleBadge-DgKHYExT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"238-fdwSNroPQvFW7+go6q9OlcKSZ0E\"",
		"mtime": "2026-10-01T15:37:47.724Z",
		"size": 568,
		"path": "../public/assets/RoleBadge-DgKHYExT.js"
	},
	"/assets/routes-CIT-D2q-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dcf-16AWLXJt9DdyUi6RE7OvPusnXq0\"",
		"mtime": "2026-10-01T15:37:47.766Z",
		"size": 3535,
		"path": "../public/assets/routes-CIT-D2q-.js"
	},
	"/assets/sales-CgSKnUB8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"163c-qItxnOQcSg/Oh/hq5kRXl1u/sEg\"",
		"mtime": "2026-10-01T15:37:47.768Z",
		"size": 5692,
		"path": "../public/assets/sales-CgSKnUB8.js"
	},
	"/assets/SearchInput-CuBeWX_G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b2-97rH+xB+Q95gJPsxpx6GhXOiN4o\"",
		"mtime": "2026-10-01T15:37:47.727Z",
		"size": 946,
		"path": "../public/assets/SearchInput-CuBeWX_G.js"
	},
	"/assets/SalesChart-Bz2XXL9c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"63f37-I6WC+yDrcPQ9UB2DFomAXxG0vQk\"",
		"mtime": "2026-10-01T15:37:47.725Z",
		"size": 409399,
		"path": "../public/assets/SalesChart-Bz2XXL9c.js"
	},
	"/assets/services-CbTrrFqk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5dc-wnodnkBbg+C5i9f1yXvYdi2yt2o\"",
		"mtime": "2026-10-01T15:37:47.769Z",
		"size": 54748,
		"path": "../public/assets/services-CbTrrFqk.js"
	},
	"/assets/settings-DaxUYsFr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d4-zZt21NEhnZ0ldjNWC4jV3ZNxCl4\"",
		"mtime": "2026-10-01T15:37:47.770Z",
		"size": 724,
		"path": "../public/assets/settings-DaxUYsFr.js"
	},
	"/assets/StatCard-DM4PKWfb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"460-D3V9D8Tz05/2hPR0ZFvFFUwEKKU\"",
		"mtime": "2026-10-01T15:37:47.727Z",
		"size": 1120,
		"path": "../public/assets/StatCard-DM4PKWfb.js"
	},
	"/assets/states-CSK99sQS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a74-DZ4DlQvISjfxPl7B0JB7F8MViJw\"",
		"mtime": "2026-10-01T15:37:47.771Z",
		"size": 2676,
		"path": "../public/assets/states-CSK99sQS.js"
	},
	"/assets/StatusBadge-CRm3DhxD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57b-YOboiw3iz3p7goHyYd/pO3q8eq0\"",
		"mtime": "2026-10-01T15:37:47.728Z",
		"size": 1403,
		"path": "../public/assets/StatusBadge-CRm3DhxD.js"
	},
	"/assets/styles-BPtuTQrG.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"155e9-Dxu1RrE7AnN80tsoFwyCTvnz/3E\"",
		"mtime": "2026-10-01T15:37:47.784Z",
		"size": 87529,
		"path": "../public/assets/styles-BPtuTQrG.css"
	},
	"/assets/switch-Ca0QDFn3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d7-Wsm+3c1JmqJdBWZRKLnMMfNtEFM\"",
		"mtime": "2026-10-01T15:37:47.771Z",
		"size": 4311,
		"path": "../public/assets/switch-Ca0QDFn3.js"
	},
	"/assets/system-settings-CSgXjSXm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1516-16kTGxXMuWcEuqIkjikqNHx9yA0\"",
		"mtime": "2026-10-01T15:37:47.772Z",
		"size": 5398,
		"path": "../public/assets/system-settings-CSgXjSXm.js"
	},
	"/assets/table-BqSRGl74.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"665-A5aG8+/BjCpcYzSs1GD6S3WltQE\"",
		"mtime": "2026-10-01T15:37:47.774Z",
		"size": 1637,
		"path": "../public/assets/table-BqSRGl74.js"
	},
	"/assets/tabs-CF4GgZxe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e17-ctLvTFt++N5UbbJecYkf1S9tNCo\"",
		"mtime": "2026-10-01T15:37:47.774Z",
		"size": 3607,
		"path": "../public/assets/tabs-CF4GgZxe.js"
	},
	"/assets/textarea-CsDttaNJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"200-icb76MaXjT1QtkpqwEIJKxU2d/Q\"",
		"mtime": "2026-10-01T15:37:47.774Z",
		"size": 512,
		"path": "../public/assets/textarea-CsDttaNJ.js"
	},
	"/assets/truck-Bj6XNUYI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-LsRSI6WxIX1I/PwPEOqN4y2BCoU\"",
		"mtime": "2026-10-01T15:37:47.777Z",
		"size": 406,
		"path": "../public/assets/truck-Bj6XNUYI.js"
	},
	"/assets/useMatch-KGWaNyOR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"479-YUGYYQvqJ33qFFJvSOwzvPxbhzk\"",
		"mtime": "2026-10-01T15:37:47.777Z",
		"size": 1145,
		"path": "../public/assets/useMatch-KGWaNyOR.js"
	},
	"/assets/useMutation-C8YThwCT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"924-BkNGXZhSkI+8C5eYspK1Qi1qMhM\"",
		"mtime": "2026-10-01T15:37:47.779Z",
		"size": 2340,
		"path": "../public/assets/useMutation-C8YThwCT.js"
	},
	"/assets/useQuery-CjVJzCTR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f16-j3RJNjkd8TYPEt0CkXjbse4iA6o\"",
		"mtime": "2026-10-01T15:37:47.779Z",
		"size": 7958,
		"path": "../public/assets/useQuery-CjVJzCTR.js"
	},
	"/assets/users-BBqjSXKb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c74-k16O0Gh7IdhzTMcK+sClV/WyBqg\"",
		"mtime": "2026-10-01T15:37:47.781Z",
		"size": 7284,
		"path": "../public/assets/users-BBqjSXKb.js"
	},
	"/assets/users-OUCHO2gh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"298-BEgZmndW1/1g479xPYZ0wD1nokM\"",
		"mtime": "2026-10-01T15:37:47.781Z",
		"size": 664,
		"path": "../public/assets/users-OUCHO2gh.js"
	},
	"/assets/wallet-UnBLMxKh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-cjEa+c26qia3qoquwCaP3Iu2NuU\"",
		"mtime": "2026-10-01T15:37:47.781Z",
		"size": 286,
		"path": "../public/assets/wallet-UnBLMxKh.js"
	},
	"/assets/website-requests-BB4QuduW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19f3-98yS9hBTsSnUcxdgUIapK956OfE\"",
		"mtime": "2026-10-01T15:37:47.783Z",
		"size": 6643,
		"path": "../public/assets/website-requests-BB4QuduW.js"
	},
	"/assets/x-3y0Nf6Km.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-b+y3N7bzgMv8lTq7aXHTPDUDJVU\"",
		"mtime": "2026-10-01T15:37:47.784Z",
		"size": 154,
		"path": "../public/assets/x-3y0Nf6Km.js"
	},
	"/assets/_authenticated-C6Cu5cb0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"810f-cWHMqJkMG1VEX3w4GX6R4pTwLdM\"",
		"mtime": "2026-10-01T15:37:47.729Z",
		"size": 33039,
		"path": "../public/assets/_authenticated-C6Cu5cb0.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_thzT14 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_thzT14
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
