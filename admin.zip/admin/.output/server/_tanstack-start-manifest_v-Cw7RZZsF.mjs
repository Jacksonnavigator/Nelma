//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cw7RZZsF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/reset-password"
		],
		preloads: [
			"/assets/index-rqflDa6O.js",
			"/assets/services-CbTrrFqk.js",
			"/assets/link-zvcgpv5H.js",
			"/assets/Match-Cb0Aj3Gr.js",
			"/assets/useMatch-KGWaNyOR.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-rqflDa6O.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CIT-D2q-.js",
			"/assets/loader-circle-DxSy_2GF.js",
			"/assets/button-CbHDWFrM.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated.tsx",
		children: [
			"/_authenticated/admin-accounts",
			"/_authenticated/audit-logs",
			"/_authenticated/create-order",
			"/_authenticated/dashboard",
			"/_authenticated/deliveries",
			"/_authenticated/notifications",
			"/_authenticated/operations",
			"/_authenticated/pricing",
			"/_authenticated/products",
			"/_authenticated/profile",
			"/_authenticated/sales",
			"/_authenticated/system-settings",
			"/_authenticated/users",
			"/_authenticated/website-requests",
			"/_authenticated/drivers/$id",
			"/_authenticated/orders/$id",
			"/_authenticated/drivers/",
			"/_authenticated/orders/"
		],
		preloads: [
			"/assets/_authenticated-C6Cu5cb0.js",
			"/assets/useQuery-CjVJzCTR.js",
			"/assets/createLucideIcon-CoTZf2oV.js",
			"/assets/settings-DaxUYsFr.js",
			"/assets/check-Ci8GA_FX.js",
			"/assets/circle-plus-HL2_siJD.js",
			"/assets/circle-Cdnh72AK.js",
			"/assets/users-OUCHO2gh.js",
			"/assets/loader-circle-DxSy_2GF.js",
			"/assets/package-CI3qzO0j.js",
			"/assets/truck-Bj6XNUYI.js",
			"/assets/x-3y0Nf6Km.js",
			"/assets/dist-DlTlzDqh.js",
			"/assets/button-CbHDWFrM.js",
			"/assets/dist-BpS8h7FN.js",
			"/assets/dist-CLQAGs60.js",
			"/assets/es2015-Gk2xCMJo.js",
			"/assets/dist-BnCP_94i.js",
			"/assets/dist-ws-WhAEq.js",
			"/assets/dist-CoyOp6El.js",
			"/assets/dist-GfiyVQyI.js",
			"/assets/RoleBadge-DgKHYExT.js"
		]
	},
	"/reset-password": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Ddj4swZi.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/button-CbHDWFrM.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js"
		]
	},
	"/_authenticated/admin-accounts": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/admin-accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-accounts-BuJmpqDb.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/ContactFields-CGH4mMvE.js",
			"/assets/ConfirmDialog-DDlf9q2c.js",
			"/assets/dialog-DtqQ49Wt.js",
			"/assets/table-BqSRGl74.js"
		]
	},
	"/_authenticated/audit-logs": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/audit-logs.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-logs-CJzpcHhL.js",
			"/assets/FilterBar-Bm6nO-lE.js",
			"/assets/states-CSK99sQS.js",
			"/assets/SearchInput-CuBeWX_G.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/label-kyqZC24D.js",
			"/assets/table-BqSRGl74.js",
			"/assets/DataPagination-B9Ss_vOO.js"
		]
	},
	"/_authenticated/create-order": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/create-order.tsx",
		children: void 0,
		preloads: [
			"/assets/create-order-C78VsTHG.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/states-CSK99sQS.js",
			"/assets/SearchInput-CuBeWX_G.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/dist-CjqWO2QC.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/textarea-CsDttaNJ.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-CaIT85VC.js",
			"/assets/package-check-Cpqljsth.js",
			"/assets/states-CSK99sQS.js",
			"/assets/wallet-UnBLMxKh.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/StatCard-DM4PKWfb.js",
			"/assets/StatusBadge-CRm3DhxD.js",
			"/assets/OrderCard-BEgDxJIC.js",
			"/assets/DriverCard-pSjTQsru.js",
			"/assets/SalesChart-Bz2XXL9c.js"
		]
	},
	"/_authenticated/deliveries": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/deliveries.tsx",
		children: void 0,
		preloads: [
			"/assets/deliveries-Ca8aUVDB.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/states-CSK99sQS.js",
			"/assets/SearchInput-CuBeWX_G.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/table-BqSRGl74.js",
			"/assets/DataPagination-B9Ss_vOO.js",
			"/assets/StatusBadge-CRm3DhxD.js",
			"/assets/AssignmentModal-DxQg3l22.js",
			"/assets/tabs-CF4GgZxe.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-DjO42KNL.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/package-check-Cpqljsth.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/tabs-CF4GgZxe.js"
		]
	},
	"/_authenticated/operations": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/operations.tsx",
		children: void 0,
		preloads: [
			"/assets/operations-C0-ZYD40.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/chevron-down-DvzM3DiY.js",
			"/assets/states-CSK99sQS.js",
			"/assets/map-pin-BjW5w3Ur.js",
			"/assets/wallet-UnBLMxKh.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/dialog-DtqQ49Wt.js",
			"/assets/StatCard-DM4PKWfb.js",
			"/assets/AssignmentModal-DxQg3l22.js"
		]
	},
	"/_authenticated/products": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DEUO-4b8.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/dialog-DtqQ49Wt.js",
			"/assets/textarea-CsDttaNJ.js",
			"/assets/switch-Ca0QDFn3.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-DD5OOyPj.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/ContactFields-CGH4mMvE.js"
		]
	},
	"/_authenticated/sales": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/sales.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-CgSKnUB8.js",
			"/assets/FilterBar-Bm6nO-lE.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/table-BqSRGl74.js",
			"/assets/StatCard-DM4PKWfb.js",
			"/assets/StatusBadge-CRm3DhxD.js",
			"/assets/SalesChart-Bz2XXL9c.js"
		]
	},
	"/_authenticated/system-settings": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/system-settings.tsx",
		children: void 0,
		preloads: [
			"/assets/system-settings-CSgXjSXm.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/textarea-CsDttaNJ.js",
			"/assets/switch-Ca0QDFn3.js"
		]
	},
	"/_authenticated/users": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-BBqjSXKb.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/FilterBar-Bm6nO-lE.js",
			"/assets/states-CSK99sQS.js",
			"/assets/SearchInput-CuBeWX_G.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/ConfirmDialog-DDlf9q2c.js",
			"/assets/dialog-DtqQ49Wt.js",
			"/assets/table-BqSRGl74.js",
			"/assets/DataPagination-B9Ss_vOO.js"
		]
	},
	"/_authenticated/website-requests": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/website-requests.tsx",
		children: void 0,
		preloads: [
			"/assets/website-requests-BB4QuduW.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/states-CSK99sQS.js",
			"/assets/map-pin-BjW5w3Ur.js",
			"/assets/phone-C4IsOFMb.js",
			"/assets/PermissionGate-CcD7cpDc.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/DataPagination-B9Ss_vOO.js"
		]
	},
	"/_authenticated/drivers/$id": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/drivers.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/drivers._id-mx2wf5hT.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/arrow-left-C8CyOHN4.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/ConfirmDialog-DDlf9q2c.js",
			"/assets/table-BqSRGl74.js",
			"/assets/StatCard-DM4PKWfb.js",
			"/assets/StatusBadge-CRm3DhxD.js"
		]
	},
	"/_authenticated/orders/$id": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/orders.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/orders._id-qxGQ6pdx.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/arrow-left-C8CyOHN4.js",
			"/assets/states-CSK99sQS.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/label-kyqZC24D.js",
			"/assets/ConfirmDialog-DDlf9q2c.js",
			"/assets/dialog-DtqQ49Wt.js",
			"/assets/textarea-CsDttaNJ.js",
			"/assets/StatusBadge-CRm3DhxD.js",
			"/assets/AssignmentModal-DxQg3l22.js"
		]
	},
	"/_authenticated/drivers/": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/drivers.index.tsx",
		children: void 0,
		preloads: [
			"/assets/drivers.index-cTrY4-7y.js",
			"/assets/useMutation-C8YThwCT.js",
			"/assets/FilterBar-Bm6nO-lE.js",
			"/assets/states-CSK99sQS.js",
			"/assets/SearchInput-CuBeWX_G.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/input-B1mdbGkY.js",
			"/assets/label-kyqZC24D.js",
			"/assets/dialog-DtqQ49Wt.js",
			"/assets/DataPagination-B9Ss_vOO.js",
			"/assets/DriverCard-pSjTQsru.js"
		]
	},
	"/_authenticated/orders/": {
		filePath: "C:/Users/fivia/Documents/GitHub/Nelma/admin/src/routes/_authenticated/orders.index.tsx",
		children: void 0,
		preloads: [
			"/assets/orders.index-CKQU70Tc.js",
			"/assets/FilterBar-Bm6nO-lE.js",
			"/assets/states-CSK99sQS.js",
			"/assets/SearchInput-CuBeWX_G.js",
			"/assets/PageHeader-BHzfyVCZ.js",
			"/assets/table-BqSRGl74.js",
			"/assets/DataPagination-B9Ss_vOO.js",
			"/assets/StatusBadge-CRm3DhxD.js",
			"/assets/OrderCard-BEgDxJIC.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
