import { i as __toESM } from "../_runtime.mjs";
import { A as shortProductLabel, h as formatDate, m as driversService, p as deliveriesService, x as isApiError } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as SearchInput } from "./SearchInput-P8d-sPCQ.mjs";
import { t as DataPagination } from "./DataPagination-cN6wKWJj.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
import { t as AssignmentModal } from "./AssignmentModal-B8X0f-10.mjs";
import { n as TabsList, r as TabsTrigger, t as Tabs } from "./tabs-DYVPlZaJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deliveries-Cb2QEJ9Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VIEWS = [
	{
		value: "all",
		label: "All"
	},
	{
		value: "unassigned",
		label: "Unassigned"
	},
	{
		value: "assigned",
		label: "Assigned"
	},
	{
		value: "out_for_delivery",
		label: "Out for delivery"
	},
	{
		value: "delivered",
		label: "Delivered"
	}
];
var NEXT_STATUS = {
	assigned: {
		next: "out_for_delivery",
		label: "Mark out for delivery"
	},
	out_for_delivery: {
		next: "delivered",
		label: "Mark delivered"
	}
};
var PAGE_SIZE = 10;
function DeliveriesPage() {
	const { can } = useAuth();
	const qc = useQueryClient();
	const [view, setView] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [target, setTarget] = (0, import_react.useState)(null);
	const query = {
		page,
		pageSize: PAGE_SIZE,
		view,
		...search ? { search } : {}
	};
	const deliveries = useQuery({
		queryKey: ["deliveries", query],
		queryFn: () => deliveriesService.list(query),
		placeholderData: keepPreviousData
	});
	const drivers = useQuery({
		queryKey: ["drivers", "available"],
		queryFn: () => driversService.available()
	});
	const assign = useMutation({
		mutationFn: (driverId) => deliveriesService.assignDriver(target.id, driverId),
		onSuccess: () => {
			toast.success("Driver assigned");
			setTarget(null);
			qc.invalidateQueries();
		},
		onError: (error) => toast.error(isApiError(error) ? error.message : "Could not assign this driver")
	});
	const updateStatus = useMutation({
		mutationFn: (input) => deliveriesService.updateStatus(input.id, input.status),
		onSuccess: () => {
			toast.success("Delivery updated");
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not update this delivery")
	});
	const driverName = (id) => id ? drivers.data?.find((d) => d.id === id)?.fullName ?? id : "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Deliveries",
				description: "Every scheduled delivery, its driver and current field status."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
					value: view,
					onValueChange: (v) => {
						setView(v);
						setPage(1);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, { children: VIEWS.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: v.value,
						children: v.label
					}, v.value)) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
					value: search,
					onChange: (v) => {
						setSearch(v);
						setPage(1);
					},
					placeholder: "Search customer, area or phone"
				})]
			}),
			deliveries.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Deliveries could not be loaded.",
				onRetry: () => deliveries.refetch()
			}) : deliveries.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "table" }) : (deliveries.data?.items.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No deliveries here",
				description: "Nothing matches this view right now."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border border-border bg-card shadow-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Customer" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Location" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Scheduled" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Product" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Driver" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "text-right",
						children: "Actions"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: deliveries.data.items.map((d) => {
					const step = NEXT_STATUS[d.status];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-foreground",
							children: d.customerName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: d.customerPhone
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
							className: "max-w-56",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-foreground",
								children: d.location.area
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: d.location.addressLine
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatDate(d.scheduledDate) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: d.timeWindow
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [
							shortProductLabel(d.product),
							" × ",
							d.quantity
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: driverName(d.driverId) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
							kind: "delivery",
							status: d.status
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2",
								children: [can("deliveries.assignDriver") && d.status !== "delivered" && d.status !== "customer_received" && d.status !== "cancelled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setTarget(d),
									children: d.driverId ? "Reassign" : "Assign"
								}) : null, can("deliveries.update") && step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									disabled: updateStatus.isPending || step.next === "out_for_delivery" && !!d.orderStatus && d.orderStatus !== "processing",
									title: step.next === "out_for_delivery" && d.orderStatus && d.orderStatus !== "processing" ? "Start processing this order before dispatching it." : void 0,
									onClick: () => updateStatus.mutate({
										id: d.id,
										status: step.next
									}),
									children: step.label
								}) : null]
							})
						})
					] }, d.id);
				}) })] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPagination, {
				page: deliveries.data.page,
				pageSize: deliveries.data.pageSize,
				total: deliveries.data.total,
				onPageChange: setPage
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentModal, {
				open: !!target,
				onOpenChange: (open) => !open && setTarget(null),
				drivers: drivers.data ?? [],
				currentDriverId: target?.driverId ?? null,
				loading: assign.isPending,
				onAssign: (driverId) => assign.mutate(driverId)
			})
		]
	});
}
//#endregion
export { DeliveriesPage as component };
