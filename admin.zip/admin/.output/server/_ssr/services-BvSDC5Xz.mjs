//#region node_modules/.nitro/vite/services/ssr/assets/services-BvSDC5Xz.js
/**
* Thin HTTP client for the existing NELMA FastAPI backend.
*
* Base URL comes from VITE_API_URL (see .env.example). Nothing is hardcoded to
* localhost. Screens never call this directly — they go through repositories.
*/
var API_BASE_URL = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_API_URL": "https://nelma-gts5.onrender.com/api/v1",
	"VITE_DATA_MODE": "api"
}["VITE_API_URL"] ?? "";
var DATA_MODE = ({
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_API_URL": "https://nelma-gts5.onrender.com/api/v1",
	"VITE_DATA_MODE": "api"
}["VITE_DATA_MODE"] ?? "mock") === "api" ? "api" : "mock";
var TOKEN_KEY = "nelma.dashboard.token";
var REFRESH_KEY = "nelma.dashboard.refresh";
var SESSION_EXPIRED_EVENT = "nelma:session-expired";
function getRefreshToken() {
	return typeof window === "undefined" ? null : window.localStorage.getItem(REFRESH_KEY);
}
function setRefreshToken(token) {
	if (typeof window === "undefined") return;
	if (token) window.localStorage.setItem(REFRESH_KEY, token);
	else window.localStorage.removeItem(REFRESH_KEY);
}
function clearSession() {
	setAuthToken(null);
	setRefreshToken(null);
}
var refreshPromise = null;
async function refreshSession() {
	if (!refreshPromise) refreshPromise = (async () => {
		const token = getRefreshToken();
		if (!token) throw {
			status: 401,
			message: "Please sign in again."
		};
		const session = await apiRequest("auth/dashboard/refresh", {
			method: "POST",
			body: { refreshToken: token },
			skipRefresh: true
		});
		if (getRefreshToken() !== token) throw {
			status: 409,
			message: "Your session changed. Please try again."
		};
		setAuthToken(session.tokens.accessToken);
		setRefreshToken(session.tokens.refreshToken);
	})().finally(() => {
		refreshPromise = null;
	});
	return refreshPromise;
}
function getAuthToken() {
	if (typeof window === "undefined") return null;
	return window.localStorage.getItem(TOKEN_KEY);
}
function setAuthToken(token) {
	if (typeof window === "undefined") return;
	if (token) window.localStorage.setItem(TOKEN_KEY, token);
	else window.localStorage.removeItem(TOKEN_KEY);
}
function isApiError(value) {
	return typeof value === "object" && value !== null && "status" in value && "message" in value;
}
async function apiRequest(path, options = {}) {
	if (!API_BASE_URL) throw {
		status: 0,
		message: "Set VITE_API_URL in admin/.env before using API mode."
	};
	const url = new URL(path.replace(/^\//, ""), API_BASE_URL.endsWith("/") ? API_BASE_URL : `${API_BASE_URL}/`);
	for (const [key, value] of Object.entries(options.query ?? {})) if (value !== void 0 && value !== null && value !== "") url.searchParams.set(key, String(value));
	const token = getAuthToken();
	let response;
	try {
		response = await fetch(url.toString(), {
			method: options.method ?? "GET",
			headers: {
				"Content-Type": "application/json",
				...token ? { Authorization: `Bearer ${token}` } : {}
			},
			...options.body === void 0 ? {} : { body: JSON.stringify(options.body) },
			...options.signal ? { signal: options.signal } : {}
		});
	} catch {
		if (((options.method ?? "GET") === "GET" || /^\/?auth\/dashboard\/(login|refresh)$/.test(path)) && !options.isRetry && !options.signal?.aborted) {
			await new Promise((resolve) => setTimeout(resolve, 3e3));
			return apiRequest(path, {
				...options,
				isRetry: true
			});
		}
		throw {
			status: 0,
			message: "Unable to reach the server. It may be starting up; please try again in a minute."
		};
	}
	if (response.status === 401 && !options.skipRefresh && !/^\/?auth\/(dashboard\/(login|refresh|logout)|forgot-password|reset-password)$/.test(path)) {
		try {
			if (!getAuthToken() || getAuthToken() === token) await refreshSession();
		} catch (error) {
			if (isApiError(error) && (error.status === 401 || error.status === 403)) {
				clearSession();
				if (typeof window !== "undefined") window.dispatchEvent(new Event(SESSION_EXPIRED_EVENT));
			}
			throw error;
		}
		try {
			return await apiRequest(path, {
				...options,
				skipRefresh: true
			});
		} catch (error) {
			if (isApiError(error) && error.status === 401) {
				clearSession();
				if (typeof window !== "undefined") window.dispatchEvent(new Event(SESSION_EXPIRED_EVENT));
			}
			throw error;
		}
	}
	if (!response.ok) {
		const error = {
			status: response.status,
			message: response.status === 401 ? "Your session has expired. Please sign in again." : response.status === 403 ? "You do not have permission to perform this action." : "Something went wrong. Please try again."
		};
		const payload = await response.json().catch(() => null);
		if (payload && typeof payload === "object" && "detail" in payload) {
			const detail = payload.detail;
			if (detail && typeof detail === "object" && "message" in detail && typeof detail.message === "string") error.message = detail.message;
		}
		throw error;
	}
	if (response.status === 204) return void 0;
	return await response.json();
}
/** Simulated latency for the mock repositories. */
function delay(value, ms = 320) {
	return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}
/** Single reusable Tanzanian Shilling formatter. Never render "$". */
function formatTZS(amount, opts) {
	if (opts?.compact && Math.abs(amount) >= 1e6) return `TZS ${(amount / 1e6).toFixed(1)}M`;
	if (opts?.compact && Math.abs(amount) >= 1e3) return `TZS ${Math.round(amount / 1e3)}K`;
	return `TZS ${new Intl.NumberFormat("en-US").format(Math.round(amount))}`;
}
function formatNumber(value) {
	return new Intl.NumberFormat("en-US").format(value);
}
/** Tanzania has no DST; times are displayed in EAT (UTC+3). */
var APP_TIME_ZONE = "Africa/Dar_es_Salaam";
function businessDate(value = /* @__PURE__ */ new Date()) {
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone: APP_TIME_ZONE,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(value);
	const part = (type) => parts.find((entry) => entry.type === type).value;
	return `${part("year")}-${part("month")}-${part("day")}`;
}
function formatDate(iso) {
	return new Intl.DateTimeFormat("en-GB", {
		day: "2-digit",
		month: "short",
		year: "numeric",
		timeZone: APP_TIME_ZONE
	}).format(new Date(iso));
}
function formatDateTime(iso) {
	return new Intl.DateTimeFormat("en-GB", {
		day: "2-digit",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		hour12: false,
		timeZone: APP_TIME_ZONE
	}).format(new Date(iso));
}
function formatRelative(iso) {
	const diff = Date.now() - new Date(iso).getTime();
	const mins = Math.round(diff / 6e4);
	if (mins < 1) return "just now";
	if (mins < 60) return `${mins}m ago`;
	const hrs = Math.round(mins / 60);
	if (hrs < 24) return `${hrs}h ago`;
	const days = Math.round(hrs / 24);
	if (days < 7) return `${days}d ago`;
	return formatDate(iso);
}
var ORDER_STATUS_LABELS = {
	pending: "Order Received",
	confirmed: "Confirmed",
	processing: "Processing",
	out_for_delivery: "Out for Delivery",
	delivered: "Delivered",
	customer_received: "Customer Received",
	cancelled: "Cancelled"
};
var ORDER_LIFECYCLE = [
	"pending",
	"confirmed",
	"processing",
	"out_for_delivery",
	"delivered",
	"customer_received"
];
var DELIVERY_STATUS_LABELS = {
	unassigned: "Unassigned",
	assigned: "Assigned",
	out_for_delivery: "Out for Delivery",
	delivered: "Delivered",
	customer_received: "Customer Received",
	cancelled: "Cancelled"
};
var PAYMENT_STATUS_LABELS = {
	pending: "Pending",
	paid: "Paid",
	failed: "Failed",
	cancelled: "Cancelled",
	refunded: "Refunded"
};
var PAYMENT_METHOD_LABELS = {
	cash: "Cash",
	mobile_money: "Mobile money"
};
var PRODUCT_LABELS = {
	first_purchase: "New bottle purchase",
	refill: "20L Refill"
};
var PRODUCT_SHORT_LABELS = {
	first_purchase: "First purchase",
	refill: "Refill"
};
/** Label for a product code, preferring the name saved on the order for catalog products. */
function productLabel(code, name) {
	return PRODUCT_LABELS[code] ?? (name || code.replace(/_/g, " "));
}
function shortProductLabel(code) {
	return PRODUCT_SHORT_LABELS[code] ?? code.replace(/_/g, " ");
}
function initials(name) {
	return name.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase() ?? "").join("");
}
/**
* Mock dataset for development/demo only.
* Replaced wholesale by the FastAPI repositories — nothing here is persisted.
*/
var PRICES = {
	first_purchase: 18e3,
	refill: 4e3
};
var day = 864e5;
var now = Date.now();
function iso(offsetMs) {
	return new Date(now + offsetMs).toISOString();
}
function dayISO(offsetDays) {
	const d = new Date(now + offsetDays * day);
	d.setHours(9, 0, 0, 0);
	return d.toISOString();
}
var AREAS = [
	{
		label: "Home",
		area: "Sinza",
		addressLine: "Sinza Mori, off Shekilango Road"
	},
	{
		label: "Home",
		area: "Mikocheni",
		addressLine: "Mikocheni B, Plot 118, Senga Road"
	},
	{
		label: "Office",
		area: "Mbezi",
		addressLine: "Mbezi Beach, Africana Road"
	},
	{
		label: "Home",
		area: "Kinondoni",
		addressLine: "Kinondoni Studio, Ali Hassan Mwinyi Rd"
	},
	{
		label: "Campus",
		area: "Ubungo",
		addressLine: "UDSM Campus, Hall 6 reception"
	},
	{
		label: "Home",
		area: "Tegeta",
		addressLine: "Tegeta Nyuki, house 42"
	}
];
var customers = [
	"John Mwita",
	"Amina Hassan",
	"Neema Joseph",
	"Baraka Mushi",
	"Fatuma Salum",
	"Emmanuel Kileo",
	"Zainabu Ally",
	"Peter Massawe",
	"Grace Mollel",
	"Hamisi Juma",
	"Rehema Kimaro",
	"Daniel Shirima"
].map((fullName, i) => ({
	id: `cus_${(i + 1).toString().padStart(3, "0")}`,
	fullName,
	phone: `+2557${(6e7 + i * 1234567).toString().slice(0, 8)}`,
	savedLocations: [{
		id: `loc_${i}_1`,
		...AREAS[i % AREAS.length],
		instructions: i % 3 === 0 ? "Call on arrival, blue gate" : "Leave with the receptionist",
		coordinates: {
			lat: -6.77 - i * .01,
			lng: 39.22 + i * .01
		}
	}]
}));
var drivers = [
	{
		id: "drv_001",
		fullName: "Salum Rashid",
		phone: "+255712004411",
		status: "active",
		todayAssigned: 6,
		activeDeliveries: 2,
		completedDeliveries: 412,
		available: true
	},
	{
		id: "drv_002",
		fullName: "Joseph Mnyika",
		phone: "+255754110982",
		status: "active",
		todayAssigned: 4,
		activeDeliveries: 1,
		completedDeliveries: 287,
		available: true
	},
	{
		id: "drv_003",
		fullName: "Hawa Mbwana",
		phone: "+255689223114",
		status: "active",
		todayAssigned: 3,
		activeDeliveries: 1,
		completedDeliveries: 198,
		available: true
	},
	{
		id: "drv_004",
		fullName: "Frank Lyimo",
		phone: "+255766338100",
		status: "active",
		todayAssigned: 7,
		activeDeliveries: 3,
		completedDeliveries: 521,
		available: false
	},
	{
		id: "drv_005",
		fullName: "Mariam Kessy",
		phone: "+255715887432",
		status: "inactive",
		todayAssigned: 0,
		activeDeliveries: 0,
		completedDeliveries: 143,
		available: false
	},
	{
		id: "drv_006",
		fullName: "Elias Sanga",
		phone: "+255783551209",
		status: "active",
		todayAssigned: 2,
		activeDeliveries: 0,
		completedDeliveries: 96,
		available: true
	}
];
var adminAccounts = [
	{
		id: "usr_sm_1",
		fullName: "Asha Mrisho",
		email: "asha.mrisho@nelma.example",
		phone: "+255711220044",
		role: "SALES_MANAGER",
		status: "active",
		createdAt: iso(-220 * day),
		lastLoginAt: iso(-72e5)
	},
	{
		id: "usr_sm_2",
		fullName: "Godfrey Temu",
		email: "godfrey.temu@nelma.example",
		phone: "+255712994411",
		role: "SALES_MANAGER",
		status: "active",
		createdAt: iso(-140 * day),
		lastLoginAt: iso(-936e5)
	},
	{
		id: "usr_sm_3",
		fullName: "Lilian Mwakalinga",
		email: "lilian.m@nelma.example",
		phone: "+255755663322",
		role: "SALES_MANAGER",
		status: "inactive",
		createdAt: iso(-320 * day),
		lastLoginAt: iso(-40 * day)
	},
	{
		id: "usr_ad_1",
		fullName: "Omary Nassoro",
		email: "omary.nassoro@nelma.example",
		phone: "+255789112233",
		role: "SYSTEM_ADMIN",
		status: "active",
		createdAt: iso(-400 * day),
		lastLoginAt: iso(-27e5)
	},
	{
		id: "usr_ad_2",
		fullName: "Doreen Kibona",
		email: "doreen.kibona@nelma.example",
		phone: "+255744556677",
		role: "SYSTEM_ADMIN",
		status: "active",
		createdAt: iso(-90 * day),
		lastLoginAt: iso(-5 * day)
	}
];
var WINDOWS = [
	"08:00 – 10:00",
	"10:00 – 12:00",
	"12:00 – 14:00",
	"14:00 – 16:00",
	"16:00 – 18:00"
];
function buildTimeline(status, createdAt) {
	if (status === "cancelled") return [{
		status: "pending",
		at: createdAt
	}, {
		status: "cancelled",
		at: iso(-108e5)
	}];
	const idx = ORDER_LIFECYCLE.indexOf(status);
	return ORDER_LIFECYCLE.map((s, i) => ({
		status: s,
		at: i <= idx ? new Date(new Date(createdAt).getTime() + i * 45 * 6e4).toISOString() : null
	}));
}
var STATUS_PLAN = [
	"pending",
	"pending",
	"pending",
	"pending",
	"pending",
	"confirmed",
	"confirmed",
	"confirmed",
	"processing",
	"processing",
	"processing",
	"processing",
	"out_for_delivery",
	"out_for_delivery",
	"out_for_delivery",
	"delivered",
	"delivered",
	"delivered",
	"delivered",
	"customer_received",
	"customer_received",
	"customer_received",
	"customer_received",
	"customer_received",
	"cancelled"
];
function paymentFor(status, i) {
	if (status === "cancelled") return "cancelled";
	if (status === "customer_received") return i % 9 === 0 ? "pending" : "paid";
	if (status === "delivered") return i % 3 === 0 ? "paid" : "pending";
	return "pending";
}
var orders = Array.from({ length: 64 }, (_, i) => {
	const status = STATUS_PLAN[i % STATUS_PLAN.length];
	const customer = customers[i % customers.length];
	const product = i % 4 === 0 ? "first_purchase" : "refill";
	const quantity = product === "first_purchase" ? 1 + i % 2 : 1 + i % 5;
	const unitPrice = PRICES[product];
	const subtotal = unitPrice * quantity;
	const deliveryCharge = [
		0,
		1500,
		2e3,
		2500
	][i % 4];
	const ageDays = Math.floor(i / 8);
	const createdAt = iso(-(ageDays * day + i % 8 * 2.5 * 36e5));
	const method = "cash";
	const source = i % 7 === 0 ? "SALES_MANAGER_DASHBOARD" : "USER_MOBILE";
	const location = customer.savedLocations[0];
	return {
		id: `ord_${(1e3 + i).toString()}`,
		customer: {
			id: customer.id,
			fullName: customer.fullName,
			phone: customer.phone
		},
		item: {
			product,
			quantity,
			unitPrice,
			subtotal
		},
		status,
		createdAt,
		requestedDeliveryDate: dayISO(i % 5 === 0 ? 1 : -ageDays),
		requestedDeliveryWindow: WINDOWS[i % WINDOWS.length],
		deliveryLocation: location,
		paymentMethod: method,
		paymentStatus: paymentFor(status, i),
		deliveryCharge,
		total: subtotal + deliveryCharge,
		source,
		createdBy: source === "SALES_MANAGER_DASHBOARD" ? {
			id: "usr_sm_1",
			fullName: "Asha Mrisho",
			role: "SALES_MANAGER"
		} : null,
		assignedDriverId: status === "processing" || status === "pending" || status === "confirmed" || status === "cancelled" ? null : drivers[i % 4].id,
		timeline: buildTimeline(status, createdAt)
	};
});
function deliveryStatusFor(order) {
	switch (order.status) {
		case "cancelled": return "cancelled";
		case "out_for_delivery": return "out_for_delivery";
		case "delivered": return "delivered";
		case "customer_received": return "customer_received";
		default: return order.assignedDriverId ? "assigned" : "unassigned";
	}
}
var deliveries = orders.filter((o) => o.status !== "pending" && o.status !== "cancelled").map((o, i) => ({
	id: `dlv_${2e3 + i}`,
	orderId: o.id,
	customerName: o.customer.fullName,
	customerPhone: o.customer.phone,
	location: o.deliveryLocation,
	scheduledDate: o.requestedDeliveryDate,
	timeWindow: o.requestedDeliveryWindow,
	product: o.item.product,
	quantity: o.item.quantity,
	driverId: o.assignedDriverId,
	status: deliveryStatusFor(o)
}));
var pricing = [{
	product: "first_purchase",
	label: PRODUCT_LABELS.first_purchase,
	price: PRICES.first_purchase,
	currency: "TZS",
	updatedAt: iso(-32 * day),
	updatedBy: "Omary Nassoro"
}, {
	product: "refill",
	label: PRODUCT_LABELS.refill,
	price: PRICES.refill,
	currency: "TZS",
	updatedAt: iso(-11 * day),
	updatedBy: "Asha Mrisho"
}];
var notifications = [
	{
		id: "ntf_1",
		kind: "order",
		title: "New order received",
		body: "Amina Hassan ordered 3 × 20L Refill for today, 10:00 – 12:00.",
		createdAt: iso(-72e4),
		read: false,
		audience: ["SALES_MANAGER"]
	},
	{
		id: "ntf_2",
		kind: "delivery",
		title: "Delivery requires assignment",
		body: "4 deliveries scheduled today have no driver assigned.",
		createdAt: iso(-288e4),
		read: false,
		audience: ["SALES_MANAGER", "SYSTEM_ADMIN"]
	},
	{
		id: "ntf_3",
		kind: "payment",
		title: "Payment still pending",
		body: "Cash payment for Baraka Mushi's delivered order is not settled.",
		createdAt: iso(-108e5),
		read: false,
		audience: ["SALES_MANAGER", "SYSTEM_ADMIN"]
	},
	{
		id: "ntf_4",
		kind: "driver",
		title: "Driver unavailable",
		body: "Frank Lyimo marked himself unavailable with 3 active deliveries.",
		createdAt: iso(-18e6),
		read: true,
		audience: ["SALES_MANAGER", "SYSTEM_ADMIN"]
	},
	{
		id: "ntf_5",
		kind: "delivery",
		title: "Delivery completed",
		body: "Salum Rashid completed a delivery in Mikocheni.",
		createdAt: iso(-216e5),
		read: true,
		audience: ["SALES_MANAGER"]
	},
	{
		id: "ntf_6",
		kind: "system",
		title: "Pricing changed",
		body: "Refill price was updated by Asha Mrisho.",
		createdAt: iso(-11 * day),
		read: true,
		audience: ["SYSTEM_ADMIN"]
	},
	{
		id: "ntf_7",
		kind: "system",
		title: "New dashboard account",
		body: "A Sales Manager account was created for Godfrey Temu.",
		createdAt: iso(-14 * day),
		read: true,
		audience: ["SYSTEM_ADMIN"]
	}
];
var auditEvents = [
	{
		id: "aud_1",
		at: iso(-24e5),
		actor: "Asha Mrisho",
		role: "SALES_MANAGER",
		action: "DRIVER_ASSIGNED",
		entity: "Delivery",
		description: "Assigned Salum Rashid to a Mikocheni delivery."
	},
	{
		id: "aud_2",
		at: iso(-72e5),
		actor: "Asha Mrisho",
		role: "SALES_MANAGER",
		action: "ORDER_CREATED",
		entity: "Order",
		description: "Created a phone order for Neema Joseph (2 × 20L Refill)."
	},
	{
		id: "aud_3",
		at: iso(-324e5),
		actor: "Omary Nassoro",
		role: "SYSTEM_ADMIN",
		action: "SETTING_CHANGED",
		entity: "System Settings",
		description: "Updated support phone number."
	},
	{
		id: "aud_4",
		at: iso(-1 * day),
		actor: "Omary Nassoro",
		role: "SYSTEM_ADMIN",
		action: "ACCOUNT_CREATED",
		entity: "Admin Account",
		description: "Created Sales Manager account for Godfrey Temu."
	},
	{
		id: "aud_5",
		at: iso(-2 * day),
		actor: "Doreen Kibona",
		role: "SYSTEM_ADMIN",
		action: "DRIVER_DEACTIVATED",
		entity: "Driver",
		description: "Deactivated driver Mariam Kessy."
	},
	{
		id: "aud_6",
		at: iso(-11 * day),
		actor: "Asha Mrisho",
		role: "SALES_MANAGER",
		action: "PRICE_UPDATED",
		entity: "Pricing",
		description: "Changed 20L Refill price to TZS 4,000."
	},
	{
		id: "aud_7",
		at: iso(-14 * day),
		actor: "Omary Nassoro",
		role: "SYSTEM_ADMIN",
		action: "ACCOUNT_DEACTIVATED",
		entity: "Admin Account",
		description: "Deactivated Sales Manager account Lilian Mwakalinga."
	},
	{
		id: "aud_8",
		at: iso(-18 * day),
		actor: "Doreen Kibona",
		role: "SYSTEM_ADMIN",
		action: "SETTING_CHANGED",
		entity: "System Settings",
		description: "Mobile Money kept disabled (under construction)."
	},
	{
		id: "aud_9",
		at: iso(-21 * day),
		actor: "Godfrey Temu",
		role: "SALES_MANAGER",
		action: "DRIVER_UPDATED",
		entity: "Driver",
		description: "Updated phone number for Elias Sanga."
	},
	{
		id: "aud_10",
		at: iso(-32 * day),
		actor: "Omary Nassoro",
		role: "SYSTEM_ADMIN",
		action: "PRICE_UPDATED",
		entity: "Pricing",
		description: "Changed New bottle purchase price to TZS 18,000."
	}
];
var recentActivity = [
	{
		id: "act_1",
		at: iso(-48e4),
		title: "Order confirmed",
		description: "Refill order for Zainabu Ally moved to Confirmed."
	},
	{
		id: "act_2",
		at: iso(-156e4),
		title: "Driver assigned",
		description: "Joseph Mnyika assigned to a Sinza delivery."
	},
	{
		id: "act_3",
		at: iso(-33e5),
		title: "Delivery completed",
		description: "Hawa Mbwana delivered 4 × 20L Refill in Mbezi."
	},
	{
		id: "act_4",
		at: iso(-54e5),
		title: "Order created",
		description: "Phone order captured for Baraka Mushi."
	},
	{
		id: "act_5",
		at: iso(-9e6),
		title: "Payment settled",
		description: "Cash payment received for a Kinondoni delivery."
	}
];
var adminActivity = [
	{
		id: "aact_1",
		at: iso(-27e5),
		title: "Driver assigned",
		description: "Asha Mrisho assigned Salum Rashid to a delivery."
	},
	{
		id: "aact_2",
		at: iso(-324e5),
		title: "System setting changed",
		description: "Support phone number updated."
	},
	{
		id: "aact_3",
		at: iso(-1 * day),
		title: "Account created",
		description: "Sales Manager account created for Godfrey Temu."
	},
	{
		id: "aact_4",
		at: iso(-2 * day),
		title: "Driver deactivated",
		description: "Mariam Kessy set to inactive."
	}
];
var systemSettings = {
	business: {
		name: "NELMA Drinking Water",
		supportPhone: "+255 700 000 000",
		supportEmail: "support@nelma.example",
		address: "Placeholder address, Dar es Salaam",
		operatingHours: "Mon – Sat, 08:00 – 18:00"
	},
	payments: {
		cashEnabled: true,
		mobileMoneyEnabled: false
	},
	notifications: {
		newOrderAlerts: true,
		deliveryAlerts: true,
		paymentAlerts: true
	},
	delivery: {
		defaultTimeWindows: WINDOWS,
		zones: [{
			id: "nmaist",
			name: "NM-AIST campus",
			fee: 0,
			keywords: [
				"nm-aist",
				"nmaist",
				"nelson mandela"
			]
		}, {
			id: "tengeru",
			name: "Tengeru",
			fee: 0,
			keywords: ["tengeru"]
		}],
		defaultZoneName: "Arusha",
		defaultFee: 0
	}
};
var db = {
	websiteRequests: [{
		id: "web_1",
		kind: "order",
		status: "new",
		name: "Grace Mollel",
		email: "grace@example.com",
		phone: "+255754220011",
		company: "Njiro Dental Clinic",
		customerType: "new",
		city: "Arusha",
		area: "Njiro",
		productCode: "refill",
		productName: "20L Refill",
		quantity: 20,
		address: "Njiro complex, block B",
		message: "Weekly delivery on Mondays, please.",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 72e5)).toISOString(),
		handledAt: null
	}, {
		id: "web_2",
		kind: "contact",
		status: "new",
		name: "Baraka Mushi",
		email: "baraka@example.com",
		phone: null,
		company: null,
		customerType: null,
		city: null,
		area: null,
		productCode: null,
		productName: null,
		quantity: null,
		address: null,
		message: "Do you deliver to Usa River?",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 936e5)).toISOString(),
		handledAt: null
	}].map((r) => ({ ...r })),
	orders: orders.map((o) => ({ ...o })),
	deliveries: deliveries.map((d) => ({ ...d })),
	drivers: drivers.map((d) => ({ ...d })),
	accounts: adminAccounts.map((a) => ({ ...a })),
	products: pricing.map((p, index) => ({
		id: `prd_${p.product}`,
		code: p.product,
		name: p.label,
		description: "",
		price: p.price,
		imageUrl: null,
		isActive: true,
		sortOrder: index,
		orderCount: orders.filter((o) => o.item.product === p.product).length,
		updatedAt: p.updatedAt
	})),
	notifications: notifications.map((n) => ({ ...n })),
	audit: auditEvents.map((a) => ({ ...a })),
	settings: structuredClone(systemSettings)
};
function priceOf(p) {
	return {
		product: p.code,
		label: p.name,
		price: p.price,
		currency: "TZS",
		updatedAt: p.updatedAt,
		updatedBy: "Dashboard"
	};
}
function paginate(items, page = 1, pageSize = 10) {
	const start = (page - 1) * pageSize;
	return {
		items: items.slice(start, start + pageSize),
		page,
		pageSize,
		total: items.length
	};
}
function sameDay(a, b) {
	return new Date(a).toDateString() === new Date(b).toDateString();
}
function todayISO() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function pushAudit(event) {
	db.audit.unshift({
		...event,
		id: `aud_${Date.now()}`,
		at: todayISO()
	});
}
var DEMO_IDENTITIES = [{
	identifier: [
		"asha.mrisho@nelma.example",
		"+255711220044",
		"sales"
	],
	password: "nelma1234",
	user: {
		id: "usr_sm_1",
		fullName: "Asha Mrisho",
		email: "asha.mrisho@nelma.example",
		phone: "+255711220044",
		role: "SALES_MANAGER",
		status: "active"
	}
}, {
	identifier: [
		"omary.nassoro@nelma.example",
		"+255789112233",
		"admin"
	],
	password: "nelma1234",
	user: {
		id: "usr_ad_1",
		fullName: "Omary Nassoro",
		email: "omary.nassoro@nelma.example",
		phone: "+255789112233",
		role: "SYSTEM_ADMIN",
		status: "active"
	}
}];
var SESSION_KEY = "nelma.dashboard.session";
function readSession() {
	if (typeof window === "undefined") return null;
	const raw = window.localStorage.getItem(SESSION_KEY);
	if (!raw) return null;
	try {
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function writeSession(user) {
	if (typeof window === "undefined") return;
	if (user) window.localStorage.setItem(SESSION_KEY, JSON.stringify(user));
	else window.localStorage.removeItem(SESSION_KEY);
}
var mockServices = {
	auth: {
		async changePassword() {
			throw {
				status: 400,
				message: "Password management requires API mode."
			};
		},
		async forgotPassword() {
			throw {
				status: 400,
				message: "Password reset requires API mode."
			};
		},
		async resetPassword() {
			throw {
				status: 400,
				message: "Password reset requires API mode."
			};
		},
		async login(identifier, password) {
			const key = identifier.trim().toLowerCase();
			const match = DEMO_IDENTITIES.find((d) => d.identifier.includes(key));
			if (!match || password !== match.password) throw {
				status: 401,
				message: "Incorrect credentials. Please try again."
			};
			const account = db.accounts.find((a) => a.id === match.user.id);
			if (account?.status === "inactive") throw {
				status: 403,
				message: "This account is inactive. Contact a system administrator."
			};
			const user = account ? { ...account } : match.user;
			await delay(null, 500);
			setAuthToken(`mock.${user.id}`);
			writeSession(user);
			return {
				token: `mock.${user.id}`,
				user
			};
		},
		async logout() {
			setAuthToken(null);
			writeSession(null);
			await delay(null, 120);
		},
		async currentUser() {
			return delay(readSession(), 60);
		},
		async updateProfile(input) {
			const current = readSession();
			if (!current) throw {
				status: 401,
				message: "Not signed in."
			};
			const next = {
				...current,
				...input
			};
			const account = db.accounts.find((a) => a.id === current.id);
			if (account) Object.assign(account, input);
			const identity = DEMO_IDENTITIES.find((d) => d.user.id === current.id);
			if (identity) {
				identity.user = next;
				identity.identifier = [
					input.email.toLowerCase(),
					input.phone,
					...identity.identifier.filter((i) => i === "admin" || i === "sales")
				];
			}
			writeSession(next);
			return delay(next);
		}
	},
	orders: {
		async metrics() {
			const today = todayISO();
			const todays = db.orders.filter((o) => sameDay(o.createdAt, today));
			return delay({
				todayOrders: todays.length,
				pendingOrders: db.orders.filter((o) => o.status === "pending").length,
				processing: db.orders.filter((o) => o.status === "processing").length,
				outForDelivery: db.orders.filter((o) => o.status === "out_for_delivery").length,
				completedToday: todays.filter((o) => o.status === "delivered" || o.status === "customer_received").length,
				todaySales: todays.filter((o) => o.status !== "cancelled").reduce((sum, o) => sum + o.total, 0),
				pendingPayments: db.orders.filter((o) => o.paymentStatus === "pending").length,
				activeDrivers: db.drivers.filter((d) => d.status === "active").length,
				activeSalesManagers: db.accounts.filter((a) => a.role === "SALES_MANAGER" && a.status === "active").length,
				pendingDeliveries: db.deliveries.filter((d) => d.status === "unassigned").length,
				systemStatus: "operational"
			});
		},
		async activity(role) {
			return delay(role === "SYSTEM_ADMIN" ? adminActivity : recentActivity);
		},
		async list(query) {
			let items = [...db.orders];
			if (query.status && query.status !== "all") items = items.filter((o) => o.status === query.status);
			if (query.product && query.product !== "all") items = items.filter((o) => o.item.product === query.product);
			if (query.paymentMethod && query.paymentMethod !== "all") items = items.filter((o) => o.paymentMethod === query.paymentMethod);
			if (query.paymentStatus && query.paymentStatus !== "all") items = items.filter((o) => o.paymentStatus === query.paymentStatus);
			if (query.orderDate) items = items.filter((o) => sameDay(o.createdAt, query.orderDate));
			if (query.deliveryDate) items = items.filter((o) => sameDay(o.requestedDeliveryDate, query.deliveryDate));
			if (query.search) {
				const term = query.search.toLowerCase();
				items = items.filter((o) => o.customer.fullName.toLowerCase().includes(term) || o.customer.phone.includes(term));
			}
			items.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
			return delay(paginate(items, query.page, query.pageSize));
		},
		async get(id) {
			const order = db.orders.find((o) => o.id === id);
			if (!order) throw {
				status: 404,
				message: "This order could not be found."
			};
			return delay(order);
		},
		async create(input, actor) {
			const customer = customers.find((c) => c.id === input.customerId);
			if (!customer) throw {
				status: 400,
				message: "Select a valid customer."
			};
			const price = db.products.find((p) => p.code === input.product)?.price ?? 0;
			const subtotal = price * input.quantity;
			const order = {
				id: `ord_${Date.now()}`,
				customer: {
					id: customer.id,
					fullName: customer.fullName,
					phone: customer.phone
				},
				item: {
					product: input.product,
					quantity: input.quantity,
					unitPrice: price,
					subtotal
				},
				status: "pending",
				createdAt: todayISO(),
				requestedDeliveryDate: input.deliveryDate,
				requestedDeliveryWindow: input.deliveryWindow,
				deliveryLocation: input.deliveryLocation,
				paymentMethod: input.paymentMethod,
				paymentStatus: "pending",
				deliveryCharge: 2e3,
				total: subtotal + 2e3,
				source: "SALES_MANAGER_DASHBOARD",
				createdBy: {
					id: actor.id,
					fullName: actor.fullName,
					role: actor.role
				},
				assignedDriverId: null,
				timeline: ORDER_LIFECYCLE.map((status, i) => ({
					status,
					at: i === 0 ? todayISO() : null
				}))
			};
			db.orders.unshift(order);
			pushAudit({
				actor: actor.fullName,
				role: actor.role,
				action: "ORDER_CREATED",
				entity: "Order",
				description: `Created a dashboard order for ${customer.fullName} (${input.quantity} × ${productLabel(input.product, db.products.find((p) => p.code === input.product)?.name)}).`
			});
			return delay(order, 600);
		},
		async collectCash(id, amount) {
			const order = db.orders.find((o) => o.id === id);
			if (!order || order.paymentMethod !== "cash" || !["delivered", "customer_received"].includes(order.status) || amount !== order.total) throw {
				status: 409,
				message: "Cash cannot be recorded for this order."
			};
			if (order.paymentStatus !== "pending" && !order.cashReceipt) throw {
				status: 409,
				message: "Payment is not pending."
			};
			order.paymentStatus = "paid";
			order.cashReceipt ??= {
				id: `CASH-${id}`,
				amount,
				collectedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			return delay(order);
		},
		async confirm(id) {
			return advance(id, "pending", "confirmed");
		},
		async process(id) {
			return advance(id, "confirmed", "processing");
		},
		async reply(id, body) {
			const order = db.orders.find((o) => o.id === id);
			if (!order) throw {
				status: 404,
				message: "Order not found."
			};
			order.messages = [...order.messages ?? [], {
				id: `msg_${Date.now()}`,
				sender: "nelma",
				body,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			}];
			return delay(structuredClone(order), 300);
		},
		async cancel(id, reason) {
			const order = db.orders.find((o) => o.id === id);
			if (!order) throw {
				status: 404,
				message: "Order not found."
			};
			if ([
				"delivered",
				"customer_received",
				"cancelled"
			].includes(order.status)) throw {
				status: 409,
				message: "Delivered or cancelled orders cannot be cancelled."
			};
			order.status = "cancelled";
			if (order.paymentStatus === "pending") order.paymentStatus = "cancelled";
			order.messages = [...order.messages ?? [], {
				id: `msg_${Date.now()}`,
				sender: "system",
				body: `Cancelled by NELMA: ${reason}`,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			}];
			return delay(structuredClone(order), 400);
		},
		async statusCounts() {
			const counts = /* @__PURE__ */ new Map();
			for (const o of db.orders) counts.set(o.status, (counts.get(o.status) ?? 0) + 1);
			return delay([...counts.entries()].map(([status, count]) => ({
				status,
				count
			})));
		}
	},
	customers: {
		async search(term) {
			const t = term.trim().toLowerCase();
			return delay(!t ? customers.slice(0, 6) : customers.filter((c) => c.fullName.toLowerCase().includes(t) || c.phone.includes(t)), 220);
		},
		async get(id) {
			const customer = customers.find((c) => c.id === id);
			if (!customer) throw {
				status: 404,
				message: "Customer not found."
			};
			return delay(customer);
		}
	},
	deliveries: {
		forOrder: (orderId) => delay(db.deliveries.find((delivery) => delivery.orderId === orderId) ?? null),
		async list(query) {
			let items = [...db.deliveries];
			if (query.view && query.view !== "all") items = items.filter((d) => d.status === query.view);
			if (query.search) {
				const t = query.search.toLowerCase();
				items = items.filter((d) => d.customerName.toLowerCase().includes(t) || d.customerPhone.includes(t) || d.location.area.toLowerCase().includes(t));
			}
			items.sort((a, b) => +new Date(a.scheduledDate) - +new Date(b.scheduledDate));
			return delay(paginate(items, query.page, query.pageSize));
		},
		async get(id) {
			const delivery = db.deliveries.find((d) => d.id === id);
			if (!delivery) throw {
				status: 404,
				message: "Delivery not found."
			};
			return delay(delivery);
		},
		async assignDriver(deliveryId, driverId) {
			const delivery = db.deliveries.find((d) => d.id === deliveryId);
			const driver = db.drivers.find((d) => d.id === driverId);
			if (!delivery || !driver) throw {
				status: 404,
				message: "Delivery or driver not found."
			};
			delivery.driverId = driverId;
			if (delivery.status === "unassigned") delivery.status = "assigned";
			driver.todayAssigned += 1;
			const order = db.orders.find((o) => o.id === delivery.orderId);
			if (order) order.assignedDriverId = driverId;
			return delay({ ...delivery }, 450);
		},
		async updateStatus(deliveryId, status) {
			const delivery = db.deliveries.find((d) => d.id === deliveryId);
			if (!delivery) throw {
				status: 404,
				message: "Delivery not found."
			};
			delivery.status = status;
			const order = db.orders.find((o) => o.id === delivery.orderId);
			if (order) {
				if (status === "out_for_delivery") order.status = "out_for_delivery";
				if (status === "delivered") order.status = "delivered";
				if (order.status === "out_for_delivery" || order.status === "delivered") {
					const idx = ORDER_LIFECYCLE.indexOf(order.status);
					order.timeline = ORDER_LIFECYCLE.map((s, i) => ({
						status: s,
						at: i <= idx ? order.timeline[i]?.at ?? todayISO() : null
					}));
				}
			}
			return delay({ ...delivery }, 400);
		}
	},
	drivers: {
		async list(query) {
			let items = [...db.drivers];
			if (query.status && query.status !== "all") items = items.filter((d) => d.status === query.status);
			if (query.search) {
				const t = query.search.toLowerCase();
				items = items.filter((d) => d.fullName.toLowerCase().includes(t) || d.phone.includes(t));
			}
			return delay(paginate(items, query.page, query.pageSize ?? 20));
		},
		async get(id) {
			const driver = db.drivers.find((d) => d.id === id);
			if (!driver) throw {
				status: 404,
				message: "Driver not found."
			};
			return delay(driver);
		},
		async available() {
			return delay(db.drivers.filter((d) => d.status === "active").map((d) => ({
				...d,
				onDuty: d.onDuty ?? d.available
			})));
		},
		async create(input) {
			const driver = {
				id: `drv_${Date.now()}`,
				fullName: input.fullName,
				phone: input.phone,
				status: "active",
				todayAssigned: 0,
				activeDeliveries: 0,
				completedDeliveries: 0,
				available: true
			};
			db.drivers.unshift(driver);
			return delay(driver, 450);
		},
		async update(id, input) {
			const driver = db.drivers.find((d) => d.id === id);
			if (!driver) throw {
				status: 404,
				message: "Driver not found."
			};
			Object.assign(driver, input);
			if (input.status) driver.available = input.status === "active";
			return delay({ ...driver }, 400);
		},
		async deliveriesFor(driverId) {
			return delay(db.deliveries.filter((d) => d.driverId === driverId));
		}
	},
	sales: { async report(query) {
		const now = Date.now();
		const spanDays = query.period === "today" ? 1 : query.period === "week" ? 7 : 30;
		const from = query.from ? +new Date(query.from) : now - spanDays * 864e5;
		const to = query.to ? +new Date(query.to) : now;
		const inRange = db.orders.filter((o) => {
			const t = +new Date(o.createdAt);
			return t >= from && t <= to;
		});
		const records = inRange.map((o) => ({
			orderId: o.id,
			date: o.createdAt,
			customer: o.customer.fullName,
			product: o.item.product,
			quantity: o.item.quantity,
			paymentMethod: o.paymentMethod,
			paymentStatus: o.paymentStatus,
			total: o.total
		}));
		const active = inRange.filter((o) => o.status !== "cancelled");
		const trendBuckets = /* @__PURE__ */ new Map();
		const buckets = query.period === "today" ? 1 : spanDays;
		for (let i = buckets - 1; i >= 0; i--) {
			const d = /* @__PURE__ */ new Date(now - i * 864e5);
			trendBuckets.set(d.toISOString().slice(0, 10), {
				sales: 0,
				orders: 0
			});
		}
		for (const o of active) {
			const key = new Date(o.createdAt).toISOString().slice(0, 10);
			const bucket = trendBuckets.get(key);
			if (bucket) {
				bucket.sales += o.total;
				bucket.orders += 1;
			}
		}
		const statusCounts = /* @__PURE__ */ new Map();
		for (const o of inRange) statusCounts.set(o.status, (statusCounts.get(o.status) ?? 0) + 1);
		const paymentCounts = /* @__PURE__ */ new Map();
		for (const o of inRange) paymentCounts.set(o.paymentStatus, (paymentCounts.get(o.paymentStatus) ?? 0) + 1);
		const byProduct = (product) => active.filter((o) => o.item.product === product);
		return delay({
			summary: {
				totalSales: active.reduce((s, o) => s + o.total, 0),
				totalOrders: inRange.length,
				unitsSold: active.reduce((s, o) => s + o.item.quantity, 0),
				firstPurchases: byProduct("first_purchase").length,
				refills: byProduct("refill").length,
				completedOrders: inRange.filter((o) => o.status === "delivered" || o.status === "customer_received").length,
				cancelledOrders: inRange.filter((o) => o.status === "cancelled").length,
				cashPayments: inRange.filter((o) => o.paymentMethod === "cash").length,
				pendingPayments: inRange.filter((o) => o.paymentStatus === "pending").length,
				deliveryCharges: active.reduce((s, o) => s + o.deliveryCharge, 0)
			},
			trend: [...trendBuckets.entries()].map(([date, v]) => ({
				date,
				...v
			})),
			productMix: db.products.map((p) => p.code).map((product) => ({
				product,
				label: productLabel(product, db.products.find((p) => p.code === product)?.name),
				orders: byProduct(product).length,
				sales: byProduct(product).reduce((s, o) => s + o.total, 0)
			})),
			statusDistribution: [...statusCounts.entries()].map(([status, count]) => ({
				status,
				count
			})),
			paymentDistribution: [...paymentCounts.entries()].map(([status, count]) => ({
				status,
				count
			})),
			records: records.sort((a, b) => +new Date(b.date) - +new Date(a.date))
		}, 420);
	} },
	pricing: {
		async list() {
			return delay(db.products.filter((p) => p.isActive).map(priceOf));
		},
		async update(product, price, actor) {
			const entry = db.products.find((p) => p.code === product);
			if (!entry) throw {
				status: 404,
				message: "Price configuration not found."
			};
			if (!Number.isFinite(price) || price <= 0) throw {
				status: 400,
				message: "Enter a valid price greater than zero."
			};
			entry.price = Math.round(price);
			entry.updatedAt = todayISO();
			pushAudit({
				actor,
				role: "SALES_MANAGER",
				action: "PRICE_UPDATED",
				entity: "Pricing",
				description: `Changed ${entry.name} price to TZS ${entry.price.toLocaleString("en-US")}.`
			});
			return delay(priceOf(entry), 450);
		}
	},
	products: {
		async list() {
			return delay(db.products.map((p) => ({ ...p })));
		},
		async create(input) {
			const base = input.name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 24) || "product";
			let code = base;
			for (let n = 2; db.products.some((p) => p.code === code); n++) code = `${base}_${n}`;
			const product = {
				id: `prd_${Date.now()}`,
				code,
				name: input.name,
				description: input.description ?? "",
				price: input.price,
				imageUrl: input.imageUrl ?? null,
				isActive: input.isActive ?? true,
				sortOrder: input.sortOrder ?? db.products.length,
				orderCount: 0,
				updatedAt: todayISO()
			};
			db.products.push(product);
			return delay({ ...product }, 400);
		},
		async update(id, input) {
			const product = db.products.find((p) => p.id === id);
			if (!product) throw {
				status: 404,
				message: "Product not found."
			};
			Object.assign(product, input, { updatedAt: todayISO() });
			return delay({ ...product }, 400);
		},
		async uploadImage(id, file) {
			const product = db.products.find((p) => p.id === id);
			if (!product) throw {
				status: 404,
				message: "Product not found."
			};
			product.imageUrl = URL.createObjectURL(file);
			product.updatedAt = todayISO();
			return delay({ ...product }, 600);
		},
		async deliveryFees() {
			const { zones, defaultZoneName, defaultFee } = db.settings.delivery;
			return delay(structuredClone({
				zones,
				defaultZoneName,
				defaultFee
			}));
		},
		async saveDeliveryFees(input) {
			db.settings = {
				...db.settings,
				delivery: {
					...db.settings.delivery,
					...structuredClone(input)
				}
			};
			return delay(structuredClone(input), 350);
		}
	},
	users: {
		async list(query) {
			const everyone = [
				...customers.map((c, i) => ({
					id: c.id,
					fullName: c.fullName,
					phone: c.phone,
					email: null,
					role: "USER",
					isActive: true,
					orderCount: db.orders.filter((o) => o.customer.id === c.id).length,
					createdAt: (/* @__PURE__ */ new Date(Date.now() - (i + 3) * 864e5)).toISOString()
				})),
				...db.drivers.map((d, i) => ({
					id: d.id,
					fullName: d.fullName,
					phone: d.phone,
					email: null,
					role: "DRIVER",
					isActive: d.status === "active",
					orderCount: 0,
					createdAt: (/* @__PURE__ */ new Date(Date.now() - (i + 20) * 864e5)).toISOString()
				})),
				...db.accounts.map((a) => ({
					id: a.id,
					fullName: a.fullName,
					phone: a.phone,
					email: a.email,
					role: a.role,
					isActive: a.status === "active",
					orderCount: 0,
					createdAt: a.createdAt
				}))
			].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
			const roleCounts = {};
			for (const u of everyone) roleCounts[u.role] = (roleCounts[u.role] ?? 0) + 1;
			const term = (query.search ?? "").trim().toLowerCase();
			return delay({
				...paginate(everyone.filter((u) => (!query.role || query.role === "all" || u.role === query.role) && (!query.status || query.status === "all" || u.isActive === (query.status === "active")) && (!term || `${u.fullName} ${u.phone} ${u.email ?? ""}`.toLowerCase().includes(term))), query.page, query.pageSize ?? 25),
				roleCounts
			});
		},
		async setActive(id, active) {
			const account = (await mockServices.users.list({
				page: 1,
				pageSize: 500
			})).items.find((u) => u.id === id);
			if (!account) throw {
				status: 404,
				message: "Account not found."
			};
			const driver = db.drivers.find((d) => d.id === id);
			if (driver) driver.status = active ? "active" : "inactive";
			const staff = db.accounts.find((a) => a.id === id);
			if (staff) staff.status = active ? "active" : "inactive";
			return delay({
				...account,
				isActive: active
			}, 300);
		},
		async setPassword() {
			return delay(void 0, 300);
		}
	},
	adminAccounts: {
		async list() {
			return delay(db.accounts.map((a) => ({ ...a })));
		},
		async create(input) {
			const account = {
				id: `usr_${Date.now()}`,
				fullName: input.fullName,
				email: input.email,
				phone: input.phone,
				role: input.role,
				status: "active",
				createdAt: todayISO(),
				lastLoginAt: null
			};
			db.accounts.unshift(account);
			pushAudit({
				actor: "System Admin",
				role: "SYSTEM_ADMIN",
				action: "ACCOUNT_CREATED",
				entity: "Admin Account",
				description: `Created ${input.role === "SALES_MANAGER" ? "Sales Manager" : "System Admin"} account for ${input.fullName}.`
			});
			return delay(account, 500);
		},
		async update(id, input) {
			const account = db.accounts.find((a) => a.id === id);
			if (!account) throw {
				status: 404,
				message: "Account not found."
			};
			Object.assign(account, input);
			return delay({ ...account }, 400);
		}
	},
	settings: {
		async orderOptions() {
			return delay(structuredClone({
				delivery: db.settings.delivery,
				payments: db.settings.payments
			}));
		},
		async get() {
			return delay(structuredClone(db.settings));
		},
		async update(patch) {
			db.settings = {
				...db.settings,
				...patch,
				delivery: {
					...db.settings.delivery,
					...patch.delivery
				}
			};
			pushAudit({
				actor: "System Admin",
				role: "SYSTEM_ADMIN",
				action: "SETTING_CHANGED",
				entity: "System Settings",
				description: "Updated system configuration."
			});
			return delay(structuredClone(db.settings), 450);
		}
	},
	audit: { async list(query) {
		let items = [...db.audit];
		if (query.actor) {
			const t = query.actor.toLowerCase();
			items = items.filter((a) => a.actor.toLowerCase().includes(t));
		}
		if (query.action && query.action !== "all") items = items.filter((a) => a.action === query.action);
		if (query.entity && query.entity !== "all") items = items.filter((a) => a.entity === query.entity);
		if (query.date) items = items.filter((a) => sameDay(a.at, query.date));
		return delay(paginate(items, query.page, query.pageSize ?? 10));
	} },
	notifications: {
		async list(role) {
			return delay(db.notifications.filter((n) => n.audience.includes(role)).map((n) => ({ ...n })));
		},
		async markRead(id) {
			const item = db.notifications.find((n) => n.id === id);
			if (item) item.read = true;
			await delay(null, 120);
		},
		async markAllRead(role) {
			for (const n of db.notifications) if (n.audience.includes(role)) n.read = true;
			await delay(null, 160);
		}
	},
	operations: {
		async overview() {
			return delay(structuredClone({
				...operations,
				generatedAt: todayISO()
			}));
		},
		async handIn(driverId, paymentIds, amountReceived) {
			const entry = operations.cash.find((c) => c.driverId === driverId);
			const receipts = entry?.receipts.filter((r) => paymentIds.includes(r.paymentId)) ?? [];
			if (!entry || receipts.length !== paymentIds.length) throw {
				status: 409,
				message: "This driver's cash changed. Refresh and count again."
			};
			const expected = receipts.reduce((sum, r) => sum + r.amount, 0);
			if (expected !== amountReceived) throw {
				status: 422,
				message: `You counted ${amountReceived.toLocaleString()} but the receipts add up to ${expected.toLocaleString()}. Count again before confirming.`
			};
			operations.cash = operations.cash.filter((c) => c.driverId !== driverId);
			pushAudit({
				actor: readSession()?.fullName ?? "Demo",
				role: "SALES_MANAGER",
				action: "CASH_HANDED_IN",
				entity: "user",
				description: `Cash handed in by ${entry.driverName}`
			});
			return delay({ settled: expected }, 400);
		},
		async reviewFlag(id) {
			operations.flags = operations.flags.filter((f) => f.id !== id);
			await delay(null, 200);
		}
	},
	websiteRequests: {
		async list(query) {
			const rows = db.websiteRequests.filter((r) => (!query.kind || query.kind === "all" || r.kind === query.kind) && (!query.status || query.status === "all" || r.status === query.status)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
			const fresh = db.websiteRequests.filter((r) => r.status === "new");
			return delay({
				...paginate(rows, query.page, query.pageSize ?? 20),
				newCounts: {
					order: fresh.filter((r) => r.kind === "order").length,
					contact: fresh.filter((r) => r.kind === "contact").length
				}
			});
		},
		async setStatus(id, status) {
			const request = db.websiteRequests.find((r) => r.id === id);
			if (!request) throw {
				status: 404,
				message: "Request not found."
			};
			request.status = status;
			request.handledAt = status === "handled" ? (/* @__PURE__ */ new Date()).toISOString() : null;
			return delay({ ...request }, 300);
		}
	}
};
var minutesAgo = (minutes) => (/* @__PURE__ */ new Date(Date.now() - minutes * 6e4)).toISOString();
var operations = {
	generatedAt: todayISO(),
	cash: [{
		driverId: "drv_001",
		driverName: "Salum Rashid",
		driverPhone: "+255712004411",
		onDuty: true,
		amount: 26e3,
		oldestAt: minutesAgo(310),
		receipts: [{
			paymentId: "pay_m1",
			orderId: null,
			orderNumber: "NELMA-DEMO-000118",
			customerName: "Neema Mushi",
			area: "Sakina",
			amount: 18e3,
			collectedAt: minutesAgo(310)
		}, {
			paymentId: "pay_m2",
			orderId: null,
			orderNumber: "NELMA-DEMO-000124",
			customerName: "Baraka Temba",
			area: "Njiro",
			amount: 8e3,
			collectedAt: minutesAgo(95)
		}]
	}, {
		driverId: "drv_003",
		driverName: "Hawa Mbwana",
		driverPhone: "+255689223114",
		onDuty: false,
		amount: 4e3,
		oldestAt: minutesAgo(1500),
		receipts: [{
			paymentId: "pay_m3",
			orderId: null,
			orderNumber: "NELMA-DEMO-000097",
			customerName: "Grace Lema",
			area: "Kijenge",
			amount: 4e3,
			collectedAt: minutesAgo(1500)
		}]
	}],
	flags: [
		{
			id: "flag_m1",
			at: minutesAgo(40),
			kinds: ["proof_skipped", "far_from_address"],
			detail: "Delivered without the code: customer had no phone. Marked delivered 1,240 m from the saved address",
			driverId: "drv_004",
			driverName: "Frank Lyimo",
			orderId: null,
			orderNumber: "NELMA-DEMO-000131",
			customerName: "Rehema Kweka",
			area: "Themi"
		},
		{
			id: "flag_m2",
			at: minutesAgo(130),
			kinds: ["declined"],
			detail: "Declined: Vehicle problem (flat tyre)",
			driverId: "drv_002",
			driverName: "Joseph Mnyika",
			orderId: null,
			orderNumber: "NELMA-DEMO-000129",
			customerName: "Daudi Shirima",
			area: "Olasiti"
		},
		{
			id: "flag_m3",
			at: minutesAgo(600),
			kinds: ["delivery_issue"],
			detail: "Customer not answering",
			driverId: "drv_001",
			driverName: "Salum Rashid",
			orderId: null,
			orderNumber: "NELMA-DEMO-000102",
			customerName: "Upendo Massawe",
			area: "Sanawari"
		}
	],
	stalled: [{
		kind: "not_accepted",
		since: minutesAgo(52),
		driverId: "drv_006",
		driverName: "Elias Sanga",
		scheduledDate: todayISO().slice(0, 10),
		timeWindow: "12:00 - 16:00",
		orderId: null,
		orderNumber: "NELMA-DEMO-000133",
		customerName: "Janeth Mollel",
		area: "Ngarenaro"
	}, {
		kind: "driver_off_duty",
		since: minutesAgo(180),
		driverId: "drv_004",
		driverName: "Frank Lyimo",
		scheduledDate: todayISO().slice(0, 10),
		timeWindow: "16:00 - 19:00",
		orderId: null,
		orderNumber: "NELMA-DEMO-000127",
		customerName: "Said Mfinanga",
		area: "Moshono"
	}],
	drivers: [
		{
			driverId: "drv_001",
			driverName: "Salum Rashid",
			driverPhone: "+255712004411",
			onTheRoad: 1,
			waiting: 1,
			lastLocation: {
				latitude: -3.3731,
				longitude: 36.6937,
				at: minutesAgo(1)
			}
		},
		{
			driverId: "drv_006",
			driverName: "Elias Sanga",
			driverPhone: "+255783551209",
			onTheRoad: 0,
			waiting: 1,
			lastLocation: {
				latitude: -3.3869,
				longitude: 36.7123,
				at: minutesAgo(26)
			}
		},
		{
			driverId: "drv_002",
			driverName: "Joseph Mnyika",
			driverPhone: "+255754110982",
			onTheRoad: 0,
			waiting: 0,
			lastLocation: null
		}
	]
};
async function advance(id, from, to) {
	const order = db.orders.find((o) => o.id === id);
	if (!order) throw {
		status: 404,
		message: "This order could not be found."
	};
	if (order.status !== from) throw {
		status: 409,
		message: "This order is no longer in the expected state."
	};
	order.status = to;
	const idx = ORDER_LIFECYCLE.indexOf(to);
	order.timeline = ORDER_LIFECYCLE.map((s, i) => ({
		status: s,
		at: i <= idx ? order.timeline[i]?.at ?? todayISO() : null
	}));
	return delay({ ...order }, 450);
}
function dashboardUser(user) {
	if (user.role !== "SYSTEM_ADMIN" && user.role !== "SALES_MANAGER") throw {
		status: 403,
		message: "This account cannot access the dashboard."
	};
	return {
		id: user.id,
		fullName: user.fullName,
		email: user.email ?? "",
		phone: user.phone,
		role: user.role,
		status: user.isActive ? "active" : "inactive"
	};
}
function acceptSession(session) {
	const user = dashboardUser(session.user);
	setAuthToken(session.tokens.accessToken);
	setRefreshToken(session.tokens.refreshToken);
	return {
		token: session.tokens.accessToken,
		user
	};
}
function adminAccount(user) {
	return {
		...dashboardUser(user),
		createdAt: user.createdAt,
		lastLoginAt: null
	};
}
/** Base64 contents of a picked file, without the data: URL prefix. */
function fileToBase64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result).split(",", 2)[1] ?? "");
		reader.onerror = () => reject(reader.error ?? /* @__PURE__ */ new Error("Could not read the image."));
		reader.readAsDataURL(file);
	});
}
/**
* Repository injection point.
*
* VITE_DATA_MODE=mock -> in-memory demo repositories (default)
* VITE_DATA_MODE=api  -> the existing NELMA FastAPI backend
*
* Screens import `services` only. Swapping the data source requires no screen
* changes. The backend remains authoritative for authorization and pricing.
*/
var services = DATA_MODE === "api" ? {
	auth: {
		async login(identifier, password) {
			return acceptSession(await apiRequest("auth/dashboard/login", {
				method: "POST",
				body: {
					identifier,
					password
				}
			}));
		},
		async logout() {
			const refreshToken = getRefreshToken();
			try {
				if (refreshToken) await apiRequest("auth/dashboard/logout", {
					method: "POST",
					body: { refreshToken },
					skipRefresh: true
				});
			} finally {
				clearSession();
			}
		},
		currentUser: async () => getAuthToken() ? dashboardUser(await apiRequest("auth/dashboard/me")) : null,
		updateProfile: async (input) => dashboardUser(await apiRequest("auth/dashboard/me", {
			method: "PATCH",
			body: input
		})),
		changePassword: (input) => apiRequest("auth/dashboard/security", {
			method: "PATCH",
			body: input
		}),
		forgotPassword: (identifier) => apiRequest("auth/forgot-password", {
			method: "POST",
			body: { identifier }
		}),
		resetPassword: (input) => apiRequest("auth/reset-password", {
			method: "POST",
			body: input
		})
	},
	orders: {
		metrics: () => apiRequest("admin/dashboard"),
		activity: (role) => apiRequest("admin/activity", { query: { role } }),
		list: (query) => apiRequest("admin/orders", { query: {
			status: query.status,
			search: query.search,
			product: query.product,
			payment_method: query.paymentMethod,
			payment_status: query.paymentStatus,
			order_date: query.orderDate,
			delivery_date: query.deliveryDate,
			page: query.page,
			page_size: query.pageSize
		} }),
		get: (id) => apiRequest(`admin/orders/${id}`),
		create: (input) => apiRequest("admin/orders", {
			method: "POST",
			body: input
		}),
		collectCash: (id, amount) => apiRequest(`admin/orders/${id}/collect-cash`, {
			method: "POST",
			body: { amount }
		}),
		confirm: (id) => apiRequest(`admin/orders/${id}/confirm`, { method: "POST" }),
		process: (id) => apiRequest(`admin/orders/${id}/process`, { method: "POST" }),
		reply: (id, body) => apiRequest(`admin/orders/${id}/messages`, {
			method: "POST",
			body: { body }
		}),
		cancel: (id, reason) => apiRequest(`admin/orders/${id}/cancel`, {
			method: "POST",
			body: { reason }
		}),
		statusCounts: () => apiRequest("admin/orders/status-counts")
	},
	customers: {
		search: (term) => apiRequest("admin/customers", { query: { search: term } }),
		get: (id) => apiRequest(`admin/customers/${id}`)
	},
	deliveries: {
		forOrder: (orderId) => apiRequest(`admin/deliveries/${orderId}`),
		list: (query) => apiRequest("admin/deliveries", { query: {
			view: query.view,
			search: query.search,
			page: query.page,
			page_size: query.pageSize
		} }),
		get: (id) => apiRequest(`admin/deliveries/${id}`),
		assignDriver: (deliveryId, driverId) => apiRequest(`admin/deliveries/${deliveryId}/assign`, {
			method: "POST",
			body: { driver_id: driverId }
		}),
		updateStatus: (deliveryId, status) => apiRequest(`admin/deliveries/${deliveryId}`, {
			method: "PATCH",
			body: { status }
		})
	},
	drivers: {
		list: (query) => apiRequest("admin/drivers", { query: {
			search: query.search,
			status: query.status,
			page: query.page,
			page_size: query.pageSize
		} }),
		get: (id) => apiRequest(`admin/drivers/${id}`),
		available: () => apiRequest("admin/drivers/available"),
		create: (input) => apiRequest("admin/drivers", {
			method: "POST",
			body: input
		}),
		update: async (id, input) => {
			if (input.status) {
				await apiRequest(`drivers/${id}/${input.status === "active" ? "activate" : "deactivate"}`, { method: "POST" });
				return apiRequest(`admin/drivers/${id}`);
			}
			return apiRequest(`admin/drivers/${id}`, {
				method: "PATCH",
				body: input
			});
		},
		deliveriesFor: (driverId) => apiRequest(`admin/drivers/${driverId}/deliveries`)
	},
	sales: { report: (query) => apiRequest("admin/reports/sales", { query: {
		period: query.period,
		from: query.from,
		to: query.to
	} }) },
	pricing: {
		list: () => apiRequest("admin/pricing"),
		update: (product, price) => apiRequest(`admin/pricing/${product}`, {
			method: "PATCH",
			body: { price }
		})
	},
	products: {
		list: () => apiRequest("admin/products"),
		create: (input) => apiRequest("admin/products", {
			method: "POST",
			body: input
		}),
		update: (id, input) => apiRequest(`admin/products/${id}`, {
			method: "PATCH",
			body: input
		}),
		uploadImage: async (id, file) => apiRequest(`admin/products/${id}/image`, {
			method: "POST",
			body: {
				contentType: file.type,
				data: await fileToBase64(file)
			}
		}),
		deliveryFees: () => apiRequest("admin/delivery-fees"),
		saveDeliveryFees: (input) => apiRequest("admin/delivery-fees", {
			method: "PUT",
			body: input
		})
	},
	users: {
		list: (query) => apiRequest("admin/users", { query: {
			page: query.page,
			page_size: query.pageSize,
			role: query.role,
			status: query.status,
			search: query.search
		} }),
		setActive: (id, active) => apiRequest(`admin/users/${id}/status`, {
			method: "POST",
			body: { active }
		}),
		setPassword: (id, password) => apiRequest(`admin/users/${id}/password`, {
			method: "POST",
			body: { password }
		})
	},
	adminAccounts: {
		list: async () => (await apiRequest("admin/accounts")).map(adminAccount),
		create: async (input) => adminAccount(await apiRequest("admin/accounts", {
			method: "POST",
			body: input
		})),
		update: async (id, input) => {
			if (input.status) return adminAccount(await apiRequest(`admin/accounts/${id}/${input.status === "active" ? "activate" : "deactivate"}`, { method: "POST" }));
			return adminAccount(await apiRequest(`admin/accounts/${id}`, {
				method: "PATCH",
				body: {
					fullName: input.fullName,
					email: input.email,
					phone: input.phone,
					role: input.role
				}
			}));
		}
	},
	settings: {
		get: () => apiRequest("admin/settings"),
		orderOptions: () => apiRequest("admin/order-options"),
		update: (patch) => apiRequest("admin/settings", {
			method: "PATCH",
			body: patch
		})
	},
	audit: { list: (query) => apiRequest("admin/audit-logs", { query: {
		actor: query.actor,
		action: query.action,
		entity: query.entity,
		date: query.date,
		page: query.page,
		page_size: query.pageSize
	} }) },
	notifications: {
		list: (role) => apiRequest("admin/notifications", { query: { role } }),
		markRead: (id) => apiRequest(`admin/notifications/${id}/read`, { method: "POST" }),
		markAllRead: () => apiRequest("admin/notifications/read-all", { method: "POST" })
	},
	operations: {
		overview: () => apiRequest("admin/operations"),
		handIn: (driverId, paymentIds, amountReceived) => apiRequest(`admin/operations/cash/${driverId}/hand-in`, {
			method: "POST",
			body: {
				paymentIds,
				amountReceived
			}
		}),
		reviewFlag: (id) => apiRequest(`admin/operations/flags/${id}/review`, { method: "POST" })
	},
	websiteRequests: {
		list: (query) => apiRequest("admin/website-requests", { query: {
			kind: query.kind,
			status: query.status,
			page: query.page,
			page_size: query.pageSize
		} }),
		setStatus: (id, status) => apiRequest(`admin/website-requests/${id}/status`, {
			method: "POST",
			body: { status }
		})
	}
} : mockServices;
var authService = services.auth;
var ordersService = services.orders;
var customersService = services.customers;
var deliveriesService = services.deliveries;
var driversService = services.drivers;
var salesService = services.sales;
var pricingService = services.pricing;
var productsService = services.products;
var usersService = services.users;
var adminAccountsService = services.adminAccounts;
var settingsService = services.settings;
var auditService = services.audit;
var notificationsService = services.notifications;
var operationsService = services.operations;
var websiteRequestsService = services.websiteRequests;
//#endregion
export { shortProductLabel as A, operationsService as C, productsService as D, productLabel as E, websiteRequestsService as M, salesService as O, notificationsService as S, pricingService as T, formatNumber as _, PAYMENT_METHOD_LABELS as a, initials as b, adminAccountsService as c, businessDate as d, customersService as f, formatDateTime as g, formatDate as h, ORDER_STATUS_LABELS as i, usersService as j, settingsService as k, auditService as l, driversService as m, DELIVERY_STATUS_LABELS as n, PAYMENT_STATUS_LABELS as o, deliveriesService as p, ORDER_LIFECYCLE as r, SESSION_EXPIRED_EVENT as s, DATA_MODE as t, authService as u, formatRelative as v, ordersService as w, isApiError as x, formatTZS as y };
