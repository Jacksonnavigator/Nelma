import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as cn } from "./button-bsxhEVXA.mjs";
import { i as Skeleton } from "./states-eHNfqxIu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatCard-Bxab4anC.js
var import_jsx_runtime = require_jsx_runtime();
var TONES = {
	brand: "bg-primary/10 text-primary",
	green: "bg-success/10 text-success",
	mint: "bg-brand-mint/25 text-foreground",
	warning: "bg-warning/15 text-warning",
	neutral: "bg-muted text-muted-foreground"
};
function StatCard({ label, value, hint, icon: Icon, tone = "brand", loading }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl border border-border bg-card p-4 shadow-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
						children: label
					}),
					loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-2 h-7 w-24" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-2xl font-semibold text-foreground",
						children: value
					}),
					hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: hint
					}) : null
				]
			}), Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-9 shrink-0 items-center justify-center rounded-lg", TONES[tone]),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}) : null]
		})
	});
}
//#endregion
export { StatCard as t };
