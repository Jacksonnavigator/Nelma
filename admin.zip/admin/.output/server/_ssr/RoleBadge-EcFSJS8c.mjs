import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as ROLE_LABELS } from "./useAuth-BIb6Ul2A.mjs";
import { r as cn } from "./button-bsxhEVXA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RoleBadge-EcFSJS8c.js
var import_jsx_runtime = require_jsx_runtime();
function RoleBadge({ role, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-medium", role === "SYSTEM_ADMIN" ? "border-primary/25 bg-primary/10 text-primary" : "border-brand-green/35 bg-brand-green/20 text-foreground", className),
		children: role === "SYSTEM_ADMIN" || role === "SALES_MANAGER" ? ROLE_LABELS[role] : role === "USER" ? "Customer" : role === "DRIVER" ? "Driver" : role === "SYSTEM" ? "System" : role
	});
}
//#endregion
export { RoleBadge as t };
