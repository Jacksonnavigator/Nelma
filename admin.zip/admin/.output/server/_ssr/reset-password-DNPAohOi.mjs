import { i as __toESM } from "../_runtime.mjs";
import { t as DATA_MODE, u as authService, x as isApiError } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-DNPAohOi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPassword() {
	const { signOut } = useAuth();
	const [identifier, setIdentifier] = (0, import_react.useState)("");
	const [resetToken, setToken] = (0, import_react.useState)("");
	const [newPassword, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirm] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	const request = useMutation({
		mutationFn: () => authService.forgotPassword(identifier.trim()),
		onSuccess: () => setSent(true)
	});
	const reset = useMutation({
		mutationFn: () => authService.resetPassword({
			identifier: identifier.trim(),
			resetToken: resetToken.trim(),
			newPassword,
			confirmPassword
		}),
		onSuccess: async () => {
			await signOut().catch(() => void 0);
			setToken("");
			setPassword("");
			setConfirm("");
		}
	});
	const error = request.error ?? reset.error;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md space-y-5 rounded-xl border bg-card p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: "Reset password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Enter your registered email for an email code, or your phone number for an SMS code."
				}),
				DATA_MODE !== "api" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Password reset is available when connected to the backend." }) : reset.isSuccess ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "status",
					children: "Password reset. You can sign in with your new password."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					className: "space-y-4",
					onSubmit: (e) => {
						e.preventDefault();
						if (request.isPending || reset.isPending) return;
						if (!sent) request.mutate();
						else if (newPassword === confirmPassword) reset.mutate();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						disabled: request.isPending || reset.isPending,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "reset-identifier",
									children: "Email or phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "reset-identifier",
									autoComplete: "username",
									required: true,
									minLength: 3,
									value: identifier,
									readOnly: sent,
									onChange: (e) => setIdentifier(e.target.value)
								})]
							}),
							sent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									role: "status",
									className: "text-sm text-muted-foreground",
									children: "If the account exists, a reset code has been sent. Enter it below."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "reset-code",
										children: "Reset code"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "reset-code",
										autoComplete: "one-time-code",
										required: true,
										minLength: 4,
										maxLength: 32,
										value: resetToken,
										onChange: (e) => setToken(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "reset-new",
										children: "New password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "reset-new",
										type: "password",
										autoComplete: "new-password",
										required: true,
										minLength: 8,
										maxLength: 128,
										value: newPassword,
										onChange: (e) => setPassword(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "reset-confirm",
										children: "Confirm new password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "reset-confirm",
										type: "password",
										autoComplete: "new-password",
										required: true,
										minLength: 8,
										value: confirmPassword,
										onChange: (e) => setConfirm(e.target.value)
									})]
								}),
								confirmPassword && newPassword !== confirmPassword && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									role: "alert",
									className: "text-sm text-destructive",
									children: "Passwords must match."
								})
							] }),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "text-sm text-destructive",
								children: isApiError(error) ? error.message : "Please try again."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: request.isPending || reset.isPending || sent && newPassword !== confirmPassword,
								children: sent ? "Reset password" : "Send reset code"
							}),
							sent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								onClick: () => {
									setSent(false);
									request.reset();
									reset.reset();
								},
								children: "Use another account or request a new code"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "block text-sm text-primary underline",
					children: "Back to sign in"
				})
			]
		})
	});
}
//#endregion
export { ResetPassword as component };
