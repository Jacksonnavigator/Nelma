import { i as __toESM } from "../_runtime.mjs";
import { E as productLabel, T as pricingService, d as businessDate, f as customersService, k as settingsService, w as ordersService, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { J as Check, k as Info, z as Circle } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { n as ErrorState, r as LoadingSkeleton } from "./states-eHNfqxIu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as SearchInput } from "./SearchInput-P8d-sPCQ.mjs";
import { t as Textarea } from "./textarea-BlwX1vdP.mjs";
import { n as RadioGroupIndicator, r as RadioGroupItem$1, t as RadioGroup$1 } from "../_libs/radix-ui__react-radio-group.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/create-order-BALo-zcn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RadioGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
		className: cn("grid gap-2", className),
		...props,
		ref
	});
});
RadioGroup.displayName = RadioGroup$1.displayName;
var RadioGroupItem = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem$1, {
		ref,
		className: cn("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupIndicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3.5 w-3.5 fill-primary" })
		})
	});
});
RadioGroupItem.displayName = RadioGroupItem$1.displayName;
var STEPS = [
	"Customer",
	"Product",
	"Delivery",
	"Payment",
	"Review"
];
function Stepper({ step }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-wrap items-center gap-2",
		children: STEPS.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: cn("flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium", i === step ? "border-primary/30 bg-primary/10 text-primary" : i < step ? "border-success/25 bg-success/10 text-success" : "border-border bg-card text-muted-foreground"),
			children: [i < step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: i + 1 }), label]
		}, label))
	});
}
function Panel({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-5 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-4 text-sm font-semibold text-foreground",
			children: title
		}), children]
	});
}
function CreateOrderPage() {
	const { user } = useAuth();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [step, setStep] = (0, import_react.useState)(0);
	const [search, setSearch] = (0, import_react.useState)("");
	const [customer, setCustomer] = (0, import_react.useState)(null);
	const [product, setProduct] = (0, import_react.useState)("refill");
	const [quantity, setQuantity] = (0, import_react.useState)(1);
	const [savedLocationIdx, setSavedLocationIdx] = (0, import_react.useState)(null);
	const [location, setLocation] = (0, import_react.useState)({
		label: "New location",
		area: "",
		addressLine: "",
		instructions: "",
		phone: ""
	});
	const [deliveryDate, setDeliveryDate] = (0, import_react.useState)(() => businessDate());
	const [deliveryWindow, setDeliveryWindow] = (0, import_react.useState)("");
	const [paymentMethod] = (0, import_react.useState)("cash");
	const customers = useQuery({
		queryKey: ["customers", search],
		queryFn: () => customersService.search(search)
	});
	const prices = useQuery({
		queryKey: ["prices"],
		queryFn: () => pricingService.list()
	});
	const settings = useQuery({
		queryKey: ["order-options"],
		queryFn: () => settingsService.orderOptions()
	});
	const windows = settings.data?.delivery.defaultTimeWindows ?? [];
	const selected = prices.data?.find((p) => p.product === product);
	const unitPrice = selected?.price ?? 0;
	(0, import_react.useEffect)(() => {
		const first = prices.data?.[0];
		if (first && !prices.data?.some((p) => p.product === product)) setProduct(first.product);
	}, [prices.data, product]);
	const subtotal = unitPrice * quantity;
	const create = useMutation({
		mutationFn: () => ordersService.create({
			customerId: customer.id,
			product,
			quantity,
			deliveryLocation: {
				label: location.label,
				area: location.area,
				addressLine: location.addressLine,
				...location.instructions ? { instructions: location.instructions } : {},
				...location.phone ? { phone: location.phone } : {}
			},
			deliveryDate,
			deliveryWindow: deliveryWindow || (windows[0] ?? "08:00 – 10:00"),
			paymentMethod
		}, user),
		onSuccess: (order) => {
			toast.success("Order created");
			qc.invalidateQueries();
			navigate({
				to: "/orders/$id",
				params: { id: order.id }
			});
		},
		onError: (error) => toast.error(error && typeof error === "object" && "message" in error ? String(error.message) : "Order could not be created")
	});
	const stepValid = (0, import_react.useMemo)(() => {
		if (step === 0) return !!customer;
		if (step === 1) return Number.isInteger(quantity) && quantity > 0 && !!selected;
		if (step === 2) return windows.length > 0 && !!location.area.trim() && !!location.addressLine.trim() && deliveryDate >= businessDate();
		return true;
	}, [
		step,
		customer,
		quantity,
		location,
		deliveryDate,
		selected,
		windows.length
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Create Order",
				description: "Place an order for a walk-in or phone customer. Pricing comes from the server."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, { step }),
			prices.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Prices could not be loaded. Retry before placing an order.",
				onRetry: () => prices.refetch()
			}),
			settings.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Delivery options could not be loaded.",
				onRetry: () => settings.refetch()
			}),
			customers.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Customers could not be loaded.",
				onRetry: () => customers.refetch()
			}),
			customers.isLoading && step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { rows: 3 }),
			step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Select customer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
					value: search,
					onChange: setSearch,
					placeholder: "Search by name or phone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-2 sm:grid-cols-2",
					children: [(customers.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setCustomer(c);
							setSavedLocationIdx(c.savedLocations.length ? 0 : null);
							setLocation(c.savedLocations[0] ?? {
								label: "New location",
								area: "",
								addressLine: "",
								instructions: "",
								phone: c.phone
							});
						},
						className: cn("rounded-lg border p-3 text-left transition-colors", customer?.id === c.id ? "border-primary bg-primary/5" : "border-border bg-card hover:bg-muted/50"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: c.fullName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: c.phone
						})]
					}, c.id)), customers.data && customers.data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No customers match that search."
					}) : null]
				})]
			}) : null,
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Product and quantity",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
						value: product,
						onValueChange: (v) => setProduct(v),
						className: "grid gap-3 sm:grid-cols-2",
						children: (prices.data ?? []).map(({ product: p, label, price }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
							className: cn("flex cursor-pointer items-start gap-3 rounded-lg border p-3", product === p ? "border-primary bg-primary/5" : "border-border bg-card"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
								value: p,
								className: "mt-1"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium text-foreground",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted-foreground",
								children: [formatTZS(price), " per unit"]
							})] })]
						}, p))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 max-w-40 space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: "Quantity"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							value: quantity,
							onChange: (e) => setQuantity(Math.max(1, Number(e.target.value) || 1))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: [
							"Subtotal ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: formatTZS(subtotal)
							}),
							". Any delivery charge is applied by the backend."
						]
					})
				]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Delivery details",
				children: [customer?.savedLocations.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 grid gap-2 sm:grid-cols-2",
					children: customer.savedLocations.map((loc, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setSavedLocationIdx(i);
							setLocation(loc);
						},
						className: cn("rounded-lg border p-3 text-left", savedLocationIdx === i ? "border-primary bg-primary/5" : "border-border bg-card"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: loc.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								loc.area,
								" · ",
								loc.addressLine
							]
						})]
					}, loc.id ?? i))
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs text-muted-foreground",
								children: "Area"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: location.area,
								onChange: (e) => {
									setSavedLocationIdx(null);
									setLocation({
										...location,
										area: e.target.value
									});
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs text-muted-foreground",
								children: "Contact phone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: location.phone ?? "",
								onChange: (e) => setLocation({
									...location,
									phone: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs text-muted-foreground",
								children: "Address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: location.addressLine,
								onChange: (e) => {
									setSavedLocationIdx(null);
									setLocation({
										...location,
										addressLine: e.target.value
									});
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs text-muted-foreground",
								children: "Delivery instructions"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 3,
								value: location.instructions ?? "",
								onChange: (e) => setLocation({
									...location,
									instructions: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs text-muted-foreground",
								children: "Delivery date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: deliveryDate,
								onChange: (e) => setDeliveryDate(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs text-muted-foreground",
								children: "Time window"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: deliveryWindow || windows[0] || "",
								onChange: (e) => setDeliveryWindow(e.target.value),
								className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
								children: windows.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: w,
									children: w
								}, w))
							})]
						})
					]
				})]
			}) : null,
			step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Payment method",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3 rounded-lg border border-primary bg-primary/5 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: "Cash on delivery"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Cash on delivery. Payment status is tracked separately from delivery."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3 rounded-lg border border-dashed border-border bg-muted/40 p-3 opacity-70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mt-0.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-muted-foreground",
							children: "Mobile money"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Under construction — not yet available."
						})] })]
					})]
				})
			}) : null,
			step === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Review and place order",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Customer",
							value: `${customer?.fullName} · ${customer?.phone}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Product",
							value: selected?.label ?? productLabel(product)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Quantity",
							value: String(quantity)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Unit price",
							value: formatTZS(unitPrice)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Subtotal",
							value: formatTZS(subtotal)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Payment",
							value: "Cash on delivery"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Delivery",
							value: `${location.area} · ${location.addressLine}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
							label: "Scheduled",
							value: `${deliveryDate} · ${deliveryWindow || windows[0] || "—"}`
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: step === 0,
					onClick: () => setStep((s) => s - 1),
					children: "Back"
				}), step < STEPS.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !stepValid,
					onClick: () => setStep((s) => s + 1),
					children: "Continue"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: create.isPending || !customer,
					onClick: () => create.mutate(),
					children: create.isPending ? "Placing order…" : "Place order"
				})]
			})
		]
	});
}
function Summary({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-muted/30 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-sm font-medium text-foreground",
			children: value
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "orders.create",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateOrderPage, {})
});
//#endregion
export { SplitComponent as component };
