import { i as __toESM } from "../_runtime.mjs";
import { A as shortProductLabel, E as productLabel, O as salesService, _ as formatNumber, a as PAYMENT_METHOD_LABELS, h as formatDate, i as ORDER_STATUS_LABELS, o as PAYMENT_STATUS_LABELS, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { I as Download } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as FilterDate, r as FilterSelect, t as FilterBar } from "./FilterBar-BHwBUYK9.mjs";
import { t as StatCard } from "./StatCard-Bxab4anC.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
import { a as PAYMENT_STATUS_COLORS, i as PAYMENT_METHOD_COLORS, n as DistributionChart, o as PRODUCT_COLORS, r as ORDER_STATUS_COLORS, s as SalesTrendChart, t as CountBarChart } from "./SalesChart-CNTf1wVH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sales-Wa1caKud.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var csvCell = (value) => {
	const text = String(value);
	return `"${(/^[=+\-@]/.test(text) ? `'${text}` : text).replace(/"/g, "\"\"")}"`;
};
function paymentMethodShares(records) {
	const counts = /* @__PURE__ */ new Map();
	for (const r of records) counts.set(r.paymentMethod, (counts.get(r.paymentMethod) ?? 0) + 1);
	return [...counts].map(([method, count]) => ({
		label: PAYMENT_METHOD_LABELS[method] ?? method,
		count,
		color: PAYMENT_METHOD_COLORS[method]
	}));
}
function downloadCsv(records, period, from, to) {
	const csv = [[
		"Date",
		"Order",
		"Customer",
		"Product",
		"Quantity",
		"Payment method",
		"Payment status",
		"Total (TZS)"
	], ...records.map((r) => [
		r.date,
		r.orderId,
		r.customer,
		productLabel(r.product),
		r.quantity,
		PAYMENT_METHOD_LABELS[r.paymentMethod] ?? r.paymentMethod,
		r.paymentStatus,
		r.total
	])].map((row) => row.map(csvCell).join(",")).join("\r\n");
	const url = URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }));
	const link = document.createElement("a");
	link.href = url;
	link.download = `nelma-sales-${period === "custom" ? `${from}_to_${to}` : period}.csv`;
	link.click();
	URL.revokeObjectURL(url);
}
function SalesPage() {
	const [period, setPeriod] = (0, import_react.useState)("week");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const query = {
		period,
		...period === "custom" && from ? { from } : {},
		...period === "custom" && to ? { to } : {}
	};
	const report = useQuery({
		queryKey: ["sales", query],
		queryFn: () => salesService.report(query),
		placeholderData: keepPreviousData,
		enabled: period !== "custom" || !!from && !!to && from <= to
	});
	const data = report.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Sales Reports",
				description: "Paid sales use the payment date. Unpaid orders use the order date.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					disabled: !data?.records.length,
					onClick: () => data && downloadCsv(data.records, period, from, to),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "mr-2 size-4" }), " Download CSV"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, {
				onClear: () => {
					setPeriod("week");
					setFrom("");
					setTo("");
				},
				showClear: period !== "week",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
					label: "Period",
					value: period,
					onChange: (v) => setPeriod(v),
					options: [
						{
							value: "today",
							label: "Today"
						},
						{
							value: "week",
							label: "This week"
						},
						{
							value: "month",
							label: "This month"
						},
						{
							value: "custom",
							label: "Custom range"
						}
					]
				}), period === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterDate, {
					label: "From",
					value: from,
					onChange: setFrom
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterDate, {
					label: "To",
					value: to,
					onChange: setTo
				})] }) : null]
			}),
			period === "custom" && (!from || !to || from > to) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "text-sm text-muted-foreground",
				children: "Select both dates, with the start date on or before the end date."
			}) : report.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "The sales report could not be loaded.",
				onRetry: () => report.refetch()
			}) : report.isLoading || !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "cards" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "chart" })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Total sales",
							value: formatTZS(data.summary.totalSales)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Orders",
							value: formatNumber(data.summary.totalOrders),
							tone: "neutral"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Units sold",
							value: formatNumber(data.summary.unitsSold),
							tone: "mint"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Pending payments",
							value: formatNumber(data.summary.pendingPayments),
							tone: "warning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Completed orders",
							value: formatNumber(data.summary.completedOrders),
							tone: "green"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Cancelled orders",
							value: formatNumber(data.summary.cancelledOrders),
							tone: "neutral"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "First purchases",
							value: formatNumber(data.summary.firstPurchases),
							tone: "mint"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Refills",
							value: formatNumber(data.summary.refills),
							tone: "mint"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 xl:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesTrendChart, { data: data.trend.map((p) => ({
							date: formatDate(p.date),
							sales: p.sales
						})) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountBarChart, {
							title: "Product mix",
							dataKey: "orders",
							data: data.productMix.map((p) => ({
								label: p.label,
								orders: p.orders,
								color: PRODUCT_COLORS[p.product]
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DistributionChart, {
							title: "Order status distribution",
							data: data.statusDistribution.map((s) => ({
								label: ORDER_STATUS_LABELS[s.status],
								count: s.count,
								color: ORDER_STATUS_COLORS[s.status]
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DistributionChart, {
							title: "Payment status",
							data: data.paymentDistribution.map((s) => ({
								label: PAYMENT_STATUS_LABELS[s.status] ?? s.status,
								count: s.count,
								color: PAYMENT_STATUS_COLORS[s.status]
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DistributionChart, {
							title: "Payment method",
							data: paymentMethodShares(data.records)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-foreground",
						children: "Sales records"
					}), data.records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No sales in this period",
						description: "Try a wider date range."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-border bg-card shadow-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Date" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Customer" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Product" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Qty" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Payment" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "Total"
							})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: data.records.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap",
								children: formatDate(r.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "font-medium text-foreground",
								children: r.customer
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: shortProductLabel(r.product) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: r.quantity }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: PAYMENT_METHOD_LABELS[r.paymentMethod] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
								kind: "payment",
								status: r.paymentStatus
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								className: "whitespace-nowrap text-right font-medium text-foreground",
								children: formatTZS(r.total)
							})
						] }, r.orderId)) })] })
					})]
				})
			] })
		]
	});
}
//#endregion
export { SalesPage as component };
