import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ContactFields-DqDSQHDE.js
var import_jsx_runtime = require_jsx_runtime();
function ContactFields({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 sm:grid-cols-2",
		children: [
			[
				"fullName",
				"Full name",
				"text"
			],
			[
				"email",
				"Email address",
				"email"
			],
			[
				"phone",
				"Phone number",
				"tel"
			]
		].map(([key, label, type]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: key,
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: key,
				type,
				required: true,
				value: value[key],
				onChange: (e) => onChange({
					...value,
					[key]: e.target.value
				}),
				minLength: key === "fullName" ? 3 : key === "phone" ? 9 : void 0,
				pattern: key === "fullName" ? ".*\\S.*" : key === "phone" ? "[+0-9 \\(\\)\\-]{9,}" : void 0
			})]
		}, key))
	});
}
//#endregion
export { ContactFields as t };
