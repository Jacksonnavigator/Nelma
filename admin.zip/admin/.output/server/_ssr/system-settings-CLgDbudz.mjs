import { i as __toESM } from "../_runtime.mjs";
import { k as settingsService, x as isApiError } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { n as ErrorState, r as LoadingSkeleton } from "./states-eHNfqxIu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Textarea } from "./textarea-BlwX1vdP.mjs";
import { t as Switch } from "./switch-BErL7BqH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/system-settings-CLgDbudz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const qc = useQueryClient();
	const settings = useQuery({
		queryKey: ["settings"],
		queryFn: () => settingsService.get()
	});
	const [draft, setDraft] = (0, import_react.useState)(null);
	const save = useMutation({
		mutationFn: (value) => settingsService.update(value),
		onSuccess: (value) => {
			qc.setQueryData(["settings"], value);
			qc.invalidateQueries({ queryKey: ["order-options"] });
			qc.invalidateQueries({ queryKey: ["audit"] });
			setDraft(null);
			toast.success("Settings saved");
		}
	});
	const value = draft ?? settings.data;
	const dirty = !!draft && JSON.stringify(draft) !== JSON.stringify(settings.data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "System Settings",
			description: "Business details, payments, alerts and delivery preferences."
		}), settings.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "detail" }) : settings.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
			description: "Settings could not be loaded.",
			onRetry: () => settings.refetch()
		}) : value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
			className: "max-w-3xl",
			onSubmit: (e) => {
				e.preventDefault();
				if (dirty && !save.isPending) save.mutate({
					...value,
					business: {
						name: value.business.name.trim(),
						supportPhone: value.business.supportPhone.trim(),
						supportEmail: value.business.supportEmail.trim(),
						address: value.business.address.trim(),
						operatingHours: value.business.operatingHours.trim()
					},
					delivery: { defaultTimeWindows: [...new Set(value.delivery.defaultTimeWindows.map((w) => w.trim()).filter(Boolean))] }
				});
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				disabled: save.isPending,
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border bg-card p-6 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-4 font-semibold",
							children: "Business information"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								[
									"name",
									"Business name",
									"text"
								],
								[
									"supportPhone",
									"Support phone",
									"tel"
								],
								[
									"supportEmail",
									"Support email",
									"email"
								],
								[
									"address",
									"Address",
									"text"
								],
								[
									"operatingHours",
									"Operating hours",
									"text"
								]
							].map(([key, label, type]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: key,
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: key,
									required: true,
									type,
									pattern: type === "text" ? ".*\\S.*" : void 0,
									value: value.business[key],
									onChange: (e) => setDraft({
										...value,
										business: {
											...value.business,
											[key]: e.target.value
										}
									})
								})]
							}, key))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border bg-card p-6 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-4 font-semibold",
								children: "Payment methods"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: [["cashEnabled", "Cash on delivery"], ["mobileMoneyEnabled", "Mobile money (not connected yet)"]].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: key,
										children: label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: key,
										disabled: true,
										checked: value.payments[key],
										onCheckedChange: (checked) => setDraft({
											...value,
											payments: {
												...value.payments,
												[key]: checked
											}
										})
									})]
								}, key))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted-foreground",
								children: "Customers pay cash on delivery. Mobile money appears in the app once a payment provider account (for example Selcom or AzamPay) is connected to the server."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border bg-card p-6 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-4 font-semibold",
							children: "Notifications"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-4",
							children: [
								["newOrderAlerts", "New order alerts"],
								["deliveryAlerts", "Delivery alerts"],
								["paymentAlerts", "Payment alerts"]
							].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: key,
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									id: key,
									checked: value.notifications[key],
									onCheckedChange: (checked) => setDraft({
										...value,
										notifications: {
											...value.notifications,
											[key]: checked
										}
									})
								})]
							}, key))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4 rounded-xl border bg-card p-6 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold",
								children: "Delivery"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									"Delivery fees are set on",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/products",
										className: "font-medium text-primary hover:underline",
										children: "Prices & delivery"
									}),
									", where sales managers can change them too."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "time-windows",
										children: "Default delivery time windows"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "time-windows",
										required: true,
										value: value.delivery.defaultTimeWindows.join("\n"),
										onChange: (e) => setDraft({
											...value,
											delivery: {
												...value.delivery,
												defaultTimeWindows: e.target.value.split("\n")
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "One per line, for example 09:00 - 12:00. Customers pick from these in the app, next to \"As soon as possible\"."
									})
								]
							})
						]
					}),
					save.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: isApiError(save.error) ? save.error.message : "Could not save settings. Please try again."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !dirty || save.isPending || !value.payments.cashEnabled && !value.payments.mobileMoneyEnabled || !value.delivery.defaultTimeWindows.some((w) => w.trim()),
							children: save.isPending ? "Saving..." : "Save settings"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							disabled: !dirty,
							onClick: () => {
								setDraft(null);
								save.reset();
							},
							children: "Cancel"
						})]
					})
				]
			})
		}) : null]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "settings.manage",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {})
});
//#endregion
export { SplitComponent as component };
