import { i as __toESM } from "../_runtime.mjs";
import { g as formatDateTime, l as auditService } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { t as RoleBadge } from "./RoleBadge-EcFSJS8c.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as FilterDate, t as FilterBar } from "./FilterBar-BHwBUYK9.mjs";
import { t as SearchInput } from "./SearchInput-P8d-sPCQ.mjs";
import { t as DataPagination } from "./DataPagination-cN6wKWJj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-logs-BUzDWjG0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Read-only audit trail. Entries can never be edited or deleted here. */
function AuditLogTable({ events }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-xl border border-border bg-card shadow-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Date & time" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Actor" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Role" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Action" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Entity" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Description" })
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: events.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: formatDateTime(event.at)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap font-medium text-foreground",
				children: event.actor
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: event.role }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: event.action
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: event.entity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "min-w-64",
				children: event.description
			})
		] }, event.id)) })] })
	});
}
var PAGE_SIZE = 12;
function AuditLogsPage() {
	const [actor, setActor] = (0, import_react.useState)("");
	const [action, setAction] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const query = {
		page,
		pageSize: PAGE_SIZE,
		...actor ? { actor } : {},
		...action ? { action } : {},
		...date ? { date } : {}
	};
	const events = useQuery({
		queryKey: ["audit", query],
		queryFn: () => auditService.list(query),
		placeholderData: keepPreviousData
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Audit Logs",
				description: "Every recorded action, in order. Entries cannot be edited or deleted."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, {
				onClear: () => {
					setActor("");
					setAction("");
					setDate("");
					setPage(1);
				},
				showClear: actor !== "" || action !== "" || date !== "",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: "Actor"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
							value: actor,
							onChange: (v) => {
								setActor(v);
								setPage(1);
							},
							placeholder: "Search staff name"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: "Action"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
							value: action,
							onChange: (v) => {
								setAction(v);
								setPage(1);
							},
							placeholder: "Search action or entity"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterDate, {
						label: "Date",
						value: date,
						onChange: (v) => {
							setDate(v);
							setPage(1);
						}
					})
				]
			}),
			events.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Audit logs could not be loaded.",
				onRetry: () => events.refetch()
			}) : events.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "table" }) : (events.data?.items.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No audit entries",
				description: "Nothing matches these filters."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditLogTable, { events: events.data.items }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPagination, {
				page: events.data.page,
				pageSize: events.data.pageSize,
				total: events.data.total,
				onPageChange: setPage
			})] })
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "audit.view",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditLogsPage, {})
});
//#endregion
export { SplitComponent as component };
