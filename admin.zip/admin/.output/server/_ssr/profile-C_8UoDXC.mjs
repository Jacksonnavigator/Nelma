import { i as __toESM } from "../_runtime.mjs";
import { t as DATA_MODE, u as authService, x as isApiError } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { t as RoleBadge } from "./RoleBadge-EcFSJS8c.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { t as ContactFields } from "./ContactFields-DqDSQHDE.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-C_8UoDXC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PasswordChange() {
	const { signOut } = useAuth();
	const [currentPassword, setCurrent] = (0, import_react.useState)("");
	const [newPassword, setNew] = (0, import_react.useState)("");
	const [confirmPassword, setConfirm] = (0, import_react.useState)("");
	const mutation = useMutation({
		mutationFn: () => authService.changePassword({
			currentPassword,
			newPassword,
			confirmPassword
		}),
		onSuccess: async () => {
			setCurrent("");
			setNew("");
			setConfirm("");
			toast.success("Password changed. Please sign in again.");
			await signOut().catch(() => void 0);
		}
	});
	if (DATA_MODE !== "api") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Password changes are available when connected to the backend."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
		className: "space-y-4",
		onSubmit: (e) => {
			e.preventDefault();
			if (!mutation.isPending && newPassword === confirmPassword) mutation.mutate();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			disabled: mutation.isPending,
			className: "space-y-4",
			children: [
				[
					[
						"current-password",
						"Current password",
						currentPassword,
						setCurrent
					],
					[
						"new-password",
						"New password",
						newPassword,
						setNew
					],
					[
						"confirm-password",
						"Confirm new password",
						confirmPassword,
						setConfirm
					]
				].map(([id, label, value, update]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: id,
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id,
						type: "password",
						autoComplete: id === "current-password" ? "current-password" : "new-password",
						required: true,
						minLength: 8,
						maxLength: 128,
						value,
						onChange: (e) => update(e.target.value)
					})]
				}, id)),
				confirmPassword && newPassword !== confirmPassword && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-destructive",
					children: "Passwords must match."
				}),
				mutation.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-destructive",
					children: isApiError(mutation.error) ? mutation.error.message : "Could not change password."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: mutation.isPending || !newPassword || newPassword !== confirmPassword,
					children: mutation.isPending ? "Changing..." : "Change password"
				})
			]
		})
	});
}
function ProfilePage() {
	const { user, setUser, signOut } = useAuth();
	const qc = useQueryClient();
	const [draft, setDraft] = (0, import_react.useState)(null);
	const save = useMutation({
		mutationFn: (input) => authService.updateProfile(input),
		onSuccess: (updated) => {
			setUser(updated);
			setDraft(null);
			qc.invalidateQueries({ queryKey: ["accounts"] });
			toast.success("Profile saved");
		}
	});
	if (!user) return null;
	const value = draft ?? user;
	const dirty = [
		"fullName",
		"email",
		"phone"
	].some((key) => value[key] !== user[key]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Profile",
				description: "Manage your personal contact details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl rounded-xl border bg-card p-6 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Your account"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: user.role })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						if (dirty && !save.isPending) save.mutate({
							fullName: value.fullName.trim(),
							email: value.email.trim(),
							phone: value.phone.trim()
						});
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						disabled: save.isPending,
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactFields, {
								value,
								onChange: setDraft
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Your role and account access are managed by a system administrator."
							}),
							save.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "text-sm text-destructive",
								children: isApiError(save.error) ? save.error.message : "Could not save your profile. Please try again."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									disabled: !dirty || save.isPending,
									children: save.isPending ? "Saving..." : "Save profile"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									disabled: !dirty,
									onClick: () => {
										setDraft(null);
										save.reset();
									},
									children: "Cancel"
								})]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-2xl space-y-3 rounded-xl border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Security"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordChange, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							signOut().catch(() => toast.error("Could not sign out. Please try again."));
						},
						children: "Log out"
					})
				]
			})
		]
	});
}
//#endregion
export { ProfilePage as component };
