import { i as __toESM } from "../_runtime.mjs";
import { A as shortProductLabel, h as formatDate, m as driversService, p as deliveriesService } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Q as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-DZsl5SSz.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as StatCard } from "./StatCard-Bxab4anC.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
import { t as Route } from "./drivers._id-CD8L45YW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drivers._id-BPkCpCKO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DriverDetailPage() {
	const { id } = Route.useParams();
	const { can } = useAuth();
	const qc = useQueryClient();
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [deliveryAction, setDeliveryAction] = (0, import_react.useState)(null);
	const updateDelivery = useMutation({
		mutationFn: (delivery) => deliveriesService.updateStatus(delivery.id, delivery.status === "assigned" ? "out_for_delivery" : "delivered"),
		onSuccess: () => {
			toast.success("Delivery updated");
			setDeliveryAction(null);
			qc.invalidateQueries();
		},
		onError: (error) => toast.error(error instanceof Error ? error.message : "Could not update delivery")
	});
	const driver = useQuery({
		queryKey: ["driver", id],
		queryFn: () => driversService.get(id)
	});
	const deliveries = useQuery({
		queryKey: [
			"driver",
			id,
			"deliveries"
		],
		queryFn: () => driversService.deliveriesFor(id)
	});
	(0, import_react.useEffect)(() => {
		if (driver.data) {
			setFullName(driver.data.fullName);
			setPhone(driver.data.phone);
		}
	}, [driver.data]);
	const save = useMutation({
		mutationFn: () => driversService.update(id, {
			fullName: fullName.trim(),
			phone: phone.trim()
		}),
		onSuccess: () => {
			toast.success("Driver details saved");
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not save these details")
	});
	const toggle = useMutation({
		mutationFn: () => driversService.update(id, { status: driver.data?.status === "active" ? "inactive" : "active" }),
		onSuccess: () => {
			toast.success("Driver updated");
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not update this driver")
	});
	if (driver.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		description: "This driver could not be loaded.",
		onRetry: () => driver.refetch()
	});
	if (driver.isLoading || !driver.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "detail" });
	const d = driver.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2 w-fit",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/drivers",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back to drivers"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: d.fullName,
				description: d.phone,
				actions: can("drivers.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: toggle.isPending,
					onClick: () => toggle.mutate(),
					children: d.status === "active" ? "Deactivate driver" : "Activate driver"
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Status",
						value: d.status === "active" ? "Active" : "Inactive",
						tone: "neutral"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Scheduled today",
						value: d.todayAssigned
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active deliveries",
						value: d.activeDeliveries,
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Completed",
						value: d.completedDeliveries,
						tone: "green"
					})
				]
			}),
			can("drivers.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-4 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-foreground",
						children: "Driver details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "edit-name",
								children: "Full name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "edit-name",
								value: fullName,
								onChange: (e) => setFullName(e.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "edit-phone",
								children: "Phone number"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "edit-phone",
								value: phone,
								onChange: (e) => setPhone(e.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						disabled: save.isPending || fullName.trim().length < 3 || phone.trim().length < 9,
						onClick: () => save.mutate(),
						children: "Save changes"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-foreground",
						children: "Assigned deliveries"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: ["Open an order to review its details, prepare it, reassign its driver, or record cash.", can("deliveries.update") ? " Dispatch prepared orders and mark completed deliveries below." : " A Sales Manager manages preparation, dispatch, delivery updates, and cash collection."]
					}),
					deliveries.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
						description: "Deliveries could not be loaded.",
						onRetry: () => deliveries.refetch()
					}) : deliveries.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
						variant: "table",
						rows: 3
					}) : (deliveries.data?.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No deliveries assigned",
						description: "This driver has no deliveries on record."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-border bg-card shadow-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Customer" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Location" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Scheduled" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Product" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Actions" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: deliveries.data.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/orders/$id",
								params: { id: item.orderId },
								className: "font-medium text-primary underline-offset-4 hover:underline",
								children: item.customerName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: item.customerPhone
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
								className: "max-w-56",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.location.area }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: item.location.addressLine
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatDate(item.scheduledDate) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: item.timeWindow
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [
								shortProductLabel(item.product),
								" × ",
								item.quantity
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
								kind: "delivery",
								status: item.status
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									variant: "outline",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/orders/$id",
										params: { id: item.orderId },
										children: "Open order"
									})
								}), can("deliveries.update") && (item.status === "assigned" || item.status === "out_for_delivery") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									disabled: updateDelivery.isPending || item.status === "assigned" && !!item.orderStatus && item.orderStatus !== "processing",
									onClick: () => setDeliveryAction(item),
									children: item.status === "assigned" ? "Mark out for delivery" : "Mark delivered"
								}) : null]
							}), item.status === "assigned" && item.orderStatus && item.orderStatus !== "processing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: "Open the order and complete confirmation and preparation before dispatch."
							}) : null] })
						] }, item.id)) })] })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: deliveryAction !== null,
				onOpenChange: (open) => {
					if (!open) setDeliveryAction(null);
				},
				title: deliveryAction?.status === "assigned" ? "Send order out for delivery?" : "Mark order delivered?",
				description: deliveryAction?.status === "assigned" ? `Confirm ${d.fullName} is leaving with this order for ${deliveryAction.customerName}.` : `Confirm the order has been delivered to ${deliveryAction?.customerName ?? "the customer"}. Cash payment must be recorded separately on the order.`,
				confirmLabel: deliveryAction?.status === "assigned" ? "Mark out for delivery" : "Mark delivered",
				loading: updateDelivery.isPending,
				onConfirm: () => {
					if (deliveryAction) updateDelivery.mutate(deliveryAction);
				}
			})
		]
	});
}
//#endregion
export { DriverDetailPage as component };
