import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as AuthProvider } from "./useAuth-BIb6Ul2A.mjs";
import { A as redirect, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$20 } from "./drivers._id-CD8L45YW.mjs";
import { t as Route$21 } from "./orders._id-D_b07s0R.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BZODiVOL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BPtuTQrG.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$19 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "NELMA | Management Portal" },
			{
				name: "description",
				content: "NELMA Drinking Water staff dashboard for orders, deliveries and sales."
			},
			{
				name: "author",
				content: "NELMA"
			},
			{
				name: "robots",
				content: "noindex, nofollow"
			},
			{
				name: "theme-color",
				content: "#009FE3"
			},
			{
				property: "og:title",
				content: "NELMA | Management Portal"
			},
			{
				property: "og:description",
				content: "NELMA Drinking Water staff dashboard."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:image",
				content: "/icon-512.png"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				sizes: "any"
			},
			{
				rel: "icon",
				href: "/favicon-32x32.png",
				type: "image/png",
				sizes: "32x32"
			},
			{
				rel: "icon",
				href: "/favicon-16x16.png",
				type: "image/png",
				sizes: "16x16"
			},
			{
				rel: "apple-touch-icon",
				href: "/apple-touch-icon.png",
				sizes: "180x180"
			},
			{
				rel: "manifest",
				href: "/site.webmanifest"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$19.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			richColors: true,
			position: "top-right"
		})] })
	});
}
var $$splitComponentImporter$17 = () => import("./routes-BV2em5IH.mjs");
var Route$18 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "NELMA | Sign In" },
		{
			name: "description",
			content: "Sign in to the NELMA drinking water management portal for sales and admin staff."
		},
		{
			property: "og:title",
			content: "NELMA | Sign In"
		},
		{
			property: "og:description",
			content: "Sign in to the NELMA drinking water management portal."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("../_authenticated-BBZbGcg2.mjs");
var Route$17 = createFileRoute("/_authenticated")({
	ssr: false,
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./reset-password-DNPAohOi.mjs");
var Route$16 = createFileRoute("/reset-password")({
	head: () => ({ meta: [{ title: "NELMA | Reset password" }] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./admin-accounts-Wed7ZA3M.mjs");
var Route$15 = createFileRoute("/_authenticated/admin-accounts")({
	head: () => ({ meta: [{ title: "NELMA | Admin Accounts" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./audit-logs-BUzDWjG0.mjs");
var Route$14 = createFileRoute("/_authenticated/audit-logs")({
	head: () => ({ meta: [
		{ title: "NELMA | Audit Logs" },
		{
			name: "description",
			content: "Read-only record of administrative and operational actions in the NELMA portal."
		},
		{
			property: "og:title",
			content: "NELMA | Audit Logs"
		},
		{
			property: "og:description",
			content: "Read-only record of administrative and operational actions in the NELMA portal."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./create-order-BALo-zcn.mjs");
var Route$13 = createFileRoute("/_authenticated/create-order")({
	head: () => ({ meta: [
		{ title: "NELMA | Create order" },
		{
			name: "description",
			content: "Place a walk-in or phone water order on behalf of a NELMA customer."
		},
		{
			property: "og:title",
			content: "NELMA | Create order"
		},
		{
			property: "og:description",
			content: "Place a walk-in or phone water order on behalf of a NELMA customer."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./dashboard-C-s0EPJQ.mjs");
var Route$12 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "NELMA | Dashboard" },
		{
			name: "description",
			content: "Daily orders, deliveries, drivers and sales overview for NELMA staff."
		},
		{
			property: "og:title",
			content: "NELMA | Dashboard"
		},
		{
			property: "og:description",
			content: "Daily orders, deliveries, drivers and sales overview for NELMA staff."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./deliveries-Cb2QEJ9Y.mjs");
var Route$11 = createFileRoute("/_authenticated/deliveries")({
	head: () => ({ meta: [
		{ title: "NELMA | Deliveries" },
		{
			name: "description",
			content: "Assign drivers and track NELMA water deliveries through to customer receipt."
		},
		{
			property: "og:title",
			content: "NELMA | Deliveries"
		},
		{
			property: "og:description",
			content: "Assign drivers and track NELMA water deliveries through to customer receipt."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./notifications-Bw5ERqh-.mjs");
var Route$10 = createFileRoute("/_authenticated/notifications")({
	head: () => ({ meta: [
		{ title: "NELMA | Notifications" },
		{
			name: "description",
			content: "Operational alerts for NELMA orders, deliveries, payments and system events."
		},
		{
			property: "og:title",
			content: "NELMA | Notifications"
		},
		{
			property: "og:description",
			content: "Operational alerts for NELMA orders, deliveries, payments and system events."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./operations-vlk48hbz.mjs");
var Route$9 = createFileRoute("/_authenticated/operations")({
	head: () => ({ meta: [{ title: "NELMA | Operations" }, {
		name: "description",
		content: "Cash held by drivers, deliveries that need a second look and stalled assignments."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
/** Cash held this long is worth a phone call. */
/** A position older than this is shown as stale: the app is closed or the phone lost signal. */
var Route$8 = createFileRoute("/_authenticated/pricing")({ beforeLoad: () => {
	throw redirect({ to: "/products" });
} });
var $$splitComponentImporter$7 = () => import("./products-DpochkYV.mjs");
var Route$7 = createFileRoute("/_authenticated/products")({
	head: () => ({ meta: [{ title: "NELMA | Products" }, {
		name: "description",
		content: "Add NELMA products and set their names, prices and pictures."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./profile-C_8UoDXC.mjs");
var Route$6 = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [{ title: "NELMA | Profile" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./sales-Wa1caKud.mjs");
var Route$5 = createFileRoute("/_authenticated/sales")({
	head: () => ({ meta: [
		{ title: "NELMA | Sales Reports" },
		{
			name: "description",
			content: "Sales performance, product mix and payment breakdown for NELMA water orders."
		},
		{
			property: "og:title",
			content: "NELMA | Sales Reports"
		},
		{
			property: "og:description",
			content: "Sales performance, product mix and payment breakdown for NELMA water orders."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./system-settings-CLgDbudz.mjs");
var Route$4 = createFileRoute("/_authenticated/system-settings")({
	head: () => ({ meta: [{ title: "NELMA | System Settings" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./users-Bb-2mFKZ.mjs");
var Route$3 = createFileRoute("/_authenticated/users")({
	head: () => ({ meta: [{ title: "NELMA | Users" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./website-requests-DTQmXqa5.mjs");
var Route$2 = createFileRoute("/_authenticated/website-requests")({
	head: () => ({ meta: [{ title: "NELMA | Website requests" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./drivers.index-TDIFkeA7.mjs");
var Route$1 = createFileRoute("/_authenticated/drivers/")({
	head: () => ({ meta: [
		{ title: "NELMA | Drivers" },
		{
			name: "description",
			content: "Manage NELMA delivery drivers, their availability and delivery workload."
		},
		{
			property: "og:title",
			content: "NELMA | Drivers"
		},
		{
			property: "og:description",
			content: "Manage NELMA delivery drivers, their availability and delivery workload."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./orders.index-D_KwgpVG.mjs");
var Route = createFileRoute("/_authenticated/orders/")({
	head: () => ({ meta: [
		{ title: "NELMA | Orders" },
		{
			name: "description",
			content: "Search, filter and process NELMA drinking water orders."
		},
		{
			property: "og:title",
			content: "NELMA | Orders"
		},
		{
			property: "og:description",
			content: "Search, filter and process NELMA water orders."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$18.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$19
});
var AuthenticatedRoute = Route$17.update({
	id: "/_authenticated",
	getParentRoute: () => Route$19
});
var ResetPasswordRoute = Route$16.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$19
});
var AuthenticatedAdminAccountsRoute = Route$15.update({
	id: "/admin-accounts",
	path: "/admin-accounts",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedAuditLogsRoute = Route$14.update({
	id: "/audit-logs",
	path: "/audit-logs",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedCreateOrderRoute = Route$13.update({
	id: "/create-order",
	path: "/create-order",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedDashboardRoute = Route$12.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedDeliveriesRoute = Route$11.update({
	id: "/deliveries",
	path: "/deliveries",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedNotificationsRoute = Route$10.update({
	id: "/notifications",
	path: "/notifications",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOperationsRoute = Route$9.update({
	id: "/operations",
	path: "/operations",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedPricingRoute = Route$8.update({
	id: "/pricing",
	path: "/pricing",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedProductsRoute = Route$7.update({
	id: "/products",
	path: "/products",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedProfileRoute = Route$6.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedSalesRoute = Route$5.update({
	id: "/sales",
	path: "/sales",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedSystemSettingsRoute = Route$4.update({
	id: "/system-settings",
	path: "/system-settings",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedUsersRoute = Route$3.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedWebsiteRequestsRoute = Route$2.update({
	id: "/website-requests",
	path: "/website-requests",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedDriversIndexRoute = Route$1.update({
	id: "/drivers/",
	path: "/drivers/",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedDriversIdRoute = Route$20.update({
	id: "/drivers/$id",
	path: "/drivers/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOrdersIndexRoute = Route.update({
	id: "/orders/",
	path: "/orders/",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedRouteChildren = {
	AuthenticatedAdminAccountsRoute,
	AuthenticatedAuditLogsRoute,
	AuthenticatedCreateOrderRoute,
	AuthenticatedDashboardRoute,
	AuthenticatedDeliveriesRoute,
	AuthenticatedNotificationsRoute,
	AuthenticatedOperationsRoute,
	AuthenticatedPricingRoute,
	AuthenticatedProductsRoute,
	AuthenticatedProfileRoute,
	AuthenticatedSalesRoute,
	AuthenticatedSystemSettingsRoute,
	AuthenticatedUsersRoute,
	AuthenticatedWebsiteRequestsRoute,
	AuthenticatedDriversIdRoute,
	AuthenticatedOrdersIdRoute: Route$21.update({
		id: "/orders/$id",
		path: "/orders/$id",
		getParentRoute: () => AuthenticatedRoute
	}),
	AuthenticatedDriversIndexRoute,
	AuthenticatedOrdersIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRoute: AuthenticatedRoute._addFileChildren(AuthenticatedRouteChildren),
	ResetPasswordRoute
};
var routeTree = Route$19._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
