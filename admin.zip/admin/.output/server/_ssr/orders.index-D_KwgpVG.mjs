import { i as __toESM } from "../_runtime.mjs";
import { D as productsService, E as productLabel, a as PAYMENT_METHOD_LABELS, g as formatDateTime, h as formatDate, i as ORDER_STATUS_LABELS, o as PAYMENT_STATUS_LABELS, w as ordersService, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { H as CirclePlus } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as FilterDate, r as FilterSelect, t as FilterBar } from "./FilterBar-BHwBUYK9.mjs";
import { t as SearchInput } from "./SearchInput-P8d-sPCQ.mjs";
import { t as DataPagination } from "./DataPagination-cN6wKWJj.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
import { t as OrderCard } from "./OrderCard-CKNOPI7n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders.index-D_KwgpVG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Desktop/tablet order table. Order identifiers are deliberately not shown as
* a column — the customer is the primary label.
*/
function OrderTable({ orders, sortKey, sortDir, onSort }) {
	const sortLabel = (key, label) => onSort ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onSort(key),
		className: "inline-flex items-center gap-1 font-medium hover:text-foreground",
		children: [label, sortKey === key ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			children: sortDir === "asc" ? "▲" : "▼"
		}) : null]
	}) : label;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-xl border border-border bg-card shadow-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Customer" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Phone" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Product" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				className: "text-right",
				children: "Qty"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: sortLabel("createdAt", "Ordered") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: sortLabel("requestedDeliveryDate", "Delivery") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Time window" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Payment" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Payment status" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				className: "text-right",
				children: sortLabel("total", "Total")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				className: "text-right",
				children: "Action"
			})
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "font-medium text-foreground",
				children: order.customer.fullName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: order.customer.phone
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: productLabel(order.item.product, order.item.productName)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: order.item.quantity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: formatDateTime(order.createdAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: formatDate(order.requestedDeliveryDate)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: order.requestedDeliveryWindow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: PAYMENT_METHOD_LABELS[order.paymentMethod] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
				kind: "payment",
				status: order.paymentStatus
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap text-right tabular-nums",
				children: formatTZS(order.total)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
				kind: "order",
				status: order.status
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/orders/$id",
						params: { id: order.id },
						children: "View"
					})
				})
			})
		] }, order.id)) })] })
	});
}
var PAGE_SIZE = 10;
function OrdersPage() {
	const { can } = useAuth();
	const [page, setPage] = (0, import_react.useState)(1);
	const [search, setSearch] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [product, setProduct] = (0, import_react.useState)("all");
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("all");
	const [paymentStatus, setPaymentStatus] = (0, import_react.useState)("all");
	const [orderDate, setOrderDate] = (0, import_react.useState)("");
	const [deliveryDate, setDeliveryDate] = (0, import_react.useState)("");
	const [sortKey, setSortKey] = (0, import_react.useState)("createdAt");
	const [sortDir, setSortDir] = (0, import_react.useState)("desc");
	const query = {
		page,
		pageSize: PAGE_SIZE,
		...search ? { search } : {},
		status,
		product,
		paymentMethod,
		paymentStatus,
		...orderDate ? { orderDate } : {},
		...deliveryDate ? { deliveryDate } : {}
	};
	const orders = useQuery({
		queryKey: ["orders", query],
		queryFn: () => ordersService.list(query),
		placeholderData: keepPreviousData
	});
	const products = useQuery({
		queryKey: ["products"],
		queryFn: () => productsService.list()
	});
	const sorted = (0, import_react.useMemo)(() => {
		const items = [...orders.data?.items ?? []];
		items.sort((a, b) => {
			const dir = sortDir === "asc" ? 1 : -1;
			if (sortKey === "total") return (a.total - b.total) * dir;
			const av = sortKey === "createdAt" ? a.createdAt : a.requestedDeliveryDate;
			const bv = sortKey === "createdAt" ? b.createdAt : b.requestedDeliveryDate;
			return (+new Date(av) - +new Date(bv)) * dir;
		});
		return items;
	}, [
		orders.data,
		sortKey,
		sortDir
	]);
	const filtersActive = !!search || status !== "all" || product !== "all" || paymentMethod !== "all" || paymentStatus !== "all" || !!orderDate || !!deliveryDate;
	function clearFilters() {
		setSearch("");
		setStatus("all");
		setProduct("all");
		setPaymentMethod("all");
		setPaymentStatus("all");
		setOrderDate("");
		setDeliveryDate("");
		setPage(1);
	}
	function onSort(key) {
		if (key === sortKey) setSortDir((d) => d === "asc" ? "desc" : "asc");
		else {
			setSortKey(key);
			setSortDir("desc");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Orders",
				description: "All customer water orders from the mobile app and the sales desk.",
				actions: can("orders.create") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/create-order",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "mr-2 size-4" }), " Create Order"]
					})
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
					value: search,
					onChange: (v) => {
						setSearch(v);
						setPage(1);
					},
					placeholder: "Search customer name or phone"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, {
				onClear: clearFilters,
				showClear: filtersActive,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						label: "Status",
						value: status,
						onChange: (v) => {
							setStatus(v);
							setPage(1);
						},
						options: [{
							value: "all",
							label: "All statuses"
						}, ...Object.keys(ORDER_STATUS_LABELS).map((s) => ({
							value: s,
							label: ORDER_STATUS_LABELS[s]
						}))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						label: "Product",
						value: product,
						onChange: (v) => {
							setProduct(v);
							setPage(1);
						},
						options: [{
							value: "all",
							label: "All products"
						}, ...(products.data ?? []).map((p) => ({
							value: p.code,
							label: p.name
						}))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						label: "Payment method",
						value: paymentMethod,
						onChange: (v) => {
							setPaymentMethod(v);
							setPage(1);
						},
						options: [
							{
								value: "all",
								label: "All methods"
							},
							{
								value: "cash",
								label: PAYMENT_METHOD_LABELS.cash
							},
							{
								value: "mobile_money",
								label: PAYMENT_METHOD_LABELS.mobile_money
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						label: "Payment status",
						value: paymentStatus,
						onChange: (v) => {
							setPaymentStatus(v);
							setPage(1);
						},
						options: [{
							value: "all",
							label: "All payments"
						}, ...Object.keys(PAYMENT_STATUS_LABELS).map((s) => ({
							value: s,
							label: PAYMENT_STATUS_LABELS[s]
						}))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterDate, {
						label: "Order date",
						value: orderDate,
						onChange: (v) => {
							setOrderDate(v);
							setPage(1);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterDate, {
						label: "Delivery date",
						value: deliveryDate,
						onChange: (v) => {
							setDeliveryDate(v);
							setPage(1);
						}
					})
				]
			}),
			orders.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Orders could not be loaded.",
				onRetry: () => orders.refetch()
			}) : orders.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "table" }) : sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No orders match these filters",
				description: "Try a different search term, date or status.",
				action: filtersActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: clearFilters,
					children: "Clear filters"
				}) : null
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderTable, {
						orders: sorted,
						sortKey,
						sortDir,
						onSort
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:hidden",
					children: sorted.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, { order }, order.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPagination, {
					page: orders.data.page,
					pageSize: orders.data.pageSize,
					total: orders.data.total,
					onPageChange: setPage
				})
			] })
		]
	});
}
//#endregion
export { OrdersPage as component };
