import { i as __toESM } from "../_runtime.mjs";
import { C as operationsService, g as formatDateTime, h as formatDate, m as driversService, p as deliveriesService, v as formatRelative, x as isApiError, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as MapPin, M as Hourglass, P as Flag, g as RefreshCw, n as Wallet, q as ChevronDown } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as StatCard } from "./StatCard-Bxab4anC.mjs";
import { t as AssignmentModal } from "./AssignmentModal-B8X0f-10.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/operations-vlk48hbz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var FLAG_LABELS = {
	proof_skipped: {
		label: "No delivery code",
		tone: "bg-warning/15 text-warning"
	},
	far_from_address: {
		label: "Far from address",
		tone: "bg-destructive/10 text-destructive"
	},
	delivery_issue: {
		label: "Problem reported",
		tone: "bg-primary/10 text-primary"
	},
	declined: {
		label: "Declined",
		tone: "bg-muted text-muted-foreground"
	},
	code_locked: {
		label: "Code guessing",
		tone: "bg-destructive/10 text-destructive"
	}
};
var STALL_COPY = {
	not_accepted: {
		label: "Not accepted",
		hint: "The driver has not opened this assignment."
	},
	not_started: {
		label: "Not started",
		hint: "Accepted but still waiting to leave."
	},
	driver_off_duty: {
		label: "Driver off duty",
		hint: "Assigned to a driver who went off duty."
	}
};
/** Cash held this long is worth a phone call. */
var OLD_CASH_HOURS = 12;
function OperationsPage() {
	const { can } = useAuth();
	const qc = useQueryClient();
	const [handInFor, setHandInFor] = (0, import_react.useState)(null);
	const [reassign, setReassign] = (0, import_react.useState)(null);
	const overview = useQuery({
		queryKey: ["operations"],
		queryFn: () => operationsService.overview(),
		refetchInterval: 6e4
	});
	const drivers = useQuery({
		queryKey: ["drivers", "available"],
		queryFn: () => driversService.available(),
		enabled: !!reassign
	});
	const review = useMutation({
		mutationFn: (id) => operationsService.reviewFlag(id),
		onSuccess: () => qc.invalidateQueries({ queryKey: ["operations"] }),
		onError: (error) => toast.error(isApiError(error) ? error.message : "Could not update this flag")
	});
	const assign = useMutation({
		mutationFn: (driverId) => deliveriesService.assignDriver(reassign.orderId, driverId),
		onSuccess: () => {
			toast.success("Delivery reassigned");
			setReassign(null);
			qc.invalidateQueries();
		},
		onError: (error) => toast.error(isApiError(error) ? error.message : "Could not reassign")
	});
	const data = overview.data;
	const cashTotal = data?.cash.reduce((sum, entry) => sum + entry.amount, 0) ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Operations",
				description: "What needs a decision today: money still in the field, stops going nowhere, and deliveries worth a second look.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: ["Updated ", formatRelative(data.generatedAt)]
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					disabled: overview.isFetching,
					onClick: () => overview.refetch(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: cn("size-4", overview.isFetching && "animate-spin") }), "Refresh"]
				})] })
			}),
			overview.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Operations could not be loaded.",
				onRetry: () => overview.refetch()
			}) : overview.isLoading || !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "table" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Cash with drivers",
						value: formatTZS(cashTotal),
						hint: data.cash.length ? `${data.cash.length} ${data.cash.length === 1 ? "driver" : "drivers"} to settle` : "Everything is handed in",
						icon: Wallet,
						tone: data.cash.length ? "warning" : "green"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Stalled stops",
						value: data.stalled.length,
						hint: "Assigned but not moving",
						icon: Hourglass,
						tone: data.stalled.length ? "warning" : "neutral"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Flags to review",
						value: data.flags.length,
						hint: "Last 30 days",
						icon: Flag,
						tone: data.flags.length ? "brand" : "neutral"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 xl:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6 xl:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Stalled stops",
						caption: "Assignments that are waiting on a driver. Reassign or call the driver.",
						children: data.stalled.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "Nothing stuck",
							description: "Every assigned stop is moving."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-border",
							children: data.stalled.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StalledRow, {
								row,
								canReassign: can("deliveries.assignDriver") && !!row.orderId,
								onReassign: () => setReassign(row)
							}, `${row.orderId ?? row.orderNumber}-${row.kind}`))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Flagged deliveries",
						caption: "Handed over without the customer's code, far from the address, declined or reported. Clear each one once you have checked it.",
						children: data.flags.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "No flags",
							description: "Nothing unusual in the last 30 days."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-border",
							children: data.flags.map((flag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlagRow, {
								flag,
								busy: review.isPending && review.variables === flag.id,
								onReview: () => review.mutate(flag.id)
							}, flag.id))
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6 xl:col-span-2",
					children: [data.drivers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "On duty now",
						caption: "Positions come from the driver app about once a minute while it is open.",
						children: data.drivers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "Nobody on duty",
							description: "Drivers switch on duty in their app."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-border",
							children: data.drivers.map((driver) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyRow, { driver }, driver.driverId))
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Cash with drivers",
						caption: "Cash confirmed at the door but not yet brought to the office.",
						children: data.cash.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "All settled",
							description: "No driver is holding NELMA cash."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 p-4",
							children: data.cash.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CashCard, {
								entry,
								canSettle: can("payments.collectCash"),
								onSettle: () => setHandInFor(entry)
							}, entry.driverId))
						})
					})]
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandInDialog, {
				entry: handInFor,
				onClose: () => setHandInFor(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentModal, {
				open: !!reassign,
				onOpenChange: (open) => !open && setReassign(null),
				drivers: drivers.data ?? [],
				currentDriverId: reassign?.driverId ?? null,
				loading: assign.isPending,
				onAssign: (driverId) => assign.mutate(driverId),
				title: "Reassign stalled stop"
			})
		]
	});
}
function Section({ title, caption, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-xl border border-border bg-card shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "border-b border-border px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold text-foreground",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-muted-foreground",
				children: caption
			})]
		}), children]
	});
}
function OrderRef({ orderId, orderNumber }) {
	const label = orderNumber ?? "Order";
	return orderId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/orders/$id",
		params: { id: orderId },
		className: "font-mono text-xs text-primary underline-offset-2 hover:underline",
		children: label
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono text-xs text-muted-foreground",
		children: label
	});
}
function StalledRow({ row, canReassign, onReassign }) {
	const copy = STALL_COPY[row.kind];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						title: copy.hint,
						className: cn("rounded-md px-2 py-0.5 text-xs font-medium", row.kind === "driver_off_duty" ? "bg-destructive/10 text-destructive" : "bg-warning/15 text-warning"),
						children: copy.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderRef, {
						orderId: row.orderId,
						orderNumber: row.orderNumber
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-foreground",
					children: [row.customerName ?? "Customer", row.area ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [" · ", row.area]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						row.driverName,
						row.since ? ` · ${row.kind === "not_started" ? "accepted" : "assigned"} ${formatRelative(row.since)}` : "",
						row.scheduledDate ? ` · due ${formatDate(row.scheduledDate)}` : "",
						row.timeWindow ? `, ${row.timeWindow}` : ""
					]
				})
			]
		}), canReassign ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "outline",
			onClick: onReassign,
			children: "Reassign"
		}) : null]
	});
}
function FlagRow({ flag, busy, onReview }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-wrap items-start gap-x-4 gap-y-2 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: [flag.kinds.map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("rounded-md px-2 py-0.5 text-xs font-medium", FLAG_LABELS[kind].tone),
						children: FLAG_LABELS[kind].label
					}, kind)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderRef, {
						orderId: flag.orderId,
						orderNumber: flag.orderNumber
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-foreground",
					children: flag.detail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						flag.driverName,
						flag.customerName ? ` → ${flag.customerName}` : "",
						flag.area ? `, ${flag.area}` : "",
						" · ",
						formatDateTime(flag.at)
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "ghost",
			disabled: busy,
			onClick: onReview,
			children: busy ? "Saving…" : "Mark checked"
		})]
	});
}
/** A position older than this is shown as stale: the app is closed or the phone lost signal. */
var STALE_POSITION_MINUTES = 15;
function DutyRow({ driver }) {
	const position = driver.lastLocation;
	const stale = !position?.at || Date.now() - new Date(position.at).getTime() > STALE_POSITION_MINUTES * 6e4;
	const load = [driver.onTheRoad ? `${driver.onTheRoad} on the road` : null, driver.waiting ? `${driver.waiting} waiting` : null].filter(Boolean).join(" · ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center justify-between gap-3 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-medium text-foreground",
				children: driver.driverName
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `tel:${driver.driverPhone}`,
						className: "hover:underline",
						children: driver.driverPhone
					}),
					" · ",
					load || "No stops"
				]
			})]
		}), position ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: `https://www.google.com/maps?q=${position.latitude},${position.longitude}`,
			target: "_blank",
			rel: "noreferrer",
			className: cn("flex shrink-0 items-center gap-1 text-xs hover:underline", stale ? "text-muted-foreground" : "font-medium text-primary"),
			title: stale ? "The app has not reported a position recently." : void 0,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), position.at ? formatRelative(position.at) : "Map"]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 text-xs text-muted-foreground",
			children: "No position yet"
		})]
	});
}
function CashCard({ entry, canSettle, onSettle }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const overdue = (Date.now() - new Date(entry.oldestAt).getTime()) / 36e5 >= OLD_CASH_HOURS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-lg border p-3", overdue ? "border-warning/60 bg-warning/5" : "border-border"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium text-foreground",
						children: entry.driverName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${entry.driverPhone}`,
								className: "hover:underline",
								children: entry.driverPhone
							}),
							" ",
							"· ",
							entry.onDuty ? "On duty" : "Off duty"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 text-lg font-semibold tabular-nums text-foreground",
					children: formatTZS(entry.amount)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("mt-1 text-xs", overdue ? "font-medium text-warning" : "text-muted-foreground"),
				children: [
					entry.receipts.length,
					" ",
					entry.receipts.length === 1 ? "receipt" : "receipts",
					", oldest",
					" ",
					formatRelative(entry.oldestAt)
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-1 border-t border-border pt-2",
				children: entry.receipts.map((receipt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 truncate",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderRef, {
								orderId: receipt.orderId,
								orderNumber: receipt.orderNumber
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: receipt.customerName
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 tabular-nums",
						children: formatTZS(receipt.amount)
					})]
				}, receipt.paymentId))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen((value) => !value),
					className: "flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-3.5 transition-transform", open && "rotate-180") }), open ? "Hide receipts" : "Show receipts"]
				}), canSettle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: onSettle,
					children: "Record hand-in"
				}) : null]
			})
		]
	});
}
function HandInDialog({ entry, onClose }) {
	const qc = useQueryClient();
	const [counted, setCounted] = (0, import_react.useState)("");
	const amount = Number(counted.replace(/[^\d]/g, ""));
	const settle = useMutation({
		mutationFn: () => operationsService.handIn(entry.driverId, entry.receipts.map((r) => r.paymentId), amount),
		onSuccess: (result) => {
			toast.success(`${formatTZS(result.settled)} received from ${entry.driverName}`);
			setCounted("");
			onClose();
			qc.invalidateQueries({ queryKey: ["operations"] });
		}
	});
	const close = () => {
		setCounted("");
		settle.reset();
		onClose();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!entry,
		onOpenChange: (open) => !open && close(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Cash from ", entry?.driverName] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				"Count the money first, then enter what you actually received. It has to match",
				" ",
				entry ? formatTZS(entry.amount) : "",
				" from ",
				entry?.receipts.length,
				" receipts."
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: (event) => {
					event.preventDefault();
					if (counted) settle.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "counted",
						children: "Amount counted (TZS)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "counted",
						inputMode: "numeric",
						autoComplete: "off",
						autoFocus: true,
						value: counted,
						onChange: (event) => setCounted(event.target.value),
						placeholder: "e.g. 26000"
					}),
					settle.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: isApiError(settle.error) ? settle.error.message : "Could not record this hand-in."
					}) : null,
					entry && counted && amount !== entry.amount && !settle.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						className: "font-normal",
						children: amount < entry.amount ? `${formatTZS(entry.amount - amount)} short` : `${formatTZS(amount - entry.amount)} over`
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: close,
							disabled: settle.isPending,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: !counted || settle.isPending,
							children: settle.isPending ? "Saving…" : "Confirm hand-in"
						})]
					})
				]
			})]
		})
	});
}
//#endregion
export { OperationsPage as component };
