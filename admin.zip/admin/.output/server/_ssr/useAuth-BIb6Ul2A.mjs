import { i as __toESM } from "../_runtime.mjs";
import { s as SESSION_EXPIRED_EVENT, u as authService } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useAuth-BIb6Ul2A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROLE_PERMISSIONS = {
	SALES_MANAGER: [
		"orders.view",
		"orders.create",
		"orders.process",
		"payments.collectCash",
		"deliveries.view",
		"deliveries.update",
		"deliveries.assignDriver",
		"drivers.view",
		"drivers.manage",
		"reports.view",
		"pricing.manage",
		"notifications.view",
		"profile.view"
	],
	SYSTEM_ADMIN: [
		"orders.view",
		"deliveries.view",
		"deliveries.assignDriver",
		"drivers.view",
		"drivers.manage",
		"reports.view",
		"pricing.manage",
		"accounts.manage",
		"settings.manage",
		"audit.view",
		"notifications.view",
		"profile.view"
	]
};
function can(role, permission) {
	if (!role) return false;
	return ROLE_PERMISSIONS[role].includes(permission);
}
var ROLE_LABELS = {
	SALES_MANAGER: "Sales Manager",
	SYSTEM_ADMIN: "System Admin"
};
/** Valid forward transitions the dashboard may request. No arbitrary jumps. */
var ORDER_TRANSITIONS = {
	pending: "confirmed",
	confirmed: "processing"
};
var TRANSITION_LABELS = {
	pending: "Confirm Order",
	confirmed: "Start Processing"
};
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const queryClient = useQueryClient();
	const [user, setUserState] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("loading");
	(0, import_react.useEffect)(() => {
		let active = true;
		authService.currentUser().then((current) => {
			if (!active) return;
			setUserState(current);
			setStatus(current ? "authenticated" : "unauthenticated");
		}).catch(() => {
			if (active) setStatus("unauthenticated");
		});
		return () => {
			active = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const expire = () => {
			queryClient.clear();
			setUserState(null);
			setStatus("unauthenticated");
		};
		window.addEventListener(SESSION_EXPIRED_EVENT, expire);
		return () => window.removeEventListener(SESSION_EXPIRED_EVENT, expire);
	}, [queryClient]);
	const signIn = (0, import_react.useCallback)(async (identifier, password) => {
		const session = await authService.login(identifier, password);
		queryClient.clear();
		setUserState(session.user);
		setStatus("authenticated");
		return session.user;
	}, [queryClient]);
	const signOut = (0, import_react.useCallback)(async () => {
		try {
			await authService.logout();
		} finally {
			queryClient.clear();
			setUserState(null);
			setStatus("unauthenticated");
		}
	}, [queryClient]);
	const value = (0, import_react.useMemo)(() => ({
		user,
		status,
		signIn,
		signOut,
		setUser: setUserState,
		can: (permission) => can(user?.role, permission)
	}), [
		user,
		status,
		signIn,
		signOut
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(AuthContext);
	if (!ctx) throw new Error("useAuth must be used within AuthProvider");
	return ctx;
}
//#endregion
export { can as a, TRANSITION_LABELS as i, ORDER_TRANSITIONS as n, useAuth as o, ROLE_LABELS as r, AuthProvider as t };
