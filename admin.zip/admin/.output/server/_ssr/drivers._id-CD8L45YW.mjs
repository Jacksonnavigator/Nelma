import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drivers._id-CD8L45YW.js
var $$splitComponentImporter = () => import("./drivers._id-BPkCpCKO.mjs");
var Route = createFileRoute("/_authenticated/drivers/$id")({
	head: () => ({ meta: [
		{ title: "NELMA | Driver details" },
		{
			name: "description",
			content: "Driver profile, workload and assigned NELMA deliveries."
		},
		{
			property: "og:title",
			content: "NELMA | Driver details"
		},
		{
			property: "og:description",
			content: "Driver profile, workload and assigned NELMA deliveries."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
