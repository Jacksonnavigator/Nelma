import { i as __toESM } from "../_runtime.mjs";
import { M as websiteRequestsService, g as formatDateTime } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as MapPin, H as CirclePlus, U as CircleCheck, c as ShoppingBag, h as RotateCcw, v as Phone, w as Mail, x as MessageSquare } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as DataPagination } from "./DataPagination-cN6wKWJj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/website-requests-DTQmXqa5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 20;
var TABS = [
	{
		value: "order",
		label: "Order requests"
	},
	{
		value: "contact",
		label: "Messages"
	},
	{
		value: "all",
		label: "Everything"
	}
];
function WebsiteRequestsPage() {
	const { can } = useAuth();
	const qc = useQueryClient();
	const [kind, setKind] = (0, import_react.useState)("order");
	const [status, setStatus] = (0, import_react.useState)("new");
	const [page, setPage] = (0, import_react.useState)(1);
	const query = {
		kind,
		status,
		page,
		pageSize: PAGE_SIZE
	};
	const list = useQuery({
		queryKey: ["website-requests", query],
		queryFn: () => websiteRequestsService.list(query),
		placeholderData: keepPreviousData
	});
	const mark = useMutation({
		mutationFn: ({ id, next }) => websiteRequestsService.setStatus(id, next),
		onSuccess: (request) => {
			toast.success(request.status === "handled" ? "Marked as handled" : "Moved back to new");
			qc.invalidateQueries({ queryKey: ["website-requests"] });
		},
		onError: () => toast.error("Could not update this request")
	});
	const counts = list.data?.newCounts;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Website requests",
				description: "Orders and messages sent from the NELMA website. Call the person back, then create the order and mark the request as handled."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [TABS.map((tab) => {
					const active = kind === tab.value;
					const fresh = tab.value === "all" ? (counts?.order ?? 0) + (counts?.contact ?? 0) : counts?.[tab.value] ?? 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						role: "tab",
						"aria-selected": active,
						onClick: () => {
							setKind(tab.value);
							setPage(1);
						},
						className: cn("rounded-full border px-3 py-1.5 text-sm font-medium transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-muted"),
						children: [tab.label, fresh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("ml-1.5 rounded-full px-1.5 text-xs tabular-nums", active ? "bg-primary-foreground/20" : "bg-destructive text-white"),
							children: [fresh, " new"]
						}) : null]
					}, tab.value);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ml-auto flex gap-1 rounded-lg border bg-card p-1 text-sm",
					children: [
						"new",
						"handled",
						"all"
					].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setStatus(value);
							setPage(1);
						},
						className: cn("rounded-md px-3 py-1 capitalize", status === value ? "bg-muted font-medium text-foreground" : "text-muted-foreground"),
						children: value
					}, value))
				})]
			}),
			list.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Requests could not be loaded.",
				onRetry: () => list.refetch()
			}) : list.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {}) : !list.data?.items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: status === "new" ? "Nothing waiting" : "No requests",
				description: "New orders and messages from the website will appear here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 lg:grid-cols-2",
				children: list.data.items.map((request) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestCard, {
					request,
					canCreateOrder: can("orders.create"),
					busy: mark.isPending && mark.variables?.id === request.id,
					onToggle: () => mark.mutate({
						id: request.id,
						next: request.status === "new" ? "handled" : "new"
					})
				}, request.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPagination, {
				page,
				pageSize: PAGE_SIZE,
				total: list.data.total,
				onPageChange: setPage
			})] })
		]
	});
}
function RequestCard({ request, canCreateOrder, busy, onToggle }) {
	const isOrder = request.kind === "order";
	const place = [
		request.address,
		request.area,
		request.city
	].filter(Boolean).join(", ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: cn("rounded-xl border bg-card p-4 shadow-card", request.status === "new" ? "border-primary/40" : "opacity-80"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("mt-0.5 grid size-9 shrink-0 place-items-center rounded-lg", isOrder ? "bg-primary/10 text-primary" : "bg-muted text-foreground"),
				children: isOrder ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-x-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold text-foreground",
							children: [request.name, request.company ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-normal text-muted-foreground",
								children: [" · ", request.company]
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: formatDateTime(request.createdAt)
						})]
					}),
					isOrder ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
							request.quantity,
							" × ",
							request.productName ?? request.productCode
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [
								" ",
								"· ",
								request.customerType === "existing" ? "Existing customer" : "New customer"
							]
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 space-y-1 text-sm text-muted-foreground",
						children: [
							request.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "flex items-center gap-2 hover:text-foreground",
								href: `tel:${request.phone}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5" }),
									" ",
									request.phone
								]
							}) : null,
							request.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "flex items-center gap-2 hover:text-foreground",
								href: `mailto:${request.email}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5" }),
									" ",
									request.email
								]
							}) : null,
							place ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
									" ",
									place
								]
							}) : null
						]
					}),
					request.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 whitespace-pre-wrap rounded-lg bg-muted px-3 py-2 text-sm text-foreground",
						children: request.message
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [isOrder && request.status === "new" && canCreateOrder ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/create-order",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "mr-1.5 size-4" }), " Create order"]
							})
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: request.status === "new" ? "default" : "ghost",
							disabled: busy,
							onClick: onToggle,
							children: request.status === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mr-1.5 size-4" }), " Mark handled"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "mr-1.5 size-4" }), " Move back to new"] })
						})]
					})
				]
			})]
		})
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "orders.view",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteRequestsPage, {})
});
//#endregion
export { SplitComponent as component };
