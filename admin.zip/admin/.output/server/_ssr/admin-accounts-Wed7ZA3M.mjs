import { i as __toESM } from "../_runtime.mjs";
import { c as adminAccountsService, h as formatDate, t as DATA_MODE, x as isApiError } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth, r as ROLE_LABELS } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { t as RoleBadge } from "./RoleBadge-EcFSJS8c.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { t as ContactFields } from "./ContactFields-DqDSQHDE.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-DZsl5SSz.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-accounts-Wed7ZA3M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var empty = {
	fullName: "",
	email: "",
	phone: "",
	role: "SALES_MANAGER"
};
function AccountsPage() {
	const { user } = useAuth();
	const qc = useQueryClient();
	const accounts = useQuery({
		queryKey: ["accounts"],
		queryFn: () => adminAccountsService.list()
	});
	const [search, setSearch] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(empty);
	const [password, setPassword] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)(null);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["accounts"] });
		qc.invalidateQueries({ queryKey: ["audit"] });
		qc.invalidateQueries({ queryKey: ["metrics"] });
	};
	const save = useMutation({
		mutationFn: () => {
			const input = {
				role: draft.role,
				fullName: draft.fullName.trim(),
				email: draft.email.trim(),
				phone: draft.phone.trim()
			};
			if (accounts.data?.some((a) => a.id !== (editing === "new" ? null : editing?.id) && (a.email.toLowerCase() === input.email.toLowerCase() || a.phone.replace(/\D/g, "") === input.phone.replace(/\D/g, "")))) throw new Error("An account already uses this email or phone number.");
			return editing && editing !== "new" ? adminAccountsService.update(editing.id, input) : adminAccountsService.create({
				...input,
				...password ? { password } : {}
			});
		},
		onSuccess: () => {
			refresh();
			setEditing(null);
			setPassword("");
			toast.success("Account saved");
		}
	});
	const toggle = useMutation({
		mutationFn: (account) => adminAccountsService.update(account.id, { status: account.status === "active" ? "inactive" : "active" }),
		onSuccess: () => {
			refresh();
			setTarget(null);
			toast.success("Account status updated");
		},
		onError: () => toast.error("Could not update account status. Please try again.")
	});
	const rows = accounts.data?.filter((a) => `${a.fullName} ${a.email} ${a.phone} ${ROLE_LABELS[a.role]} ${a.status}`.toLowerCase().includes(search.toLowerCase())) ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Admin Accounts",
				description: "Manage staff accounts and dashboard access.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						setDraft(empty);
						setPassword("");
						save.reset();
						setEditing("new");
					},
					children: "Add account"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-md space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "account-search",
					children: "Search accounts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "account-search",
					placeholder: "Search name, email, role or status",
					value: search,
					onChange: (e) => setSearch(e.target.value)
				})]
			}),
			accounts.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {}) : accounts.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Accounts could not be loaded.",
				onRetry: () => accounts.refetch()
			}) : !rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No accounts found",
				description: "Try another search or add an account."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Name" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Contact" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Role" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Created" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Last login" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Actions" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						className: "font-medium",
						children: [a.fullName, a.id === user?.id ? " (you)" : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: a.email }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted-foreground",
						children: a.phone
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: a.role }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "capitalize",
						children: a.status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: formatDate(a.createdAt) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: a.lastLoginAt ? formatDate(a.lastLoginAt) : DATA_MODE === "api" ? "Not available" : "Never" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							disabled: a.id === user?.id,
							onClick: () => {
								setDraft(a);
								save.reset();
								setEditing(a);
							},
							children: "Edit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							disabled: a.id === user?.id || toggle.isPending,
							onClick: () => setTarget(a),
							children: a.status === "active" ? "Deactivate" : "Activate"
						})]
					}) })
				] }, a.id)) })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Use Profile to edit your own details. You cannot change your own role or deactivate your account here."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editing !== null,
				onOpenChange: (open) => {
					if (!open && !save.isPending) {
						setEditing(null);
						setPassword("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing === "new" ? "Add account" : "Edit account" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Set staff contact details and their dashboard role." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						if (!save.isPending) save.mutate();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						disabled: save.isPending,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactFields, {
								value: draft,
								onChange: (value) => setDraft({
									...draft,
									...value
								})
							}),
							editing === "new" && DATA_MODE === "api" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "account-password",
										children: "Initial password"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "account-password",
										type: "password",
										autoComplete: "new-password",
										required: true,
										minLength: 8,
										maxLength: 128,
										value: password,
										onChange: (e) => setPassword(e.target.value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Share this password with the staff member through your approved secure channel."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "account-role",
									children: "Role"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "account-role",
									className: "h-10 w-full rounded-md border bg-background px-3 text-sm",
									value: draft.role,
									onChange: (e) => setDraft({
										...draft,
										role: e.target.value
									}),
									children: Object.entries(ROLE_LABELS).map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value,
										children: label
									}, value))
								})]
							}),
							save.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "text-sm text-destructive",
								children: isApiError(save.error) || save.error instanceof Error ? save.error.message : "Could not save account. Please try again."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => {
										setEditing(null);
										setPassword("");
									},
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: save.isPending ? "Saving..." : "Save account" })]
							})
						]
					})
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!target,
				onOpenChange: (open) => {
					if (!open && !toggle.isPending) setTarget(null);
				},
				title: target?.status === "active" ? "Deactivate account?" : "Activate account?",
				description: target ? `Change dashboard access for ${target.fullName}.` : "",
				loading: toggle.isPending,
				onConfirm: () => {
					if (target) toggle.mutate(target);
				}
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "accounts.manage",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountsPage, {})
});
//#endregion
export { SplitComponent as component };
