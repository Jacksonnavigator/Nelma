import { i as __toESM } from "../_runtime.mjs";
import { E as productLabel, _ as formatNumber, a as PAYMENT_METHOD_LABELS, g as formatDateTime, h as formatDate, i as ORDER_STATUS_LABELS, m as driversService, p as deliveriesService, r as ORDER_LIFECYCLE, w as ordersService, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as TRANSITION_LABELS, n as ORDER_TRANSITIONS, o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as CircleX, J as Check, Q as ArrowLeft, a as Truck, p as Send, z as Circle } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-DZsl5SSz.mjs";
import { n as ErrorState, r as LoadingSkeleton } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Textarea } from "./textarea-BlwX1vdP.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
import { t as AssignmentModal } from "./AssignmentModal-B8X0f-10.mjs";
import { t as Route } from "./orders._id-D_b07s0R.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders._id-DpAf6hcA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Order lifecycle timeline. Stages come from the shared lifecycle definition. */
function OrderTimeline({ order }) {
	if (order.status === "cancelled") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-lg border border-destructive/20 bg-destructive/5 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-5 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium text-foreground",
			children: "Order cancelled"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "This order is no longer in progress."
		})] })]
	});
	const currentIndex = ORDER_LIFECYCLE.indexOf(order.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "space-y-0",
		children: ORDER_LIFECYCLE.map((stage, index) => {
			const entry = order.timeline.find((t) => t.status === stage);
			const done = index <= currentIndex;
			const isCurrent = index === currentIndex;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-7 items-center justify-center rounded-full border", done ? "border-success/30 bg-success/12 text-success" : "border-border bg-muted text-muted-foreground"),
						children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-2.5" })
					}), index < ORDER_LIFECYCLE.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("w-px flex-1", index < currentIndex ? "bg-success/40" : "bg-border") }) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pb-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-sm", isCurrent ? "font-semibold text-foreground" : "text-foreground/90"),
						children: ORDER_STATUS_LABELS[stage]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: entry?.at ? formatDateTime(entry.at) : "Pending"
					})]
				})]
			}, stage);
		})
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4 border-b border-border/60 py-2 last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-right text-sm font-medium text-foreground",
			children: value
		})]
	});
}
function Panel({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 text-sm font-semibold text-foreground",
			children: title
		}), children]
	});
}
var errorMessage = (error, fallback) => error && typeof error === "object" && "message" in error ? String(error.message) : fallback;
var SENDER_LABEL = {
	customer: "Customer",
	nelma: "NELMA",
	system: "Update"
};
function Conversation({ order, canReply }) {
	const qc = useQueryClient();
	const [body, setBody] = (0, import_react.useState)("");
	const messages = order.messages ?? [];
	const reply = useMutation({
		mutationFn: (text) => ordersService.reply(order.id, text),
		onSuccess: (updated) => {
			setBody("");
			qc.setQueryData(["order", order.id], updated);
			toast.success("Reply sent to the customer");
		},
		onError: (error) => toast.error(errorMessage(error, "Could not send the reply"))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Messages",
		children: [messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-2 text-sm text-muted-foreground",
			children: "No messages about this order yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "max-h-80 space-y-2 overflow-y-auto py-1",
			children: messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: m.sender === "nelma" ? "ml-6 rounded-lg bg-primary/10 px-3 py-2" : m.sender === "system" ? "rounded-lg border border-dashed px-3 py-2" : "mr-6 rounded-lg bg-muted px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: SENDER_LABEL[m.sender]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDateTime(m.createdAt) })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 whitespace-pre-wrap text-sm text-foreground",
					children: m.body
				})]
			}, m.id))
		}), canReply ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-3 space-y-2",
			onSubmit: (e) => {
				e.preventDefault();
				if (body.trim() && !reply.isPending) reply.mutate(body.trim());
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "order-reply",
					className: "sr-only",
					children: "Reply to the customer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "order-reply",
					value: body,
					maxLength: 1200,
					rows: 2,
					placeholder: "Reply to the customer",
					onChange: (e) => setBody(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					size: "sm",
					disabled: !body.trim() || reply.isPending,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "mr-2 size-4" }), reply.isPending ? "Sending…" : "Send reply"]
				})
			]
		}) : null]
	});
}
function OrderDetailPage() {
	const { id } = Route.useParams();
	const { can } = useAuth();
	const qc = useQueryClient();
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [assignOpen, setAssignOpen] = (0, import_react.useState)(false);
	const [cashOpen, setCashOpen] = (0, import_react.useState)(false);
	const [cancelOpen, setCancelOpen] = (0, import_react.useState)(false);
	const [reason, setReason] = (0, import_react.useState)("");
	const order = useQuery({
		queryKey: ["order", id],
		queryFn: () => ordersService.get(id)
	});
	const deliveries = useQuery({
		queryKey: [
			"deliveries",
			"for-order",
			id
		],
		queryFn: () => deliveriesService.forOrder(id)
	});
	const drivers = useQuery({
		queryKey: ["drivers", "available"],
		queryFn: () => driversService.available()
	});
	const delivery = deliveries.data ?? null;
	const advance = useMutation({
		mutationFn: async () => {
			return order.data.status === "pending" ? ordersService.confirm(id) : ordersService.process(id);
		},
		onSuccess: () => {
			toast.success("Order updated");
			setConfirmOpen(false);
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not update this order")
	});
	const assign = useMutation({
		mutationFn: (driverId) => deliveriesService.assignDriver(delivery.id, driverId),
		onSuccess: () => {
			toast.success("Driver assigned");
			setAssignOpen(false);
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not assign this driver")
	});
	const cancel = useMutation({
		mutationFn: (why) => ordersService.cancel(id, why),
		onSuccess: () => {
			toast.success("Order cancelled");
			setCancelOpen(false);
			setReason("");
			qc.invalidateQueries();
		},
		onError: (error) => toast.error(errorMessage(error, "Could not cancel this order"))
	});
	const collectCash = useMutation({
		mutationFn: () => ordersService.collectCash(id, order.data.total),
		onSuccess: () => {
			setCashOpen(false);
			toast.success("Cash collection recorded");
			qc.invalidateQueries();
		},
		onError: (error) => toast.error(error && typeof error === "object" && "message" in error ? String(error.message) : "Could not record cash collection")
	});
	if (order.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		description: "This order could not be loaded.",
		onRetry: () => order.refetch()
	});
	if (order.isLoading || !order.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "detail" });
	const o = order.data;
	const next = ORDER_TRANSITIONS[o.status];
	const canAdvance = can("orders.process") && !!next;
	const canCancel = can("orders.process") && ![
		"delivered",
		"customer_received",
		"cancelled"
	].includes(o.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: `${o.customer.fullName} — ${productLabel(o.item.product, o.item.productName)}`,
				description: `Placed ${formatDateTime(o.createdAt)} · ${o.source === "USER_MOBILE" ? "Customer mobile app" : "Sales desk"}`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/orders",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-2 size-4" }), " Back to orders"]
							})
						}),
						delivery && ![
							"delivered",
							"customer_received",
							"cancelled"
						].includes(o.status) && can("deliveries.assignDriver") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => setAssignOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "mr-2 size-4" }), delivery.driverId ? "Reassign driver" : "Assign driver"]
						}) : null,
						canCancel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "text-destructive hover:text-destructive",
							onClick: () => setCancelOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "mr-2 size-4" }), " Cancel order"]
						}) : null,
						canAdvance ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setConfirmOpen(true),
							children: TRANSITION_LABELS[o.status]
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
					kind: "order",
					status: o.status
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
					kind: "payment",
					status: o.paymentStatus
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							title: "Order summary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Product",
									value: productLabel(o.item.product, o.item.productName)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Quantity",
									value: formatNumber(o.item.quantity)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Unit price",
									value: formatTZS(o.item.unitPrice)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Subtotal",
									value: formatTZS(o.item.subtotal)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Delivery charge",
									value: formatTZS(o.deliveryCharge)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Total",
									value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base",
										children: formatTZS(o.total)
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							title: "Customer & delivery",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Customer",
									value: o.customer.fullName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Phone",
									value: o.customer.phone
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Area",
									value: o.deliveryLocation.area
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Address",
									value: o.deliveryLocation.addressLine
								}),
								o.deliveryLocation.instructions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Instructions",
									value: o.deliveryLocation.instructions
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Requested date",
									value: formatDate(o.requestedDeliveryDate)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Time window",
									value: o.requestedDeliveryWindow
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Driver",
									value: delivery?.driverId ? drivers.data?.find((d) => d.id === delivery.driverId)?.fullName ?? delivery.driverId : "Not assigned"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							title: "Payment",
							children: [
								o.cashReceipt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Receipt",
										value: o.cashReceipt.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Cash collected",
										value: formatTZS(o.cashReceipt.amount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Recorded at",
										value: formatDateTime(o.cashReceipt.collectedAt)
									})
								] }),
								can("payments.collectCash") && o.paymentMethod === "cash" && o.paymentStatus === "pending" && ["delivered", "customer_received"].includes(o.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "mb-3",
									onClick: () => setCashOpen(true),
									children: "Record cash received"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Method",
									value: PAYMENT_METHOD_LABELS[o.paymentMethod]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Status",
									value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
										kind: "payment",
										status: o.paymentStatus
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Order placed by",
									value: o.createdBy ? o.createdBy.fullName : "Customer (mobile app)"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Conversation, {
						order: o,
						canReply: can("orders.process")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Order lifecycle",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderTimeline, { order: o })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: cashOpen,
				onOpenChange: setCashOpen,
				title: "Record cash received?",
				description: `Confirm that the full ${formatTZS(o.total)} has been received for this order. This records a paid cash receipt and updates sales totals.`,
				confirmLabel: "Confirm cash received",
				loading: collectCash.isPending,
				onConfirm: () => collectCash.mutate()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmOpen,
				onOpenChange: setConfirmOpen,
				title: TRANSITION_LABELS[o.status] ?? "Update order",
				description: `This moves the order to "${next?.replace(/_/g, " ")}" and lets the customer know.`,
				confirmLabel: TRANSITION_LABELS[o.status] ?? "Confirm",
				loading: advance.isPending,
				onConfirm: () => advance.mutate()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: cancelOpen,
				onOpenChange: (open) => {
					setCancelOpen(open);
					if (!open) setReason("");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Cancel this order?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: ["The customer is told it was cancelled, with your reason.", delivery?.driverId ? " The driver gets an alert and it leaves their route." : ""] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cancel-reason",
							children: "Reason"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "cancel-reason",
							value: reason,
							maxLength: 300,
							placeholder: "For example: customer asked by phone, out of stock",
							onChange: (e) => setReason(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setCancelOpen(false),
						children: "Keep order"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "destructive",
						disabled: reason.trim().length < 3 || cancel.isPending,
						onClick: () => cancel.mutate(reason.trim()),
						children: cancel.isPending ? "Cancelling…" : "Cancel order"
					})] })
				] })
			}),
			delivery ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentModal, {
				open: assignOpen,
				onOpenChange: setAssignOpen,
				drivers: drivers.data ?? [],
				currentDriverId: delivery.driverId,
				loading: assign.isPending,
				onAssign: (driverId) => assign.mutate(driverId)
			}) : null
		]
	});
}
//#endregion
export { OrderDetailPage as component };
