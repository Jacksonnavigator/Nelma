import { i as __toESM } from "../_runtime.mjs";
import { m as driversService, t as DATA_MODE, x as isApiError } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as FilterSelect, t as FilterBar } from "./FilterBar-BHwBUYK9.mjs";
import { t as SearchInput } from "./SearchInput-P8d-sPCQ.mjs";
import { t as DataPagination } from "./DataPagination-cN6wKWJj.mjs";
import { t as DriverCard } from "./DriverCard-BaHzIopX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drivers.index-TDIFkeA7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 9;
function DriversPage() {
	const { can } = useAuth();
	const qc = useQueryClient();
	const [search, setSearch] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [page, setPage] = (0, import_react.useState)(1);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const query = {
		page,
		pageSize: PAGE_SIZE,
		status,
		...search ? { search } : {}
	};
	const drivers = useQuery({
		queryKey: ["drivers", query],
		queryFn: () => driversService.list(query),
		placeholderData: keepPreviousData
	});
	const create = useMutation({
		mutationFn: () => driversService.create({
			fullName: fullName.trim(),
			phone: phone.trim(),
			...password ? { password } : {}
		}),
		onSuccess: () => {
			toast.success("Driver added");
			setCreating(false);
			setFullName("");
			setPhone("");
			setPassword("");
			qc.invalidateQueries();
		},
		onError: (error) => toast.error(isApiError(error) ? error.message : "Could not add this driver")
	});
	const toggle = useMutation({
		mutationFn: (driver) => driversService.update(driver.id, { status: driver.status === "active" ? "inactive" : "active" }),
		onSuccess: () => {
			toast.success("Driver updated");
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not update this driver")
	});
	const valid = fullName.trim().length > 2 && phone.trim().length >= 9 && (DATA_MODE !== "api" || password.length >= 8);
	const filtersActive = search !== "" || status !== "all";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Drivers",
				description: "Delivery team, current workload and availability.",
				actions: can("drivers.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setCreating(true),
					children: "Add driver"
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, {
				onClear: () => {
					setSearch("");
					setStatus("all");
					setPage(1);
				},
				showClear: filtersActive,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs text-muted-foreground",
						children: "Search"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
						value: search,
						onChange: (v) => {
							setSearch(v);
							setPage(1);
						},
						placeholder: "Search name or phone"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
					label: "Status",
					value: status,
					onChange: (v) => {
						setStatus(v);
						setPage(1);
					},
					options: [
						{
							value: "all",
							label: "All drivers"
						},
						{
							value: "active",
							label: "Active"
						},
						{
							value: "inactive",
							label: "Inactive"
						}
					]
				})]
			}),
			drivers.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Drivers could not be loaded.",
				onRetry: () => drivers.refetch()
			}) : drivers.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
				variant: "cards",
				rows: 6
			}) : (drivers.data?.items.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No drivers found",
				description: "Try a different search or filter."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
				children: drivers.data.items.map((driver) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DriverCard, {
					driver,
					action: can("drivers.manage") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: toggle.isPending,
						onClick: () => toggle.mutate(driver),
						children: driver.status === "active" ? "Deactivate" : "Activate"
					}) : null
				}, driver.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPagination, {
				page: drivers.data.page,
				pageSize: drivers.data.pageSize,
				total: drivers.data.total,
				onPageChange: setPage
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: creating,
				onOpenChange: (open) => {
					if (!create.isPending) {
						setCreating(open);
						if (!open) setPassword("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add driver" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Drivers receive delivery assignments from the dashboard." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "driver-name",
									children: "Full name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "driver-name",
									value: fullName,
									onChange: (e) => setFullName(e.target.value),
									placeholder: "e.g. Juma Kileo"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "driver-phone",
									children: "Phone number"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "driver-phone",
									value: phone,
									onChange: (e) => setPhone(e.target.value),
									placeholder: "+255 7xx xxx xxx"
								})]
							})]
						}),
						DATA_MODE === "api" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "driver-password",
								children: "Initial password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "driver-password",
								type: "password",
								autoComplete: "new-password",
								minLength: 8,
								maxLength: 128,
								value: password,
								onChange: (e) => setPassword(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setCreating(false),
							disabled: create.isPending,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !valid || create.isPending,
							onClick: () => create.mutate(),
							children: "Add driver"
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { DriversPage as component };
