import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/DataPagination-cN6wKWJj.js
var import_jsx_runtime = require_jsx_runtime();
function DataPagination({ page, pageSize, total, onPageChange }) {
	const pages = Math.max(1, Math.ceil(total / pageSize));
	const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
	const to = Math.min(page * pageSize, total);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-3 px-1 py-2 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Showing ",
			from,
			"–",
			to,
			" of ",
			total
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					disabled: page <= 1,
					onClick: () => onPageChange(page - 1),
					children: "Previous"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums",
					children: [
						"Page ",
						page,
						" of ",
						pages
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					disabled: page >= pages,
					onClick: () => onPageChange(page + 1),
					children: "Next"
				})
			]
		})]
	});
}
//#endregion
export { DataPagination as t };
