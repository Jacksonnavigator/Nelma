import { i as __toESM } from "../_runtime.mjs";
import { D as productsService, g as formatDateTime, x as isApiError, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { _ as Plus, a as Truck, j as ImagePlus, s as Trash2, y as Package } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Textarea } from "./textarea-BlwX1vdP.mjs";
import { t as Switch } from "./switch-BErL7BqH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-DpochkYV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var zoneId = (name, taken) => {
	const base = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 30) || "zone";
	let id = base.length >= 2 ? base : `zone_${base}`;
	for (let n = 2; taken.includes(id); n += 1) id = `${base}_${n}`;
	return id;
};
var money = (value) => Math.max(0, Math.round(Number(value) || 0));
var clean = (fees) => ({
	defaultZoneName: fees.defaultZoneName.trim(),
	defaultFee: fees.defaultFee,
	zones: fees.zones.map((zone) => ({
		...zone,
		name: zone.name.trim(),
		keywords: zone.keywords.map((k) => k.trim()).filter(Boolean)
	}))
});
/**
* Delivery fees, edited next to product prices so sales managers can change them as well as admins.
* A zone applies when one of its place names appears in the customer's address; everywhere else pays
* the standard fee. The app and the website show the new fees on their next refresh.
*/
function DeliveryFeesCard() {
	const qc = useQueryClient();
	const fees = useQuery({
		queryKey: ["delivery-fees"],
		queryFn: () => productsService.deliveryFees()
	});
	const [draft, setDraft] = (0, import_react.useState)(null);
	const save = useMutation({
		mutationFn: (value) => productsService.saveDeliveryFees(clean(value)),
		onSuccess: (value) => {
			qc.setQueryData(["delivery-fees"], value);
			qc.invalidateQueries({ queryKey: ["settings"] });
			setDraft(null);
			toast.success("Delivery fees saved");
		}
	});
	if (fees.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "detail" });
	if (fees.isError || !fees.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		description: "Delivery fees could not be loaded.",
		onRetry: () => fees.refetch()
	});
	const value = draft ?? fees.data;
	const dirty = !!draft && JSON.stringify(draft) !== JSON.stringify(fees.data);
	const allFree = value.defaultFee === 0 && value.zones.every((zone) => zone.fee === 0);
	const setZone = (index, zone) => setDraft({
		...value,
		zones: value.zones.map((z, i) => i === index ? zone : z)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border bg-card p-5 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap items-start justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-9 place-items-center rounded-lg bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold text-foreground",
					children: "Delivery fees"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Added to each order on top of the product price.",
						" ",
						allFree ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-foreground",
							children: "Delivery is currently free everywhere."
						}) : null
					]
				})] })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
			className: "space-y-3",
			onSubmit: (e) => {
				e.preventDefault();
				if (dirty && !save.isPending) save.mutate(value);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				disabled: save.isPending,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 rounded-lg bg-muted/50 p-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "default-zone",
								children: "Standard area name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "default-zone",
								required: true,
								minLength: 2,
								value: value.defaultZoneName,
								onChange: (e) => setDraft({
									...value,
									defaultZoneName: e.target.value
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "default-fee",
									children: "Standard fee (TZS)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "default-fee",
									type: "number",
									min: 0,
									step: 100,
									required: true,
									value: value.defaultFee,
									onChange: (e) => setDraft({
										...value,
										defaultFee: money(e.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Charged everywhere not listed below. ",
										formatTZS(value.defaultFee),
										value.defaultFee === 0 ? " (free)" : ""
									]
								})
							]
						})]
					}),
					value.zones.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-1 text-xs text-muted-foreground",
						children: "Places with their own fee. Use specific place names (such as \"Tengeru\"), not general words like \"hostel\"."
					}) : null,
					value.zones.map((zone, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 rounded-lg border p-3 sm:grid-cols-[1fr_140px_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `zone-name-${zone.id}`,
									children: "Area name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `zone-name-${zone.id}`,
									required: true,
									minLength: 2,
									value: zone.name,
									onChange: (e) => setZone(index, {
										...zone,
										name: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `zone-fee-${zone.id}`,
									children: "Fee (TZS)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `zone-fee-${zone.id}`,
									type: "number",
									min: 0,
									step: 100,
									required: true,
									value: zone.fee,
									onChange: (e) => setZone(index, {
										...zone,
										fee: money(e.target.value)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									"aria-label": `Remove ${zone.name || "area"}`,
									onClick: () => setDraft({
										...value,
										zones: value.zones.filter((_, i) => i !== index)
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `zone-keywords-${zone.id}`,
									children: "Place names in the address (comma separated)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `zone-keywords-${zone.id}`,
									required: true,
									value: zone.keywords.join(", "),
									onChange: (e) => setZone(index, {
										...zone,
										keywords: e.target.value.split(",").map((k) => k.trimStart())
									})
								})]
							})
						]
					}, zone.id)),
					save.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: isApiError(save.error) ? save.error.message : "Could not save the fees. Please try again."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							disabled: value.zones.length >= 20,
							onClick: () => setDraft({
								...value,
								zones: [...value.zones, {
									id: zoneId(`zone ${value.zones.length + 1}`, value.zones.map((z) => z.id)),
									name: "",
									fee: 0,
									keywords: []
								}]
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1.5 size-4" }), " Add area with its own fee"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								disabled: !dirty,
								onClick: () => {
									setDraft(null);
									save.reset();
								},
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								size: "sm",
								disabled: !dirty || save.isPending,
								children: save.isPending ? "Saving…" : "Save delivery fees"
							})]
						})]
					})
				]
			})
		})]
	});
}
var MAX_IMAGE_MB = 5;
function ProductsPage() {
	const qc = useQueryClient();
	const products = useQuery({
		queryKey: ["products"],
		queryFn: () => productsService.list()
	});
	const [editing, setEditing] = (0, import_react.useState)(null);
	const toggle = useMutation({
		mutationFn: (p) => productsService.update(p.id, { isActive: !p.isActive }),
		onSuccess: (p) => {
			toast.success(p.isActive ? `${p.name} is on sale again` : `${p.name} is hidden from customers`);
			qc.invalidateQueries();
		},
		onError: (e) => toast.error(isApiError(e) ? e.message : "Could not change this product")
	});
	const onSale = products.data?.filter((p) => p.isActive).length ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Prices & delivery",
				description: "Products, their prices and the delivery fees customers pay. Changes apply to new orders only.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setEditing("new"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 size-4" }), " Add product"]
				})
			}),
			products.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Products could not be loaded.",
				onRetry: () => products.refetch()
			}) : products.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
				variant: "cards",
				rows: 3
			}) : !products.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No products yet",
				description: "Add the first product customers can order."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					onSale,
					" of ",
					products.data.length,
					" on sale in the app."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
				children: products.data.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card", !p.isActive && "opacity-70"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductImage, { product: p }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col gap-2 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold leading-tight text-foreground",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("shrink-0 rounded-full px-2 py-0.5 text-xs font-medium", p.isActive ? "bg-brand-green/20 text-foreground" : "bg-muted text-muted-foreground"),
									children: p.isActive ? "On sale" : "Hidden"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-semibold tracking-tight text-foreground",
								children: formatTZS(p.price)
							}),
							p.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: p.description
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-auto pt-2 text-xs text-muted-foreground",
								children: [
									p.orderCount,
									" ",
									p.orderCount === 1 ? "order" : "orders",
									p.updatedAt ? ` · updated ${formatDateTime(p.updatedAt)}` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 border-t pt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm text-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: p.isActive,
										disabled: toggle.isPending,
										onCheckedChange: () => toggle.mutate(p),
										"aria-label": `Show ${p.name} in the app`
									}), "Show in app"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setEditing(p),
									children: "Edit"
								})]
							})
						]
					})]
				}, p.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeliveryFeesCard, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductEditor, {
				product: editing === "new" ? null : editing,
				open: editing !== null,
				onClose: () => setEditing(null),
				onSaved: () => {
					setEditing(null);
					qc.invalidateQueries();
				}
			})
		]
	});
}
var BUILT_IN_PICTURES = {
	first_purchase: "/products/first_purchase.jpg",
	refill: "/products/refill.jpg"
};
function ProductImage({ product, className }) {
	const builtIn = !product.imageUrl && product.code ? BUILT_IN_PICTURES[product.code] : void 0;
	const src = product.imageUrl ?? builtIn;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative flex aspect-[4/3] items-center justify-center overflow-hidden bg-muted/60", className),
		children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: product.name,
			className: "absolute inset-0 size-full object-contain",
			loading: "lazy"
		}), builtIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute left-2 top-2 rounded-full bg-background/90 px-2 py-0.5 text-[11px] text-muted-foreground",
			children: "Built-in picture"
		}) : null] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-1 text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs",
				children: "No picture yet"
			})]
		})
	});
}
function ProductEditor({ product, open, onClose, onSaved }) {
	const [name, setName] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [imageUrl, setImageUrl] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const fileInput = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setName(product?.name ?? "");
		setDescription(product?.description ?? "");
		setPrice(product ? String(product.price) : "");
		setImageUrl(product?.imageUrl ?? "");
		setFile(null);
	}, [open, product]);
	(0, import_react.useEffect)(() => {
		if (!file) {
			setPreview(null);
			return;
		}
		const url = URL.createObjectURL(file);
		setPreview(url);
		return () => URL.revokeObjectURL(url);
	}, [file]);
	const parsed = Number(price);
	const priceOk = price.trim() !== "" && Number.isSafeInteger(parsed) && parsed > 0;
	const nameOk = name.trim().length >= 2;
	const linkOk = !imageUrl.trim() || /^https:\/\/\S+$/.test(imageUrl.trim());
	const valid = nameOk && priceOk && linkOk;
	const save = useMutation({
		mutationFn: async () => {
			const input = {
				name: name.trim(),
				description: description.trim(),
				price: parsed,
				...file ? {} : { imageUrl: imageUrl.trim() || (product ? "" : null) }
			};
			const saved = product ? await productsService.update(product.id, input) : await productsService.create(input);
			if (!file) return {
				saved,
				imageFailed: null
			};
			try {
				return {
					saved: await productsService.uploadImage(saved.id, file),
					imageFailed: null
				};
			} catch (error) {
				return {
					saved,
					imageFailed: isApiError(error) ? error.message : "The picture could not be uploaded."
				};
			}
		},
		onSuccess: ({ saved, imageFailed }) => {
			if (imageFailed) toast.warning(`${saved.name} was saved, but the picture was not: ${imageFailed}`);
			else toast.success(product ? "Product updated" : `${saved.name} added`);
			onSaved();
		},
		onError: (e) => toast.error(isApiError(e) ? e.message : "Could not save this product")
	});
	const pick = (picked) => {
		if (!picked) return;
		if (![
			"image/jpeg",
			"image/png",
			"image/webp"
		].includes(picked.type)) {
			toast.error("Choose a JPG, PNG or WebP picture.");
			return;
		}
		if (picked.size > MAX_IMAGE_MB * 1024 * 1024) {
			toast.error(`Pictures must be smaller than ${MAX_IMAGE_MB} MB.`);
			return;
		}
		setFile(picked);
	};
	const shown = preview ?? (linkOk && imageUrl.trim() ? imageUrl.trim() : null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => !next && !save.isPending && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92vh] max-w-lg overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: product ? `Edit ${product.name}` : "Add product" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: product ? "Changes show in the app straight away." : "It appears in the app as soon as you save it." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Picture" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => fileInput.current?.click(),
									className: "group relative block w-full overflow-hidden rounded-lg border border-dashed border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductImage, {
										product: {
											imageUrl: shown,
											name: name || "Product",
											code: product?.code
										},
										className: "aspect-[16/9]"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-background/85 py-2 text-sm font-medium text-foreground opacity-90 group-hover:opacity-100",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }),
											" ",
											shown ? "Change picture" : "Upload picture"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: fileInput,
									type: "file",
									accept: "image/jpeg,image/png,image/webp",
									className: "hidden",
									onChange: (e) => {
										pick(e.target.files?.[0]);
										e.target.value = "";
									}
								}),
								file ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										file.name,
										" will be uploaded when you save.",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "underline",
											onClick: () => setFile(null),
											children: "Remove"
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Or paste a picture link (https://…)",
										value: imageUrl,
										onChange: (e) => setImageUrl(e.target.value),
										"aria-label": "Picture link"
									}), !linkOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-destructive",
										children: "Links must start with https://"
									}) : null]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "product-name",
								children: "Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "product-name",
								value: name,
								maxLength: 120,
								onChange: (e) => setName(e.target.value),
								placeholder: "e.g. 10L water refill"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "product-price",
									children: "Price (TZS)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "product-price",
									inputMode: "numeric",
									value: price,
									onChange: (e) => setPrice(e.target.value.replace(/[^\d]/g, "")),
									placeholder: "4000"
								}),
								price && priceOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [formatTZS(parsed), " per unit"]
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "product-description",
								children: "Short description (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "product-description",
								value: description,
								maxLength: 300,
								rows: 2,
								onChange: (e) => setDescription(e.target.value),
								placeholder: "Shown under the name in the app"
							})]
						}),
						product && product.orderCount > 0 && Number(price) !== product.price && priceOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground",
							children: "Existing orders keep the price they were placed at."
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					disabled: save.isPending,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !valid || save.isPending,
					onClick: () => save.mutate(),
					children: save.isPending ? "Saving…" : product ? "Save changes" : "Add product"
				})] })
			]
		})
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "pricing.manage",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductsPage, {})
});
//#endregion
export { SplitComponent as component };
