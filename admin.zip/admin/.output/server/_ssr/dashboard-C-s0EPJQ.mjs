import { O as salesService, _ as formatNumber, h as formatDate, i as ORDER_STATUS_LABELS, m as driversService, p as deliveriesService, v as formatRelative, w as ordersService, y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { t as Button } from "./button-bsxhEVXA.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { L as CreditCard, R as ClipboardList, Z as BadgeCheck, a as Truck, b as PackageCheck, f as ServerCog, n as Wallet, o as TriangleAlert, r as Users } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { t as StatCard } from "./StatCard-Bxab4anC.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
import { t as OrderCard } from "./OrderCard-CKNOPI7n.mjs";
import { t as DriverCard } from "./DriverCard-BaHzIopX.mjs";
import { n as DistributionChart, r as ORDER_STATUS_COLORS, s as SalesTrendChart } from "./SalesChart-CNTf1wVH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-C-s0EPJQ.js
var import_jsx_runtime = require_jsx_runtime();
function Panel({ title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold text-foreground",
				children: title
			}), action]
		}), children]
	});
}
function DashboardPage() {
	const { user } = useAuth();
	const role = user.role;
	const isAdmin = role === "SYSTEM_ADMIN";
	const metrics = useQuery({
		queryKey: ["metrics"],
		queryFn: () => ordersService.metrics()
	});
	const activity = useQuery({
		queryKey: ["activity", role],
		queryFn: () => ordersService.activity(role)
	});
	const recentOrders = useQuery({
		queryKey: ["orders", "recent"],
		queryFn: () => ordersService.list({
			page: 1,
			pageSize: 6
		})
	});
	const attention = useQuery({
		queryKey: ["orders", "attention"],
		queryFn: () => ordersService.list({
			page: 1,
			pageSize: 5,
			status: "pending"
		})
	});
	const unassigned = useQuery({
		queryKey: ["deliveries", "unassigned"],
		queryFn: () => deliveriesService.list({
			page: 1,
			pageSize: 5,
			view: "unassigned"
		})
	});
	const drivers = useQuery({
		queryKey: ["drivers", "available"],
		queryFn: () => driversService.available()
	});
	const report = useQuery({
		queryKey: ["sales", "week"],
		queryFn: () => salesService.report({ period: "week" })
	});
	const statusCounts = useQuery({
		queryKey: ["orders", "status-counts"],
		queryFn: () => ordersService.statusCounts()
	});
	if (metrics.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		description: "The dashboard summary could not be loaded.",
		onRetry: () => metrics.refetch()
	});
	const m = metrics.data;
	const loading = metrics.isLoading;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: isAdmin ? "Overview" : "Dashboard",
				description: isAdmin ? "System-wide operational and administrative summary." : "Today's water orders, deliveries and sales at a glance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: isAdmin ? "Total orders today" : "Today's orders",
						value: formatNumber(m?.todayOrders ?? 0),
						icon: ClipboardList,
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: isAdmin ? "Sales today" : "Today's sales",
						value: formatTZS(m?.todaySales ?? 0),
						icon: Wallet,
						tone: "green",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active drivers",
						value: formatNumber(m?.activeDrivers ?? 0),
						icon: Truck,
						tone: "mint",
						loading
					}),
					isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active sales managers",
						value: formatNumber(m?.activeSalesManagers ?? 0),
						icon: Users,
						loading
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending",
						value: formatNumber(m?.pendingOrders ?? 0),
						icon: TriangleAlert,
						tone: "warning",
						loading
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending deliveries",
						value: formatNumber(m?.pendingDeliveries ?? 0),
						icon: Truck,
						tone: "warning",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending payments",
						value: formatNumber(m?.pendingPayments ?? 0),
						icon: CreditCard,
						tone: "warning",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Completed today",
						value: formatNumber(m?.completedToday ?? 0),
						icon: PackageCheck,
						tone: "green",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "System status",
						value: m ? m.systemStatus.charAt(0).toUpperCase() + m.systemStatus.slice(1) : "—",
						icon: ServerCog,
						tone: m?.systemStatus === "operational" ? "green" : "warning",
						loading
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Processing",
						value: formatNumber(m?.processing ?? 0),
						icon: PackageCheck,
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Out for delivery",
						value: formatNumber(m?.outForDelivery ?? 0),
						icon: Truck,
						tone: "mint",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Completed today",
						value: formatNumber(m?.completedToday ?? 0),
						icon: BadgeCheck,
						tone: "green",
						loading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending payments",
						value: formatNumber(m?.pendingPayments ?? 0),
						icon: CreditCard,
						tone: "warning",
						loading
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 xl:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "xl:col-span-2",
					children: report.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "chart" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesTrendChart, {
						title: "Sales trend (this week)",
						data: (report.data?.trend ?? []).map((p) => ({
							date: formatDate(p.date).slice(0, 6),
							sales: p.sales
						}))
					})
				}), statusCounts.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, { variant: "chart" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DistributionChart, {
					title: "Order status distribution",
					data: (statusCounts.data ?? []).map((s) => ({
						label: ORDER_STATUS_LABELS[s.status],
						count: s.count,
						color: ORDER_STATUS_COLORS[s.status]
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 xl:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Recent orders",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/orders",
								children: "View all"
							})
						}),
						children: recentOrders.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
							variant: "table",
							rows: 3
						}) : (recentOrders.data?.items.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "No orders yet",
							description: "New orders will appear here."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: recentOrders.data.items.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
								order,
								compact: true
							}, order.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: isAdmin ? "Orders awaiting action" : "Orders requiring attention",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/orders",
								children: "Open orders"
							})
						}),
						children: attention.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
							variant: "table",
							rows: 3
						}) : (attention.data?.items.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "Nothing needs attention",
							description: "All orders are moving."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: attention.data.items.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 rounded-lg border border-border p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium text-foreground",
											children: order.customer.fullName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												formatDate(order.requestedDeliveryDate),
												" · ",
												order.requestedDeliveryWindow
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
										kind: "order",
										status: order.status
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										size: "sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/orders/$id",
											params: { id: order.id },
											children: "View"
										})
									})
								]
							}, order.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Deliveries needing assignment",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/deliveries",
								children: "Assign"
							})
						}),
						children: unassigned.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
							variant: "table",
							rows: 3
						}) : (unassigned.data?.items.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "All deliveries assigned",
							description: "No unassigned deliveries."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: unassigned.data.items.map((delivery) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 rounded-lg border border-border p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium text-foreground",
										children: delivery.customerName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [
											delivery.location.area,
											" · ",
											delivery.timeWindow
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
									kind: "delivery",
									status: delivery.status
								})]
							}, delivery.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: isAdmin ? "Recent administrative activity" : "Recent operational activity",
						children: activity.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
							variant: "table",
							rows: 3
						}) : (activity.data?.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { title: "No recent activity" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-3",
							children: activity.data.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border-l-2 border-primary/30 pl-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-foreground",
										children: event.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: event.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-xs text-muted-foreground",
										children: formatRelative(event.at)
									})
								]
							}, event.id))
						})
					})
				]
			}),
			!isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Active drivers",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/drivers",
						children: "Manage drivers"
					})
				}),
				children: drivers.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
					variant: "cards",
					rows: 4
				}) : (drivers.data?.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No active drivers",
					description: "Activate a driver to start assigning."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
					children: drivers.data.slice(0, 4).map((driver) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DriverCard, { driver }, driver.id))
				})
			}) : null
		]
	});
}
//#endregion
export { DashboardPage as component };
