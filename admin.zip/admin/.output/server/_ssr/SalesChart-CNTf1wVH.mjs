import { y as formatTZS } from "./services-BvSDC5Xz.mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as XAxis, c as Bar, d as ResponsiveContainer, f as Tooltip, i as YAxis, l as Pie, n as BarChart, o as Line, r as LineChart, s as CartesianGrid, t as PieChart, u as Cell } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SalesChart-CNTf1wVH.js
var import_jsx_runtime = require_jsx_runtime();
var CHART_COLORS = {
	blue: "#2563eb",
	green: "#16a34a",
	orange: "#f97316",
	yellow: "#eab308",
	red: "#dc2626",
	purple: "#9333ea",
	teal: "#0d9488",
	pink: "#db2777",
	sky: "#0ea5e9",
	gray: "#64748b"
};
/** One fixed colour per order status, so a status keeps its colour on every chart. */
var ORDER_STATUS_COLORS = {
	pending: CHART_COLORS.yellow,
	confirmed: CHART_COLORS.sky,
	processing: CHART_COLORS.purple,
	out_for_delivery: CHART_COLORS.orange,
	delivered: CHART_COLORS.blue,
	customer_received: CHART_COLORS.green,
	cancelled: CHART_COLORS.red
};
var PAYMENT_STATUS_COLORS = {
	paid: CHART_COLORS.green,
	pending: CHART_COLORS.yellow,
	failed: CHART_COLORS.red,
	cancelled: CHART_COLORS.gray,
	refunded: CHART_COLORS.purple
};
var PAYMENT_METHOD_COLORS = {
	cash: CHART_COLORS.green,
	mobile_money: CHART_COLORS.blue
};
/** New bottle + water in blue, refills in green; products added later use the series colours. */
var PRODUCT_COLORS = {
	first_purchase: CHART_COLORS.blue,
	refill: CHART_COLORS.green
};
var SERIES_COLORS = [
	CHART_COLORS.blue,
	CHART_COLORS.green,
	CHART_COLORS.orange,
	CHART_COLORS.purple,
	CHART_COLORS.yellow,
	CHART_COLORS.red,
	CHART_COLORS.teal,
	CHART_COLORS.pink,
	CHART_COLORS.sky,
	CHART_COLORS.gray
];
var colorAt = (i, color) => color ?? SERIES_COLORS[i % SERIES_COLORS.length];
function Frame({ title, children, footer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-64",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children
				})
			}),
			footer
		]
	});
}
function SalesTrendChart({ title = "Sales trend", data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
		title,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				bottom: 0,
				left: 8
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					strokeDasharray: "3 3",
					className: "stroke-border",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "date",
					tickLine: false,
					axisLine: false,
					fontSize: 11
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tickLine: false,
					axisLine: false,
					fontSize: 11,
					width: 64,
					tickFormatter: (v) => formatTZS(v, { compact: true })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (v) => formatTZS(v) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: "sales",
					stroke: CHART_COLORS.blue,
					strokeWidth: 2,
					dot: false
				})
			]
		})
	});
}
function CountBarChart({ title, data, dataKey = "count" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
		title,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				bottom: 0,
				left: 8
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					strokeDasharray: "3 3",
					className: "stroke-border",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "label",
					tickLine: false,
					axisLine: false,
					fontSize: 11,
					interval: 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tickLine: false,
					axisLine: false,
					fontSize: 11,
					width: 36,
					allowDecimals: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { cursor: { fill: "rgba(100,116,139,0.08)" } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey,
					radius: [
						6,
						6,
						0,
						0
					],
					children: data.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: colorAt(i, item.color) }, item.label))
				})
			]
		})
	});
}
var percentOf = (count, total) => total ? `${Math.round(count / total * 100)}%` : "0%";
/** Ring chart with one colour per slice and a legend showing each part's share. */
function DistributionChart({ title, data }) {
	const shown = data.filter((item) => item.count > 0);
	const total = shown.reduce((sum, item) => sum + item.count, 0);
	const colored = shown.map((item, i) => ({
		...item,
		fill: colorAt(i, item.color)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
		title,
		footer: total ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid gap-x-4 gap-y-1.5 text-xs sm:grid-cols-2",
			children: colored.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-2.5 shrink-0 rounded-full",
						style: { backgroundColor: item.fill },
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-foreground",
						children: item.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-auto font-semibold text-foreground",
						children: percentOf(item.count, total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-8 text-right text-muted-foreground",
						children: item.count
					})
				]
			}, item.label))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-center text-xs text-muted-foreground",
			children: "Nothing to show for this period."
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
			data: colored,
			dataKey: "count",
			nameKey: "label",
			innerRadius: 52,
			outerRadius: 86,
			paddingAngle: colored.length > 1 ? 2 : 0,
			label: ({ percent }) => percent >= .05 ? `${Math.round(percent * 100)}%` : "",
			labelLine: false,
			children: colored.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: item.fill }, item.label))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (value, name) => [`${value} (${percentOf(value, total)})`, name] })] })
	});
}
//#endregion
export { PAYMENT_STATUS_COLORS as a, PAYMENT_METHOD_COLORS as i, DistributionChart as n, PRODUCT_COLORS as o, ORDER_STATUS_COLORS as r, SalesTrendChart as s, CountBarChart as t };
