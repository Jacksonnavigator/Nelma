import { i as __toESM } from "../_runtime.mjs";
import { S as notificationsService, v as formatRelative } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { L as CreditCard, X as Bell, a as Truck, b as PackageCheck, d as Settings } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as TabsList, r as TabsTrigger, t as Tabs } from "./tabs-DYVPlZaJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-Bw5ERqh-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	order: PackageCheck,
	delivery: Truck,
	payment: CreditCard,
	driver: Truck,
	system: Settings
};
function NotificationItem({ notification, onMarkRead, busy }) {
	const Icon = ICONS[notification.kind] ?? Bell;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-start gap-3 rounded-xl border p-4 shadow-card", notification.read ? "border-border bg-card" : "border-primary/25 bg-primary/5"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-9 shrink-0 items-center justify-center rounded-lg", notification.read ? "bg-muted text-muted-foreground" : "bg-primary/10 text-primary"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: notification.title
						}), !notification.read ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary px-2 py-0.5 text-[10px] font-semibold uppercase text-primary-foreground",
							children: "New"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: notification.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: formatRelative(notification.createdAt)
					})
				]
			}),
			!notification.read && onMarkRead ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				disabled: busy,
				onClick: () => onMarkRead(notification.id),
				children: "Mark read"
			}) : null
		]
	});
}
function NotificationsPage() {
	const { user } = useAuth();
	const qc = useQueryClient();
	const [view, setView] = (0, import_react.useState)("all");
	const role = user.role;
	const notifications = useQuery({
		queryKey: ["notifications", role],
		queryFn: () => notificationsService.list(role)
	});
	const markRead = useMutation({
		mutationFn: (id) => notificationsService.markRead(id),
		onSuccess: () => qc.invalidateQueries(),
		onError: () => toast.error("Could not update this notification")
	});
	const markAll = useMutation({
		mutationFn: () => notificationsService.markAllRead(role),
		onSuccess: () => {
			toast.success("All notifications marked as read");
			qc.invalidateQueries();
		},
		onError: () => toast.error("Could not update notifications")
	});
	const items = (notifications.data ?? []).filter((n) => view === "unread" ? !n.read : true);
	const unread = (notifications.data ?? []).filter((n) => !n.read).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Notifications",
				description: unread > 0 ? `${unread} unread alert${unread === 1 ? "" : "s"}.` : "You are up to date.",
				actions: unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: markAll.isPending,
					onClick: () => markAll.mutate(),
					children: "Mark all as read"
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: view,
				onValueChange: (v) => setView(v),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "all",
					children: "All"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "unread",
					children: "Unread"
				})] })
			}),
			notifications.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Notifications could not be loaded.",
				onRetry: () => notifications.refetch()
			}) : notifications.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
				variant: "table",
				rows: 4
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: view === "unread" ? "No unread notifications" : "No notifications yet",
				description: "Alerts about orders, deliveries and payments will appear here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: items.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationItem, {
					notification: n,
					busy: markRead.isPending,
					onMarkRead: (id) => markRead.mutate(id)
				}, n.id))
			})
		]
	});
}
//#endregion
export { NotificationsPage as component };
