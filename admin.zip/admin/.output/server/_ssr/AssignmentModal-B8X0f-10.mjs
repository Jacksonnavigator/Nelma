import { i as __toESM } from "../_runtime.mjs";
import { b as initials } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-DZsl5SSz.mjs";
import { t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { t as StatusBadge } from "./StatusBadge-JitCjw3w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AssignmentModal-B8X0f-10.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Driver assignment / reassignment. The caller owns the mutation so this
* component stays repository-agnostic.
*/
function AssignmentModal({ open, onOpenChange, drivers, currentDriverId, loading, onAssign, title = "Assign driver" }) {
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const selectable = drivers.filter((d) => d.status === "active");
	const selectedDriver = selectable.find((d) => d.id === selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next) setSelected(null);
			onOpenChange(next);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: currentDriverId ? "Choose a different active driver to reassign this delivery." : "Choose an active driver for this delivery." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-80 space-y-2 overflow-y-auto pr-1",
					children: selectable.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No active drivers",
						description: "Activate a driver first."
					}) : selectable.map((driver) => {
						const isCurrent = driver.id === currentDriverId;
						const offDuty = driver.onDuty === false;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: isCurrent || offDuty,
							title: offDuty ? `${driver.fullName} is off duty in the driver app.` : void 0,
							onClick: () => setSelected(driver.id),
							className: cn("flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors", selected === driver.id ? "border-primary bg-primary/5" : "border-border hover:bg-muted/60", (isCurrent || offDuty) && "cursor-not-allowed opacity-60"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-9 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary",
									children: initials(driver.fullName)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm font-medium text-foreground",
										children: driver.fullName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-muted-foreground",
										children: [
											driver.todayAssigned,
											" today · ",
											driver.activeDeliveries,
											" active ·",
											" ",
											offDuty ? "Off duty" : driver.available ? "Available" : "Busy"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
									kind: "account",
									status: driver.status
								})
							]
						}, driver.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => onOpenChange(false),
					disabled: loading,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !selected || loading,
					onClick: () => setConfirming(true),
					children: currentDriverId ? "Reassign" : "Assign"
				})] })
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
		open: confirming,
		onOpenChange: setConfirming,
		title: currentDriverId ? "Reassign this delivery?" : "Assign this delivery?",
		description: selectedDriver ? `${selectedDriver.fullName} will handle this delivery.` : "This delivery will be assigned.",
		confirmLabel: currentDriverId ? "Reassign" : "Assign",
		loading: loading === true,
		onConfirm: () => {
			if (!selected) return;
			onAssign(selected);
			setConfirming(false);
		}
	})] });
}
//#endregion
export { AssignmentModal as t };
