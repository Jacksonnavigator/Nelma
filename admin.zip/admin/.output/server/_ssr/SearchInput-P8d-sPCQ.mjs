import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as cn } from "./button-bsxhEVXA.mjs";
import { m as Search, t as X } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SearchInput-P8d-sPCQ.js
var import_jsx_runtime = require_jsx_runtime();
function SearchInput({ value, onChange, placeholder = "Search…", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative w-full sm:max-w-xs", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value,
				"aria-label": placeholder,
				placeholder,
				onChange: (e) => onChange(e.target.value),
				className: "pl-9 pr-8"
			}),
			value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Clear search",
				onClick: () => onChange(""),
				className: "absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
			}) : null
		]
	});
}
//#endregion
export { SearchInput as t };
