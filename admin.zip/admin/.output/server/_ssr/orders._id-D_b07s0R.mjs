import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders._id-D_b07s0R.js
var $$splitComponentImporter = () => import("./orders._id-DpAf6hcA.mjs");
var Route = createFileRoute("/_authenticated/orders/$id")({
	head: () => ({ meta: [
		{ title: "NELMA | Order details" },
		{
			name: "description",
			content: "Full order record, delivery details, payment state and lifecycle history."
		},
		{
			property: "og:title",
			content: "NELMA | Order details"
		},
		{
			property: "og:description",
			content: "Full order record, delivery details, payment state and lifecycle history."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
