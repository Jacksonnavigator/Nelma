import { i as __toESM } from "../_runtime.mjs";
import { h as formatDate, j as usersService } from "./services-BvSDC5Xz.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { o as useAuth } from "./useAuth-BIb6Ul2A.mjs";
import { r as cn, t as Button } from "./button-bsxhEVXA.mjs";
import { t as RoleBadge } from "./RoleBadge-EcFSJS8c.mjs";
import { O as KeyRound } from "../_libs/lucide-react.mjs";
import { t as PageHeader } from "./PageHeader-Cvoi0nwQ.mjs";
import { t as PermissionGate } from "./PermissionGate-BxLSXnfA.mjs";
import { t as Input } from "./input-BH8uoUrC.mjs";
import { t as Label } from "./label-sao5VpVh.mjs";
import { t as ConfirmDialog } from "./ConfirmDialog-DZsl5SSz.mjs";
import { n as ErrorState, r as LoadingSkeleton, t as EmptyState } from "./states-eHNfqxIu.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-jTYkyAl3.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BOhrZlN0.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as FilterSelect, t as FilterBar } from "./FilterBar-BHwBUYK9.mjs";
import { t as SearchInput } from "./SearchInput-P8d-sPCQ.mjs";
import { t as DataPagination } from "./DataPagination-cN6wKWJj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/users-Bb-2mFKZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 25;
var ROLE_TABS = [
	{
		value: "all",
		label: "Everyone"
	},
	{
		value: "USER",
		label: "Customers"
	},
	{
		value: "DRIVER",
		label: "Drivers"
	},
	{
		value: "SALES_MANAGER",
		label: "Sales managers"
	},
	{
		value: "SYSTEM_ADMIN",
		label: "Admins"
	}
];
function UsersPage() {
	const [page, setPage] = (0, import_react.useState)(1);
	const [role, setRole] = (0, import_react.useState)("all");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const query = {
		page,
		pageSize: PAGE_SIZE,
		role,
		status,
		search
	};
	const users = useQuery({
		queryKey: ["users", query],
		queryFn: () => usersService.list(query),
		placeholderData: keepPreviousData
	});
	const qc = useQueryClient();
	const { user: me } = useAuth();
	const [toggling, setToggling] = (0, import_react.useState)(null);
	const [resetting, setResetting] = (0, import_react.useState)(null);
	const [password, setPassword] = (0, import_react.useState)("");
	const failed = (error, fallback) => toast.error(error && typeof error === "object" && "message" in error ? String(error.message) : fallback);
	const toggle = useMutation({
		mutationFn: (u) => usersService.setActive(u.id, !u.isActive),
		onSuccess: (u) => {
			toast.success(u.isActive ? `${u.fullName} can sign in again` : `${u.fullName} is signed out and blocked`);
			setToggling(null);
			qc.invalidateQueries({ queryKey: ["users"] });
		},
		onError: (error) => failed(error, "Could not change this account")
	});
	const reset = useMutation({
		mutationFn: ({ id, value }) => usersService.setPassword(id, value),
		onSuccess: () => {
			toast.success("New password set. Share it with them privately.");
			setResetting(null);
			setPassword("");
		},
		onError: (error) => failed(error, "Could not set the password")
	});
	const counts = users.data?.roleCounts ?? {};
	const everyone = Object.values(counts).reduce((sum, n) => sum + (n ?? 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Users",
				description: "Every account: customers from the app, drivers and dashboard staff."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Filter by role",
				children: ROLE_TABS.map((tab) => {
					const count = tab.value === "all" ? everyone : counts[tab.value] ?? 0;
					const active = role === tab.value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						role: "tab",
						"aria-selected": active,
						onClick: () => {
							setRole(tab.value);
							setPage(1);
						},
						className: cn("rounded-full border px-3 py-1.5 text-sm font-medium transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-muted"),
						children: [tab.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("ml-1.5 tabular-nums", active ? "text-primary-foreground/80" : "text-muted-foreground"),
							children: users.data ? count : "·"
						})]
					}, tab.value);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
					value: search,
					onChange: (v) => {
						setSearch(v);
						setPage(1);
					},
					placeholder: "Search name, phone or email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {
					onClear: () => setStatus("all"),
					showClear: status !== "all",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						label: "Status",
						value: status,
						onChange: (v) => {
							setStatus(v);
							setPage(1);
						},
						options: [
							{
								value: "all",
								label: "Active and inactive"
							},
							{
								value: "active",
								label: "Active"
							},
							{
								value: "inactive",
								label: "Inactive"
							}
						]
					})
				})]
			}),
			users.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				description: "Users could not be loaded.",
				onRetry: () => users.refetch()
			}) : users.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {}) : !users.data?.items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No users found",
				description: "Try another search or role."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Name" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Contact" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Role" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "text-right",
						children: "Orders"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Joined" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
						className: "text-right",
						children: "Actions"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: users.data.items.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: u.fullName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "tabular-nums",
						children: u.phone
					}), u.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted-foreground",
						children: u.email
					}) : null] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: u.role }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-right tabular-nums",
						children: u.role === "USER" ? u.orderCount : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("inline-flex items-center gap-1.5 text-sm", u.isActive ? "text-foreground" : "text-muted-foreground"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", u.isActive ? "bg-brand-green" : "bg-muted-foreground/50") }), u.isActive ? "Active" : "Inactive"]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: formatDate(u.createdAt) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-right",
						children: u.id === me?.id || u.phone.startsWith("deleted-") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: u.id === me?.id ? "You" : "Deleted by customer"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => setResetting(u),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "mr-1 size-3.5" }), " Password"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								className: u.isActive ? "text-destructive hover:text-destructive" : "",
								onClick: () => setToggling(u),
								children: u.isActive ? "Deactivate" : "Activate"
							})]
						})
					})
				] }, u.id)) })] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPagination, {
				page,
				pageSize: PAGE_SIZE,
				total: users.data.total,
				onPageChange: setPage
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!toggling,
				onOpenChange: (open) => !open && setToggling(null),
				title: toggling?.isActive ? `Deactivate ${toggling.fullName}?` : `Activate ${toggling?.fullName ?? ""}?`,
				description: toggling?.isActive ? "They are signed out straight away and cannot sign in until you activate them again. Their orders stay." : "They will be able to sign in again with their current password.",
				confirmLabel: toggling?.isActive ? "Deactivate" : "Activate",
				destructive: !!toggling?.isActive,
				loading: toggle.isPending,
				onConfirm: () => toggling && toggle.mutate(toggling)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!resetting,
				onOpenChange: (open) => {
					if (!open) {
						setResetting(null);
						setPassword("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-4",
					onSubmit: (e) => {
						e.preventDefault();
						if (resetting && password.length >= 8) reset.mutate({
							id: resetting.id,
							value: password
						});
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Set a new password for ", resetting?.fullName] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "For someone who cannot use \"Forgot password\". They are signed out on every device and sign in with this password." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "new-password",
									children: "New password"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "new-password",
									type: "password",
									autoComplete: "new-password",
									minLength: 8,
									maxLength: 128,
									required: true,
									value: password,
									onChange: (e) => setPassword(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "At least 8 characters."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setResetting(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: password.length < 8 || reset.isPending,
							children: reset.isPending ? "Saving…" : "Set password"
						})] })
					]
				}) })
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionGate, {
	permission: "accounts.manage",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersPage, {})
});
//#endregion
export { SplitComponent as component };
