import { i as ORDER_STATUS_LABELS, n as DELIVERY_STATUS_LABELS, o as PAYMENT_STATUS_LABELS } from "./services-BvSDC5Xz.mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as cn } from "./button-bsxhEVXA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatusBadge-JitCjw3w.js
var import_jsx_runtime = require_jsx_runtime();
var TONE_CLASS = {
	neutral: "bg-muted text-muted-foreground border-border",
	info: "bg-primary/10 text-primary border-primary/20",
	progress: "bg-brand-soft/25 text-accent-foreground border-brand-soft/40",
	success: "bg-success/12 text-success border-success/25",
	warning: "bg-warning/15 text-warning border-warning/30",
	danger: "bg-destructive/10 text-destructive border-destructive/20"
};
var ORDER_TONES = {
	pending: "warning",
	confirmed: "info",
	processing: "progress",
	out_for_delivery: "progress",
	delivered: "success",
	customer_received: "success",
	cancelled: "danger"
};
var DELIVERY_TONES = {
	unassigned: "warning",
	assigned: "info",
	out_for_delivery: "progress",
	delivered: "success",
	customer_received: "success",
	cancelled: "danger"
};
var PAYMENT_TONES = {
	pending: "warning",
	paid: "success",
	failed: "danger",
	cancelled: "danger",
	refunded: "neutral"
};
function Pill({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-medium", TONE_CLASS[tone]),
		children
	});
}
function StatusBadge(props) {
	if (props.kind === "order") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: ORDER_TONES[props.status],
		children: ORDER_STATUS_LABELS[props.status]
	});
	if (props.kind === "delivery") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: DELIVERY_TONES[props.status],
		children: DELIVERY_STATUS_LABELS[props.status]
	});
	if (props.kind === "payment") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: PAYMENT_TONES[props.status],
		children: PAYMENT_STATUS_LABELS[props.status]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: props.status === "active" ? "success" : "neutral",
		children: props.status === "active" ? "Active" : "Inactive"
	});
}
//#endregion
export { StatusBadge as t };
